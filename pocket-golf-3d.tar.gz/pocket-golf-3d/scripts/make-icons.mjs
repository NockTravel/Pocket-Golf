// Rasterises the app icon to PNG (192 + 512) with no dependencies.
import { deflateSync } from "node:zlib";
import { writeFileSync, mkdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const out = join(dirname(fileURLToPath(import.meta.url)), "..", "public");
mkdirSync(out, { recursive: true });

const CRC = new Uint32Array(256).map((_, n) => {
  let c = n;
  for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  return c >>> 0;
});
function crc32(buf) {
  let c = 0xffffffff;
  for (const b of buf) c = CRC[(c ^ b) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}
function chunk(type, data) {
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length);
  const td = Buffer.concat([Buffer.from(type), data]);
  const crc = Buffer.alloc(4); crc.writeUInt32BE(crc32(td));
  return Buffer.concat([len, td, crc]);
}

// shape tests in unit coords (0..1)
const inCircle = (u, v, cx, cy, r) => (u - cx) ** 2 + (v - cy) ** 2 <= r * r;
const inEll = (u, v, cx, cy, rx, ry) => ((u - cx) / rx) ** 2 + ((v - cy) / ry) ** 2 <= 1;
function inTri(u, v, a, b, c) {
  const s = (p, q, r) => (p[0] - r[0]) * (q[1] - r[1]) - (q[0] - r[0]) * (p[1] - r[1]);
  const d1 = s([u, v], a, b), d2 = s([u, v], b, c), d3 = s([u, v], c, a);
  return !((d1 < 0 || d2 < 0 || d3 < 0) && (d1 > 0 || d2 > 0 || d3 > 0));
}
function color(u, v) {
  // background gradient
  let c = [Math.round(16 + 14 * (1 - v)), Math.round(34 + 26 * (1 - v)), Math.round(24 + 14 * (1 - v))];
  if (inCircle(u, v, 0.5, 0.64, 0.31)) c = [126, 226, 160];
  if (inCircle(u, v, 0.5, 0.64, 0.31) && v > 0.64 + 0.16) c = [104, 200, 138];
  if (inEll(u, v, 0.5, 0.7, 0.075, 0.03)) c = [11, 20, 16];
  if (u > 0.49 && u < 0.515 && v > 0.17 && v < 0.7) c = [255, 255, 255];
  if (inTri(u, v, [0.515, 0.17], [0.74, 0.245], [0.515, 0.32])) c = [255, 90, 74];
  if (inCircle(u, v, 0.34, 0.74, 0.042)) c = [255, 255, 255];
  return c;
}
function png(size) {
  const ss = 3, rows = [];
  for (let y = 0; y < size; y++) {
    const row = Buffer.alloc(1 + size * 4);
    for (let x = 0; x < size; x++) {
      let r = 0, g = 0, b = 0;
      for (let sy = 0; sy < ss; sy++) for (let sx = 0; sx < ss; sx++) {
        const c = color((x + (sx + 0.5) / ss) / size, (y + (sy + 0.5) / ss) / size);
        r += c[0]; g += c[1]; b += c[2];
      }
      const n = ss * ss, o = 1 + x * 4;
      row[o] = r / n; row[o + 1] = g / n; row[o + 2] = b / n; row[o + 3] = 255;
    }
    rows.push(row);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0); ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
    chunk("IHDR", ihdr), chunk("IDAT", deflateSync(Buffer.concat(rows))), chunk("IEND", Buffer.alloc(0)),
  ]);
}
for (const s of [192, 512]) { writeFileSync(join(out, `icon-${s}.png`), png(s)); console.log("icon", s); }
