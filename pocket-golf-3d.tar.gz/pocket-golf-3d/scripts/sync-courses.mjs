// Copies canonical course JSON from src/courses to public/courses so the
// built site ships droppable sample course files alongside the engine.
import { mkdirSync, readdirSync, copyFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const srcDir = join(root, "src", "courses");
const outDir = join(root, "public", "courses");
mkdirSync(outDir, { recursive: true });
for (const f of readdirSync(srcDir)) {
  if (f.endsWith(".json")) { copyFileSync(join(srcDir, f), join(outDir, f)); console.log("synced", f); }
}
