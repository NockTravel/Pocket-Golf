# Deploying `pocket-golf-3d` to GitHub Pages

The project is already a git repo with one commit on `main`. Pick either path.

## Option A — one command (needs the GitHub CLI `gh`, logged in)

```bash
cd pocket-golf-3d
gh repo create pocket-golf-3d --public --source=. --remote=origin --push
```

Then in the new repo on github.com: **Settings → Pages → Build and deployment → Source: GitHub Actions**.
The included workflow builds and publishes on every push to `main`.

## Option B — manual

1. Create a new **public** repo named `pocket-golf-3d` on github.com (no README/license — keep it empty).
2. Push:
   ```bash
   cd pocket-golf-3d
   git remote add origin https://github.com/<your-username>/pocket-golf-3d.git
   git push -u origin main
   ```
3. In the repo: **Settings → Pages → Source: GitHub Actions**.

## Result

Within a minute or two the **Deploy to GitHub Pages** action finishes and the game is live at:

```
https://<your-username>.github.io/pocket-golf-3d/
```

Every later `git push` to `main` redeploys automatically.
