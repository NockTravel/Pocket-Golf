# Pocket Golf 3D

A small 3-hole golf game built with **TypeScript + Three.js + Vite**. Runs entirely in the browser — no backend — and deploys to GitHub Pages.

## Play locally

```bash
npm install
npm run dev      # open the printed localhost URL
```

## Build

```bash
npm run build    # type-checks then outputs static site to dist/
npm run preview  # serve the production build locally
```

## How to play

- **Drag** on the view to aim, or tap **Aim view** for a top-down aiming camera (tap the ground to point).
- The main button runs the whole swing: **Start swing → Set power → Strike!** (tapping the view works too).
- Centre the **impact** marker for a pure strike; stop in the draw/fade windows to shape the shot.
- **While the ball is in the air, drag** the spin dial for back/top and side spin.
- Greens are contoured — read the surface shading; putts break downhill.

Courses: Coastal Pines (9 holes, doglegs & island green), Cape Cliffs (9 holes, clifftop fairways, sea coves & a chasm), Sunshine Links (9 holes). Custom golfer: hat, hair, shirt, trousers, skin.

## Deploy (GitHub Pages)

`vite.config.ts` sets `base: "/pocket-golf-3d/"` to match the Pages path. The included
GitHub Actions workflow (`.github/workflows/deploy.yml`) builds and publishes `dist/` on
every push to `main`. In the repo, enable **Settings → Pages → Source: GitHub Actions**.

Live URL: `https://<your-username>.github.io/pocket-golf-3d/`
