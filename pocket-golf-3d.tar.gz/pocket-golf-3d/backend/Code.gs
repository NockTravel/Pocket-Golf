/**
 * Pocket Golf 3D — leaderboard backend (Google Apps Script bound to a Google Sheet).
 *
 * Tabs (created by Pocket Golf → Set up sheets):
 *   Players : Name | PinHash | Hcap | HcapOverride | Difficulty | Rounds | Created | LastSeen
 *   Scores  : one row per round, filled in hole by hole as it's played
 *             Time | Name | Course | RoundID | Holes | H1 … H18 | Out | In | Total | Par | Net | Hcap | Bag | Difficulty | Status | Recv
 *   Bests   : readable summary (Pocket Golf → Rebuild Bests tab)
 *
 * Hcap is worked out automatically from completed rounds (average of the best 3 of the last 10,
 * scaled to 18 holes). Front-9 / back-9 rounds on an 18-hole course count too (scaled up). Put a number in HcapOverride to set someone's handicap by hand.
 * Difficulty is hidden from players: 0 normal, 1 harder, 2 much harder (decimals allowed, -1 easier).
 * Recv (last column) is the handicap strokes received on each hole for that round — used for net scores.
 */

const MAX_ROWS = 10;
const CACHE_SECS = 45;
const START_HCAP = 18;

const P_HEAD = ["Name", "PinHash", "Hcap", "HcapOverride", "Difficulty", "Rounds", "Created", "LastSeen"];
const P = { name: 0, pin: 1, hcap: 2, over: 3, diff: 4, rounds: 5, created: 6, seen: 7 };

const S_HEAD = (function () {
  const h = ["Time", "Name", "Course", "RoundID", "Holes"];
  for (let i = 1; i <= 18; i++) h.push("H" + i);
  return h.concat(["Out", "In", "Total", "Par", "Net", "Hcap", "Bag", "Difficulty", "Status", "Recv"]);
})();
const S = (function () { const o = {}; S_HEAD.forEach(function (k, i) { o[k] = i; }); return o; })();

function onOpen() {
  SpreadsheetApp.getUi().createMenu("Pocket Golf")
    .addItem("Set up sheets", "setup")
    .addItem("Rebuild Bests tab", "rebuildBests")
    .addItem("Recalculate all handicaps", "recalcAllHcaps")
    .addToUi();
}

function setup() {
  sheet_("Players", P_HEAD);
  sheet_("Scores", S_HEAD);
  sheet_("Bests", ["Course", "Type", "Key", "Name", "Best gross", "Best net"]);
}

function sheet_(name, headers) {
  const ss = SpreadsheetApp.getActive();
  let sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  // add the heading row if it's missing (e.g. the tab was made by hand)
  if (headers && headers.length && String(sh.getRange(1, 1).getValue()) !== headers[0]) {
    if (sh.getLastRow() > 0) sh.insertRowBefore(1);
    sh.getRange(1, 1, 1, headers.length).setValues([headers]).setFontWeight("bold");
    sh.setFrozenRows(1);
  }
  return sh;
}

function json_(o) {
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
function hash_(pin) {
  const raw = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, "pg3d:" + String(pin));
  return raw.map(function (b) { return ((b + 256) % 256).toString(16).padStart(2, "0"); }).join("");
}
function cleanName_(n) { return String(n || "").replace(/[^\w .'-]/g, "").trim().slice(0, 24); }
function num_(v) { return v === "" || v === null || v === undefined ? null : Number(v); }

// ------------------------------------------------------------------------------ players
function findPlayer_(name) {
  const sh = sheet_("Players", P_HEAD);
  const vals = sh.getDataRange().getValues();
  const key = String(name).toLowerCase();
  for (let i = 1; i < vals.length; i++) {
    if (String(vals[i][P.name]).toLowerCase() === key) {
      const over = num_(vals[i][P.over]);
      return {
        row: i + 1, name: vals[i][P.name], pinHash: vals[i][P.pin],
        hcap: over !== null ? over : (num_(vals[i][P.hcap]) !== null ? Number(vals[i][P.hcap]) : START_HCAP),
        difficulty: Number(vals[i][P.diff]) || 0,
      };
    }
  }
  return null;
}
function publicPlayer_(p) { return { name: p.name, hcap: p.hcap, difficulty: p.difficulty }; }

/** Handicap = average of the best 3 of the last 10 completed rounds (strokes over par, scaled to 18 holes). */
function computeHcap_(name, scoreVals) {
  const diffs = [];
  for (let i = 1; i < scoreVals.length; i++) {
    const r = scoreVals[i];
    const st = String(r[S.Status]);
    if (String(r[S.Name]).toLowerCase() !== String(name).toLowerCase() || st.indexOf("omplete") < 0) continue;
    const holes = st === "Complete" ? (Number(r[S.Holes]) || 18) : 9, tot = Number(r[S.Total]), par = Number(r[S.Par]);
    if (!tot || !par) continue;
    diffs.push({ t: new Date(r[S.Time]).getTime() || i, d: (tot - par) * (18 / holes) });
  }
  if (!diffs.length) return { hcap: START_HCAP, rounds: 0 };
  diffs.sort(function (a, b) { return b.t - a.t; });
  const last = diffs.slice(0, 10).map(function (x) { return x.d; }).sort(function (a, b) { return a - b; });
  const best = last.slice(0, Math.min(3, last.length));
  const avg = best.reduce(function (a, b) { return a + b; }, 0) / best.length;
  return { hcap: Math.max(-5, Math.min(36, Math.round(avg * 10) / 10)), rounds: diffs.length };
}
function updateHcap_(name, scoreVals) {
  const pl = findPlayer_(name);
  if (!pl) return;
  const r = computeHcap_(name, scoreVals);
  const sh = sheet_("Players", P_HEAD);
  sh.getRange(pl.row, P.hcap + 1).setValue(r.hcap);
  sh.getRange(pl.row, P.rounds + 1).setValue(r.rounds);
}
function recalcAllHcaps() {
  const scores = sheet_("Scores", S_HEAD).getDataRange().getValues();
  const players = sheet_("Players", P_HEAD).getDataRange().getValues();
  for (let i = 1; i < players.length; i++) updateHcap_(players[i][P.name], scores);
}

// ------------------------------------------------------------------------------ GET
function doGet(e) {
  const p = e.parameter || {};
  try {
    if (p.action === "login") return json_(login_(p.name, p.pin));
    if (p.action === "board") return json_(board_(String(p.course || "")));
    return json_({ ok: true, service: "pocket-golf-3d" });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  }
}

function login_(name, pin) {
  name = cleanName_(name);
  const pl = findPlayer_(name);
  if (!pl) return { ok: false, error: "No player called " + name + " — create one instead." };
  if (pl.pinHash !== hash_(pin)) return { ok: false, error: "Wrong PIN." };
  sheet_("Players", P_HEAD).getRange(pl.row, P.seen + 1).setValue(new Date());
  return { ok: true, player: publicPlayer_(pl) };
}

// ------------------------------------------------------------------------------ POST
function doPost(e) {
  const lock = LockService.getScriptLock();
  lock.waitLock(20000);
  try {
    const body = JSON.parse(e.postData.contents || "{}");
    if (body.action === "register") return json_(register_(body));
    if (body.action === "holes") return json_(holes_(body.items || []));
    return json_({ ok: false, error: "Unknown action" });
  } catch (err) {
    return json_({ ok: false, error: String(err) });
  } finally {
    lock.releaseLock();
  }
}

function register_(b) {
  const name = cleanName_(b.name);
  if (name.length < 2) return { ok: false, error: "Name needs at least 2 letters." };
  if (!/^\d{4}$/.test(String(b.pin))) return { ok: false, error: "PIN must be 4 digits." };
  if (findPlayer_(name)) return { ok: false, error: "That name is taken — sign in instead." };
  const row = [];
  row[P.name] = name; row[P.pin] = hash_(b.pin); row[P.hcap] = START_HCAP; row[P.over] = "";
  row[P.diff] = 0; row[P.rounds] = 0; row[P.created] = new Date(); row[P.seen] = new Date();
  sheet_("Players", P_HEAD).appendRow(row);
  return { ok: true, player: { name: name, hcap: START_HCAP, difficulty: 0 } };
}

/**
 * Each item is one finished hole: { roundId, course, holes, hole, strokes, pars[], recv[], bag, hcap, difficulty, ts, name, pin }.
 * The round's row is created on its first hole and filled in as the round goes.
 */
function holes_(items) {
  const sh = sheet_("Scores", S_HEAD);
  const vals = sh.getDataRange().getValues();
  const rowOf = {};
  for (let i = 1; i < vals.length; i++) rowOf[String(vals[i][S.RoundID])] = i; // index into vals
  const auth = {}, touched = {}, finished = {}, courses = {};
  let saved = 0;
  items.slice(0, 400).forEach(function (it) {
    const name = cleanName_(it.name), k = name.toLowerCase() + "|" + String(it.pin);
    if (!(k in auth)) { const pl = findPlayer_(name); auth[k] = pl && pl.pinHash === hash_(it.pin) ? pl : null; }
    const pl = auth[k];
    if (!pl) return; // unknown player or wrong PIN
    const id = String(it.roundId || "").slice(0, 40), holes = Math.min(18, Math.max(1, Number(it.holes) || 18));
    const hole = Math.round(Number(it.hole)), strokes = Math.round(Number(it.strokes));
    if (!id || !(hole >= 1 && hole <= holes) || !(strokes >= 1 && strokes <= 15)) return;
    let idx = rowOf[id];
    if (idx === undefined) {
      const r = new Array(S_HEAD.length).fill("");
      r[S.Time] = new Date(Number(it.ts) || Date.now()); r[S.Name] = pl.name; r[S.Course] = String(it.course).slice(0, 40);
      r[S.RoundID] = id; r[S.Holes] = holes; r[S.Hcap] = Number(it.hcap) || 0; r[S.Bag] = String(it.bag || "").slice(0, 40);
      r[S.Difficulty] = Number(it.difficulty) || 0; r[S.Status] = "In progress";
      r[S.Recv] = (it.recv || []).slice(0, holes).map(Number).join(",");
      vals.push(r); idx = vals.length - 1; rowOf[id] = idx;
    }
    const r = vals[idx];
    if (String(r[S.Name]).toLowerCase() !== String(pl.name).toLowerCase()) return; // someone else's round
    r[S["H" + hole]] = strokes;
    // totals
    const pars = (it.pars || []).map(Number), recv = String(r[S.Recv]).split(",").map(Number);
    const sum = function (a, b) { let t = 0; for (let h = a; h <= b; h++) { const v = num_(r[S["H" + h]]); if (v === null) return null; t += v; } return t; };
    const recvSum = function (a, b) { let t = 0; for (let h = a; h <= b; h++) t += recv[h - 1] || 0; return t; };
    if (holes >= 18) { const o = sum(1, 9), n = sum(10, 18); r[S.Out] = o === null ? "" : o; r[S.In] = n === null ? "" : n; }
    // which holes this round covers: all of them, or just the front / back nine of an 18-hole course
    const play = holes >= 18 && (it.play === "9f" || it.play === "9b") ? it.play : "18";
    const a = play === "9b" ? 10 : 1, z = play === "9f" ? 9 : holes;
    if (pars.length >= z) r[S.Par] = pars.slice(a - 1, z).reduce(function (x, y) { return x + y; }, 0);
    const tot = sum(a, z);
    if (tot !== null) {
      r[S.Total] = tot; r[S.Net] = tot - recvSum(a, z);
      r[S.Status] = play === "9f" ? "Front 9 complete" : play === "9b" ? "Back 9 complete" : "Complete";
      finished[pl.name] = true;
    }
    touched[idx] = true; courses[r[S.Course]] = true; saved++;
  });
  // write back only rows that changed
  Object.keys(touched).forEach(function (i) {
    i = Number(i);
    sh.getRange(i + 1, 1, 1, S_HEAD.length).setValues([vals[i]]);
  });
  Object.keys(finished).forEach(function (n) { updateHcap_(n, vals); });
  const cache = CacheService.getScriptCache();
  Object.keys(courses).forEach(function (c) { cache.remove("board_" + c); });
  return { ok: true, saved: saved };
}

// ------------------------------------------------------------------------------ leaderboards
function collect_(vals, course) {
  const best = { hole: {}, round: {} };
  const add = function (t, key, name, g, n) {
    const per = best[t][key] || (best[t][key] = {});
    const cur = per[name];
    if (!cur) per[name] = { g: g, n: n }; else { cur.g = Math.min(cur.g, g); cur.n = Math.min(cur.n, n); }
  };
  for (let i = 1; i < vals.length; i++) {
    const r = vals[i];
    if (course !== null && String(r[S.Course]) !== course) continue;
    const name = String(r[S.Name]), holes = Number(r[S.Holes]) || 18, recv = String(r[S.Recv]).split(",").map(Number);
    let front = 0, back = 0, all = 0, fN = 0, bN = 0, aN = 0, fOk = true, bOk = true, aOk = true;
    for (let h = 1; h <= holes; h++) {
      const v = num_(r[S["H" + h]]), rc = recv[h - 1] || 0;
      if (v === null) { aOk = false; if (h <= 9) fOk = false; else bOk = false; continue; }
      add("hole", String(h), name, v, v - rc);
      all += v; aN += v - rc;
      if (h <= 9) { front += v; fN += v - rc; } else { back += v; bN += v - rc; }
    }
    const c = course === null ? String(r[S.Course]) + "|" : "";
    if (holes >= 18) {
      if (fOk) add("round", c + "9f", name, front, fN);
      if (bOk) add("round", c + "9b", name, back, bN);
      if (aOk) add("round", c + "18", name, all, aN);
    } else if (aOk) add("round", c + String(holes), name, all, aN);
  }
  return best;
}

function board_(course) {
  const cache = CacheService.getScriptCache();
  const hit = cache.get("board_" + course);
  if (hit) return JSON.parse(hit);
  const best = collect_(sheet_("Scores", S_HEAD).getDataRange().getValues(), course);
  const toPair = function (per) {
    const names = Object.keys(per);
    const list = function (f) {
      return names.map(function (nm) { return { name: nm, score: per[nm][f] }; })
        .sort(function (a, b) { return a.score - b.score; }).slice(0, MAX_ROWS);
    };
    return { gross: list("g"), net: list("n") };
  };
  const out = { ok: true, holes: {}, rounds: {} };
  Object.keys(best.hole).forEach(function (k) { out.holes[k] = toPair(best.hole[k]); });
  Object.keys(best.round).forEach(function (k) { out.rounds[k] = toPair(best.round[k]); });
  cache.put("board_" + course, JSON.stringify(out), CACHE_SECS);
  return out;
}

/** Everyone's best per course / hole / round, written to the Bests tab for reading in Sheets. */
function rebuildBests() {
  const vals = sheet_("Scores", S_HEAD).getDataRange().getValues();
  const courses = {};
  for (let i = 1; i < vals.length; i++) courses[String(vals[i][S.Course])] = true;
  const rows = [];
  Object.keys(courses).sort().forEach(function (c) {
    const b = collect_(vals, c);
    ["round", "hole"].forEach(function (t) {
      Object.keys(b[t]).sort(function (a, z) { return (Number(a) || 99) - (Number(z) || 99) || a.localeCompare(z); }).forEach(function (k) {
        Object.keys(b[t][k]).map(function (n) { return [c, t, k, n, b[t][k][n].g, b[t][k][n].n]; })
          .sort(function (a, z) { return a[4] - z[4]; }).forEach(function (row) { rows.push(row); });
      });
    });
  });
  const sh = sheet_("Bests", ["Course", "Type", "Key", "Name", "Best gross", "Best net"]);
  if (sh.getMaxRows() > 1) sh.getRange(2, 1, sh.getMaxRows() - 1, 6).clearContent();
  if (rows.length) sh.getRange(2, 1, rows.length, 6).setValues(rows);
}
