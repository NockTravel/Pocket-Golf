import { defineConfig } from "vite";
import { viteSingleFile } from "vite-plugin-singlefile";

// base: "./" works on GitHub Pages project subpaths and anywhere else.
// viteSingleFile inlines JS/CSS into one self-contained index.html (the "engine"),
// while files in public/ (e.g. course JSON) stay separate and droppable.
export default defineConfig({
  base: "./",
  plugins: [viteSingleFile()],
  build: { target: "es2020", outDir: "dist" },
});
