// Golfer appearance: options, persistence and a tiny SVG preview.

export type HatStyle = "cap" | "bucket" | "visor" | "beanie" | "none";
export type HairStyle = "short" | "long" | "ponytail" | "bald";

export interface Look {
  hat: HatStyle; hatColor: string;
  hair: HairStyle; hairColor: string;
  shirt: string; pants: string; skin: string;
}

export const HATS: [HatStyle, string][] = [["cap", "Cap"], ["bucket", "Bucket"], ["visor", "Visor"], ["beanie", "Beanie"], ["none", "None"]];
export const HAIRS: [HairStyle, string][] = [["short", "Short"], ["long", "Long"], ["ponytail", "Ponytail"], ["bald", "Bald"]];
export const HAT_COLORS = ["#20334a", "#ffffff", "#d63c3c", "#1f9e5a", "#f2c230", "#e8732e", "#7a4fd1", "#111111"];
export const HAIR_COLORS = ["#1c1512", "#5a3820", "#a8693a", "#e2c06e", "#b5432a", "#bdbdbd", "#3a7bd5", "#e86fae"];
export const SHIRT_COLORS = ["#1f78b4", "#ffffff", "#e23b3b", "#2fae5f", "#f4c430", "#ff7a2f", "#8a5cf5", "#ff79b0", "#29c4c4", "#222831"];
export const PANTS_COLORS = ["#273544", "#c8b48a", "#f1f1f1", "#1b1b1b", "#7c838c", "#4f6b3a"];
export const SKIN_TONES = ["#f2d0b5", "#e0ac8a", "#c99a73", "#9c6b48", "#6b4430"];

export const DEFAULT_LOOK: Look = {
  hat: "cap", hatColor: "#20334a", hair: "short", hairColor: "#5a3820",
  shirt: "#1f78b4", pants: "#273544", skin: "#c99a73",
};

const KEY = "pg3d.look";
export function loadLook(): Look {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...DEFAULT_LOOK, ...JSON.parse(raw) };
  } catch { /* storage blocked */ }
  return { ...DEFAULT_LOOK };
}
export function saveLook(l: Look) {
  try { localStorage.setItem(KEY, JSON.stringify(l)); } catch { /* storage blocked */ }
}
export function randomLook(): Look {
  const pick = <T,>(a: T[]) => a[Math.floor(Math.random() * a.length)];
  return {
    hat: pick(HATS)[0], hatColor: pick(HAT_COLORS), hair: pick(HAIRS)[0], hairColor: pick(HAIR_COLORS),
    shirt: pick(SHIRT_COLORS), pants: pick(PANTS_COLORS), skin: pick(SKIN_TONES),
  };
}

/** Front-on cartoon of the golfer, matching the 3D model's blocky style. */
export function lookSVG(l: Look): string {
  const hairBack =
    l.hair === "long" ? `<rect x="35" y="30" width="50" height="42" rx="10" fill="${l.hairColor}"/>` :
    l.hair === "ponytail" ? `<path d="M80 34 q16 10 8 34 q-6 -14 -12 -20z" fill="${l.hairColor}"/>` : "";
  const hairTop = l.hair === "bald" ? "" : `<path d="M38 40 a22 22 0 0 1 44 0 l0 4 q-22 -10 -44 0z" fill="${l.hairColor}"/>`;
  const c = l.hatColor;
  const hat =
    l.hat === "cap" ? `<path d="M37 36 a23 22 0 0 1 46 0z" fill="${c}"/><rect x="50" y="33" width="38" height="6" rx="3" fill="${c}"/>` :
    l.hat === "bucket" ? `<path d="M41 34 l4 -16 h30 l4 16z" fill="${c}"/><rect x="30" y="32" width="60" height="7" rx="3.5" fill="${c}"/>` :
    l.hat === "visor" ? `<rect x="37" y="30" width="46" height="6" rx="3" fill="${c}"/><rect x="48" y="34" width="38" height="5" rx="2.5" fill="${c}"/>` :
    l.hat === "beanie" ? `<path d="M37 38 a23 24 0 0 1 46 0z" fill="${c}"/><rect x="36" y="34" width="48" height="8" rx="3" fill="${c}" style="filter:brightness(0.85)"/><circle cx="60" cy="13" r="6" fill="${c}"/>` : "";
  return `<svg viewBox="0 0 120 170" xmlns="http://www.w3.org/2000/svg">
    <ellipse cx="60" cy="163" rx="34" ry="5" fill="rgba(0,0,0,0.25)"/>
    ${hairBack}
    <rect x="44" y="118" width="32" height="42" rx="4" fill="${l.pants}"/>
    <rect x="40" y="157" width="40" height="7" rx="3" fill="#f2f2f2"/>
    <rect x="36" y="70" width="48" height="52" rx="7" fill="${l.shirt}"/>
    <rect x="24" y="74" width="12" height="40" rx="6" fill="${l.skin}"/>
    <rect x="84" y="74" width="12" height="40" rx="6" fill="${l.skin}"/>
    <circle cx="60" cy="46" r="22" fill="${l.skin}"/>
    <circle cx="52" cy="48" r="2.6" fill="#1b1b1b"/><circle cx="68" cy="48" r="2.6" fill="#1b1b1b"/>
    <path d="M53 57 q7 5 14 0" stroke="#1b1b1b" stroke-width="2" fill="none" stroke-linecap="round"/>
    ${hairTop}${hat}
  </svg>`;
}
