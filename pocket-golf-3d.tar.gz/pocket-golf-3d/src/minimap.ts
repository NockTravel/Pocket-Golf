import { Hole, pathData, FRINGE } from "./holes";
import { Theme } from "./course";

/** Small rotated hole map (tee at bottom, green at top), matching the 3D view's handedness. */
export class Minimap {
  private ctx: CanvasRenderingContext2D;
  private bg = document.createElement("canvas");
  private hole: Hole | null = null;
  private ang = 0; private s = 1; private ox = 0; private oy = 0;
  private W: number; private H: number;

  constructor(canvas: HTMLCanvasElement) {
    this.ctx = canvas.getContext("2d")!;
    this.W = canvas.width; this.H = canvas.height;
    this.bg.width = this.W; this.bg.height = this.H;
  }

  private rot(x: number, z: number) {
    const h = this.hole!, dx = x - h.tee.x, dz = z - h.tee.z, c = Math.cos(this.ang), s = Math.sin(this.ang);
    return { rx: dx * c - dz * s, rz: dx * s + dz * c };
  }
  private tf(x: number, z: number) {
    const r = this.rot(x, z);
    return { x: this.ox - r.rx * this.s, y: this.oy - r.rz * this.s };
  }

  setHole(h: Hole, t: Theme) {
    this.hole = h;
    this.ang = Math.atan2(h.green.x - h.tee.x, h.green.z - h.tee.z);
    const pd = pathData(h);
    let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
    const ext = (x: number, z: number, pad: number) => {
      const r = this.rot(x, z);
      minX = Math.min(minX, r.rx - pad); maxX = Math.max(maxX, r.rx + pad);
      minZ = Math.min(minZ, r.rz - pad); maxZ = Math.max(maxZ, r.rz + pad);
    };
    for (const p of pd.pts) ext(p.x, p.z, p.hw);
    ext(h.green.x, h.green.z, h.green.r + 4);
    ext(h.tee.x, h.tee.z, 6);
    this.s = Math.min((this.W - 18) / (maxX - minX), (this.H - 18) / (maxZ - minZ));
    this.ox = this.W / 2 + ((minX + maxX) / 2) * this.s;
    this.oy = this.H / 2 + ((minZ + maxZ) / 2) * this.s;

    const g = this.bg.getContext("2d")!;
    g.clearRect(0, 0, this.W, this.H);
    g.fillStyle = shade(t.rough, 0.62);
    g.fillRect(0, 0, this.W, this.H);
    const poly = (pts: { x: number; y: number }[], fill: string) => {
      g.beginPath(); pts.forEach((p, i) => (i ? g.lineTo(p.x, p.y) : g.moveTo(p.x, p.y))); g.closePath();
      g.fillStyle = fill; g.fill();
    };
    const ell = (cx: number, cz: number, rx: number, rz: number, fill: string) => {
      const pts = [];
      for (let i = 0; i < 24; i++) { const a = (i / 24) * Math.PI * 2; pts.push(this.tf(cx + Math.cos(a) * rx, cz + Math.sin(a) * rz)); }
      poly(pts, fill);
    };
    g.lineCap = "round"; g.lineJoin = "round"; g.strokeStyle = t.fairway;
    for (let i = 1; i < pd.pts.length; i++) {
      const a = pd.pts[i - 1], b = pd.pts[i];
      if (a.s < (h.fwStart ?? 12)) continue;
      const pa = this.tf(a.x, a.z), pb = this.tf(b.x, b.z);
      g.lineWidth = Math.max(2, a.hw * 2 * this.s);
      g.beginPath(); g.moveTo(pa.x, pa.y); g.lineTo(pb.x, pb.y); g.stroke();
    }
    if (h.plateau) for (const c of h.cliffs ?? []) ell(c.x, c.z, c.rx, c.rz, "#3a4a2c");
    for (const c of h.cross) poly([this.tf(c.xmin, c.z0), this.tf(c.xmax, c.z0), this.tf(c.xmax, c.z1), this.tf(c.xmin, c.z1)], t.water);
    for (const w of h.hazards ?? []) ell(w.x, w.z, w.rx, w.rz, "#a8914c");
    for (const w of h.water) ell(w.x, w.z, w.rx, w.rz, t.water);
    ell(h.green.x, h.green.z, h.green.r + FRINGE, h.green.r + FRINGE, t.fringe);
    ell(h.green.x, h.green.z, h.green.r, h.green.r, shade(t.green, 1.15));
    for (const b of h.bunkers) ell(b.x, b.z, b.rx, b.rz, t.sand);
    const tp = this.tf(h.tee.x, h.tee.z);
    g.fillStyle = shade(t.fairway, 1.2); g.fillRect(tp.x - 3, tp.y - 3, 6, 6);
  }

  draw(ball: { x: number; z: number }, heading: number, reach: number, showAim: boolean) {
    const h = this.hole;
    if (!h) return;
    const g = this.ctx;
    g.clearRect(0, 0, this.W, this.H);
    g.drawImage(this.bg, 0, 0);
    const b = this.tf(ball.x, ball.z);
    if (showAim) {
      const e = this.tf(ball.x + Math.sin(heading) * reach, ball.z + Math.cos(heading) * reach);
      g.strokeStyle = "#ffd166"; g.lineWidth = 2.5; g.setLineDash([5, 4]);
      g.beginPath(); g.moveTo(b.x, b.y); g.lineTo(e.x, e.y); g.stroke(); g.setLineDash([]);
      g.beginPath(); g.arc(e.x, e.y, 4.5, 0, 7); g.stroke();
    }
    const p = this.tf(h.pin.x, h.pin.z);
    g.fillStyle = "#ff5a4a"; g.beginPath(); g.arc(p.x, p.y, 4, 0, 7); g.fill();
    g.fillStyle = "#fff"; g.strokeStyle = "#0b1410"; g.lineWidth = 2;
    g.beginPath(); g.arc(b.x, b.y, 5, 0, 7); g.fill(); g.stroke();
  }
}

function shade(hex: string, k: number) {
  const v = parseInt(hex.replace("#", ""), 16);
  const c = [(v >> 16) & 255, (v >> 8) & 255, v & 255].map((x) => Math.max(0, Math.min(255, Math.round(x * k))));
  return `rgb(${c[0]},${c[1]},${c[2]})`;
}
