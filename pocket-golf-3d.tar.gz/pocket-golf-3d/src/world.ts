import * as THREE from "three";
import { Sky } from "three/addons/objects/Sky.js";
import { EffectComposer } from "three/addons/postprocessing/EffectComposer.js";
import { RenderPass } from "three/addons/postprocessing/RenderPass.js";
import { SMAAPass } from "three/addons/postprocessing/SMAAPass.js";
import { UnrealBloomPass } from "three/addons/postprocessing/UnrealBloomPass.js";
import { OutputPass } from "three/addons/postprocessing/OutputPass.js";
import {
  Hole, Ellipse, greenH, greenGrad, terrainH, groundH, buildTrees, pathData, bounds,
  WATER_LEVEL, FRINGE, waterInfluence, surfaceAt, makeRng, smoothstep, lowland, sampleHM,
} from "./holes";
import { Theme } from "./course";
import { makeWaterMaterial } from "./water";
import { Look, DEFAULT_LOOK } from "./look";
import { grassTexture, stripeTexture, sandTexture, waterNormalTexture, blobTexture } from "./textures";

const BALL_R = 0.28;
type Person = { p: THREE.Vector3; q: THREE.Quaternion; s: number; ph: number; cap: number };
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const shared = <T extends THREE.BufferGeometry>(g: T): T => { g.userData.shared = true; return g; };
const hexMix = (a: string, b: string, t: number) => "#" + new THREE.Color(a).lerp(new THREE.Color(b), t).getHexString();
const hexShift = (a: string, l: number) => "#" + new THREE.Color(a).offsetHSL(0, 0, l).getHexString();

interface Chev { x: number; z: number; dx: number; dz: number; speed: number; phase: number; }

export class World {
  renderer: THREE.WebGLRenderer;
  scene = new THREE.Scene();
  camera: THREE.PerspectiveCamera;
  high: boolean;
  private composer: EffectComposer | null = null;
  private bloom: UnrealBloomPass | null = null;
  private bloomStrength = 0.18;
  private treeDensity = 1;

  private hole!: Hole;
  private theme!: Theme;
  private holeGroup = new THREE.Group();

  private sun: THREE.DirectionalLight;
  private hemi: THREE.HemisphereLight;
  private sunDir = new THREE.Vector3();
  private sky = new Sky();
  private envSky = new Sky();
  private envScene = new THREE.Scene();
  private envRT: THREE.WebGLRenderTarget | null = null;
  private pmrem: THREE.PMREMGenerator;
  private clouds = new THREE.Group();

  private mats: Record<string, THREE.Material> = {};
  private texs: THREE.Texture[] = [];
  private waterNormal = waterNormalTexture();

  ball: THREE.Mesh;
  private ballShadow: THREE.Mesh;
  private golfer = new THREE.Group();
  private clubPivot = new THREE.Group();
  private flag = new THREE.Group();
  private clothPivot = new THREE.Group();
  private cloth: THREE.Mesh;
  private clothBase: Float32Array;
  private aimLine: THREE.Line;
  private aimRing: THREE.Mesh;
  private puttDots: THREE.InstancedMesh;
  private puttEnd: THREE.Mesh;
  private chevrons: THREE.InstancedMesh | null = null;
  private chevData: Chev[] = [];
  private puttGrid: THREE.LineSegments | null = null;
  private puttMode = false;
  private trail: THREE.Line;
  private trailPos = new Float32Array(3 * 120);
  private trailN = 0;
  private trailActive = false;
  private trailFade = 0;
  private splashes: { m: THREE.Mesh; t: number }[] = [];
  private wind = { x: 0, z: 0, mph: 0 };
  private dummy = new THREE.Object3D();

  // shared geometries / materials (overlays get a strong depth offset so they always sit on the turf)
  private chevGeo: THREE.BufferGeometry;
  private overlay = { transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -4, polygonOffsetUnits: -10 };
  private chevMat = new THREE.MeshBasicMaterial({ color: "#ffffff", opacity: 0.92, ...this.overlay });
  private gridMat = new THREE.LineBasicMaterial({ color: "#ffffff", transparent: true, opacity: 0.3, depthWrite: false });
  private geo = {
    trunk: shared(new THREE.CylinderGeometry(0.28, 0.42, 1, 6)),
    cone: shared(new THREE.ConeGeometry(1, 1, 8)),
    blob: shared(new THREE.IcosahedronGeometry(1, 1)),
    body: shared(new THREE.BoxGeometry(0.62, 1.15, 0.4)),
    head: shared(new THREE.SphereGeometry(0.24, 10, 8)),
    cap: shared(new THREE.CylinderGeometry(0.26, 0.26, 0.12, 10)),
    marker: shared(new THREE.SphereGeometry(0.28, 12, 8)),
    splash: shared(new THREE.RingGeometry(0.55, 0.85, 32).rotateX(-Math.PI / 2)),
  };

  /** Safe mode: for GPUs/drivers that mishandle half-float render targets (e.g. some Mali/Pixel phones) —
   *  no PMREM environment lighting, no post-processing, basic shadows, capped resolution. */
  readonly safe: boolean;
  constructor(canvas: HTMLCanvasElement, high: boolean, safe = false) {
    this.safe = safe;
    if (safe) high = false;
    this.high = high;
    this.treeDensity = high ? 1 : 0.6;
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: !safe, precision: "highp", powerPreference: safe ? "default" : "high-performance" });
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, safe ? 1 : high ? 2 : 1.3));
    if (safe) this.treeDensity = 0.45;
    this.renderer.shadowMap.enabled = !safe;
    this.renderer.shadowMap.type = safe ? THREE.PCFShadowMap : THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;

    this.scene.fog = new THREE.Fog("#c9dde8", 320, 1300);
    this.camera = new THREE.PerspectiveCamera(60, 1, 0.4, 14000);

    this.hemi = new THREE.HemisphereLight("#dbecff", "#4a6a40", safe ? 1.6 : 0.6);
    this.scene.add(this.hemi);
    this.sun = new THREE.DirectionalLight("#fff4df", 2.5);
    this.sun.castShadow = !safe;
    this.sun.shadow.mapSize.set(high ? 2048 : 1024, high ? 2048 : 1024);
    this.sun.shadow.bias = -0.0004;
    this.sun.shadow.normalBias = 0.6;
    const sc = this.sun.shadow.camera as THREE.OrthographicCamera;
    sc.left = -85; sc.right = 85; sc.top = 85; sc.bottom = -85; sc.near = 1; sc.far = 450;
    this.scene.add(this.sun, this.sun.target);

    this.sky.scale.setScalar(12000);
    this.envSky.scale.setScalar(12000);
    this.scene.add(this.sky);
    this.envScene.add(this.envSky);
    this.pmrem = new THREE.PMREMGenerator(this.renderer);

    this.scene.add(this.holeGroup);
    this.buildClouds();

    // ball
    this.ball = new THREE.Mesh(new THREE.SphereGeometry(BALL_R, 24, 18),
      new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.3, envMapIntensity: 1 }));
    this.ball.castShadow = true;
    this.scene.add(this.ball);
    this.ballShadow = new THREE.Mesh(new THREE.CircleGeometry(0.45, 16).rotateX(-Math.PI / 2),
      new THREE.MeshBasicMaterial({ color: "#000", opacity: 0.25, ...this.overlay }));
    this.scene.add(this.ballShadow);

    this.buildGolfer();
    this.setLook(DEFAULT_LOOK);
    this.scene.add(this.golfer);

    // flag with waving cloth
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.045, 0.045, 3.6, 6), new THREE.MeshStandardMaterial({ color: "#f4f4f4", roughness: 0.4 }));
    pole.position.y = 1.8; pole.castShadow = true;
    const clothGeo = new THREE.PlaneGeometry(1.5, 0.95, 14, 2).translate(0.75, 0, 0);
    this.clothBase = new Float32Array(clothGeo.attributes.position.array);
    this.cloth = new THREE.Mesh(clothGeo, new THREE.MeshStandardMaterial({ color: "#ff5a4a", side: THREE.DoubleSide, roughness: 0.85 }));
    this.cloth.position.y = 3.1; this.cloth.castShadow = true;
    this.clothPivot.add(this.cloth);
    const cup = new THREE.Mesh(new THREE.CircleGeometry(0.3, 20).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: "#0b100c" }));
    cup.position.y = 0.075;
    const liner = new THREE.Mesh(new THREE.RingGeometry(0.3, 0.36, 24).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: "#f2f2f2" }));
    liner.position.y = 0.074;
    this.flag.add(pole, this.clothPivot, cup, liner);
    this.scene.add(this.flag);

    // aim helpers
    const lg = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
    this.aimLine = new THREE.Line(lg, new THREE.LineDashedMaterial({ color: "#ffffff", dashSize: 2.5, gapSize: 1.6, transparent: true, opacity: 0.85 }));
    this.scene.add(this.aimLine);
    this.aimRing = new THREE.Mesh(new THREE.RingGeometry(2.0, 2.6, 48).rotateX(-Math.PI / 2),
      new THREE.MeshBasicMaterial({ color: "#ffd166", opacity: 0.85, ...this.overlay }));
    this.scene.add(this.aimRing);

    this.puttDots = new THREE.InstancedMesh(new THREE.CircleGeometry(0.17, 12).rotateX(-Math.PI / 2),
      new THREE.MeshBasicMaterial({ color: "#ffffff", opacity: 0.95, ...this.overlay }), 160);
    this.puttDots.count = 0; this.puttDots.frustumCulled = false;
    this.scene.add(this.puttDots);
    this.puttEnd = new THREE.Mesh(new THREE.RingGeometry(0.4, 0.62, 28).rotateX(-Math.PI / 2),
      new THREE.MeshBasicMaterial({ color: "#ffd166", opacity: 0.95, ...this.overlay }));
    this.puttEnd.visible = false;
    this.scene.add(this.puttEnd);

    // chevron (points along +z after rotation)
    const s = new THREE.Shape();
    s.moveTo(-0.5, 0.3); s.lineTo(0, -0.18); s.lineTo(0.5, 0.3); s.lineTo(0.5, 0.02); s.lineTo(0, -0.5); s.lineTo(-0.5, 0.02); s.closePath();
    this.chevGeo = shared(new THREE.ShapeGeometry(s).rotateX(-Math.PI / 2).scale(1.5, 1, 1.5));

    const tg = new THREE.BufferGeometry();
    tg.setAttribute("position", new THREE.BufferAttribute(this.trailPos, 3));
    tg.setDrawRange(0, 0);
    this.trail = new THREE.Line(tg, new THREE.LineBasicMaterial({ color: "#ffffff", transparent: true, opacity: 0.6, depthWrite: false }));
    this.trail.frustumCulled = false;
    this.scene.add(this.trail);

    if (high) this.setupComposer();
    this.resize();
  }

  // ------------------------------------------------------------ setup
  private setupComposer() {
    const w = innerWidth, h = innerHeight;
    this.composer = new EffectComposer(this.renderer);
    this.composer.addPass(new RenderPass(this.scene, this.camera));
    this.composer.addPass(new SMAAPass(w, h));
    this.bloom = new UnrealBloomPass(new THREE.Vector2(w, h), 0.18, 0.5, 0.93);
    this.bloom.strength = this.bloomStrength;
    this.composer.addPass(this.bloom);
    this.composer.addPass(new OutputPass());
  }

  setQuality(high: boolean) {
    if (this.safe) high = false;
    this.high = high;
    this.treeDensity = this.safe ? 0.45 : high ? 1 : 0.6;
    this.renderer.setPixelRatio(Math.min(devicePixelRatio, this.safe ? 1 : high ? 2 : 1.3));
    const ms = high ? 2048 : 1024;
    if (this.sun.shadow.mapSize.x !== ms) {
      this.sun.shadow.mapSize.set(ms, ms);
      this.sun.shadow.map?.dispose();
      (this.sun.shadow as unknown as { map: null }).map = null;
    }
    if (high && !this.composer) this.setupComposer();
    if (!high && this.composer) { this.composer.dispose(); this.composer = null; }
    this.resize();
  }

  resize() {
    const w = innerWidth, h = innerHeight;
    this.renderer.setSize(w, h, false);
    this.camera.aspect = w / h;
    this.camera.fov = w < h ? 70 : 55;
    this.camera.updateProjectionMatrix();
    this.composer?.setSize(w, h);
  }

  private buildClouds() {
    const tex = blobTexture();
    const R = makeRng(42);
    for (let i = 0; i < 16; i++) {
      const a = R() * Math.PI * 2, d = 900 + R() * 700, y = 170 + R() * 120;
      for (let k = 0; k < 4; k++) {
        const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, fog: false, opacity: 0.75 + R() * 0.2 }));
        sp.position.set(Math.cos(a) * d + (R() - 0.5) * 120, y + (R() - 0.5) * 25, 250 + Math.sin(a) * d + (R() - 0.5) * 60);
        const s = 140 + R() * 120;
        sp.scale.set(s * 1.8, s * 0.7, 1);
        this.clouds.add(sp);
      }
    }
    this.scene.add(this.clouds);
  }

  private golferBody = new THREE.Group();
  private crowd: { bodies: THREE.InstancedMesh; heads: THREE.InstancedMesh; caps: THREE.InstancedMesh; people: Person[] } | null = null;
  private react: { kind: "cheer" | "clap" | "groan"; t: number } | null = null;
  /** Gallery reaction: cheer = jumping, clap = polite bounce, groan = heads drop. */
  crowdReact(kind: "cheer" | "clap" | "groan") { this.react = { kind, t: 0 }; }
  private updateCrowd(dt: number) {
    const C = this.crowd, r = this.react;
    if (!C || !r) return;
    r.t += dt;
    const dur = r.kind === "cheer" ? 3.2 : r.kind === "clap" ? 2.2 : 2.6;
    const fade = Math.max(0, 1 - r.t / dur);
    const m = new THREE.Matrix4(), v = new THREE.Vector3(), q2 = new THREE.Quaternion(), tilt = new THREE.Quaternion(), one = new THREE.Vector3(1, 1, 1);
    const fwd = new THREE.Vector3();
    C.people.forEach((P, i) => {
      let dy = 0, lean = 0, squash = 1;
      if (r.kind === "cheer") dy = Math.max(0, Math.sin(r.t * 10 + P.ph)) * 0.55 * Math.min(1, fade * 1.6);
      else if (r.kind === "clap") dy = Math.abs(Math.sin(r.t * 14 + P.ph)) * 0.08 * fade;
      else { const k = Math.min(1, r.t * 3) * Math.min(1, fade * 2); lean = 0.35 * k; squash = 1 - 0.06 * k; }
      tilt.setFromAxisAngle(fwd.set(1, 0, 0), lean);
      q2.copy(P.q).multiply(tilt);
      const bodyY = P.p.y + dy - (1 - squash) * 0.6;
      m.compose(v.set(P.p.x, bodyY, P.p.z), q2, new THREE.Vector3(P.s, P.s * squash, P.s)); C.bodies.setMatrixAt(i, m);
      // head follows the lean forward
      const hx = Math.sin(lean) * 0.8, hy = 0.83 * P.s * squash;
      const f = new THREE.Vector3(0, 0, 1).applyQuaternion(P.q);
      m.compose(v.set(P.p.x + f.x * hx, bodyY + hy, P.p.z + f.z * hx), q2, one); C.heads.setMatrixAt(i, m);
      if (P.cap >= 0) { m.compose(v.set(P.p.x + f.x * hx * 1.1, bodyY + hy + 0.19, P.p.z + f.z * hx * 1.1), q2, one); C.caps.setMatrixAt(P.cap, m); }
    });
    C.bodies.instanceMatrix.needsUpdate = true; C.heads.instanceMatrix.needsUpdate = true; C.caps.instanceMatrix.needsUpdate = true;
    if (fade <= 0) this.react = null;
  }
  private armMat = new THREE.MeshStandardMaterial({ color: "#c99a73", roughness: 0.9 });
  /** Rebuild the golfer's body, hair and hat from an appearance (club + arms are kept). */
  setLook(l: Look) {
    const g = this.golferBody;
    for (const c of [...g.children]) { g.remove(c); (c as THREE.Mesh).geometry?.dispose(); ((c as THREE.Mesh).material as THREE.Material)?.dispose(); }
    const std = (c: string, r = 0.8) => new THREE.MeshStandardMaterial({ color: c, roughness: r });
    const add = (geo: THREE.BufferGeometry, mat: THREE.Material, x: number, y: number, z: number, rx = 0) => {
      const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.rotation.x = rx; m.castShadow = true; g.add(m); return m;
    };
    add(new THREE.BoxGeometry(0.7, 1.05, 0.42), std(l.pants), 0, 0.55, 0);
    add(new THREE.BoxGeometry(0.78, 0.14, 0.62), std("#f2f2f2", 0.5), 0, 0.07, 0);
    add(new THREE.BoxGeometry(0.86, 1.05, 0.55), std(l.shirt), 0, 1.58, 0);
    add(new THREE.BoxGeometry(0.5, 0.1, 0.57), std(l.shirt, 0.6), 0, 2.08, 0); // collar
    add(new THREE.SphereGeometry(0.4, 16, 12), std(l.skin, 0.9), 0, 2.36, 0);
    const eye = std("#1b1b1b", 0.4);
    for (const sx of [-0.13, 0.13]) add(new THREE.SphereGeometry(0.045, 8, 6), eye, sx, 2.4, 0.37);
    this.armMat.color.set(l.skin);
    const hm = std(l.hairColor, 0.95);
    if (l.hair !== "bald") {
      const top = add(new THREE.SphereGeometry(0.42, 16, 10, 0, Math.PI * 2, 0, Math.PI * 0.42), hm, 0, 2.38, -0.03);
      top.rotation.x = -0.25;
      add(new THREE.SphereGeometry(0.415, 14, 10, Math.PI * 0.6, Math.PI * 0.8, Math.PI * 0.3, Math.PI * 0.35), hm, 0, 2.36, 0);
      if (l.hair === "long") add(new THREE.BoxGeometry(0.74, 0.75, 0.22), hm, 0, 2.08, -0.28);
      if (l.hair === "ponytail") {
        add(new THREE.SphereGeometry(0.13, 10, 8), hm, 0, 2.42, -0.46);
        add(new THREE.CylinderGeometry(0.1, 0.05, 0.55, 8), hm, 0, 2.12, -0.5, 0.25);
      }
    }
    const hc = std(l.hatColor, 0.6);
    if (l.hat === "cap") {
      add(new THREE.SphereGeometry(0.425, 16, 8, 0, Math.PI * 2, 0, Math.PI / 2), hc, 0, 2.42, 0);
      add(new THREE.BoxGeometry(0.46, 0.05, 0.36), hc, 0, 2.44, 0.42);
    } else if (l.hat === "bucket") {
      add(new THREE.CylinderGeometry(0.34, 0.43, 0.34, 16), hc, 0, 2.62, 0);
      add(new THREE.CylinderGeometry(0.62, 0.64, 0.04, 20), hc, 0, 2.46, 0);
    } else if (l.hat === "visor") {
      add(new THREE.TorusGeometry(0.405, 0.055, 6, 24), hc, 0, 2.5, 0, Math.PI / 2);
      add(new THREE.BoxGeometry(0.5, 0.05, 0.38), hc, 0, 2.49, 0.43);
    } else if (l.hat === "beanie") {
      add(new THREE.SphereGeometry(0.435, 16, 8, 0, Math.PI * 2, 0, Math.PI * 0.55), hc, 0, 2.4, 0);
      add(new THREE.CylinderGeometry(0.44, 0.44, 0.14, 18), std(l.hatColor, 0.9), 0, 2.4, 0);
      add(new THREE.SphereGeometry(0.12, 10, 8), hc, 0, 2.87, 0);
    }
  }

  private buildGolfer() {
    this.golfer.add(this.golferBody);
    this.clubPivot.position.set(0, 1.95, 0.2);
    const arms = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.9, 6), this.armMat);
    arms.position.y = -0.45;
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(0.035, 0.035, 2.6, 6), new THREE.MeshStandardMaterial({ color: "#d9e2dd", metalness: 0.6, roughness: 0.3 }));
    shaft.position.y = -2.1;
    const head2 = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.12, 0.42), new THREE.MeshStandardMaterial({ color: "#333", metalness: 0.7, roughness: 0.3 }));
    head2.position.set(0, -3.38, 0.12);
    for (const m of [arms, shaft, head2]) { m.castShadow = true; this.clubPivot.add(m); }
    this.golfer.add(this.clubPivot);
  }

  // ------------------------------------------------------------ theme
  setTheme(t: Theme) {
    this.theme = t;
    for (const tx of this.texs) tx.dispose();
    this.texs = [];
    for (const m of Object.values(this.mats)) m.dispose();
    this.mats = {};

    const rough = grassTexture(t.rough, 3, 256, 0.2);
    const cut = grassTexture(hexMix(t.rough, t.fairway, 0.55), 5, 256, 0.14);
    const fw = stripeTexture(t.fairway, t.fairway2, 7);
    const grn = stripeTexture(hexShift(t.green, 0.035), hexShift(t.green, -0.03), 11, 256, 0.06);
    const fringe = grassTexture(t.fringe, 13, 256, 0.12);
    const sand = sandTexture(t.sand, 17);
    this.texs.push(rough, cut, fw, grn, fringe, sand);

    // small, layered depth offsets: ground < cut < fairway < fringe < green < sand  (overlays sit above all)
    const off = (f: number, u: number) => ({ polygonOffset: true, polygonOffsetFactor: -f, polygonOffsetUnits: -u });
    const std = (o: THREE.MeshStandardMaterialParameters) => new THREE.MeshStandardMaterial(o);
    const DS = THREE.DoubleSide;
    this.mats.ground = std({ map: rough, vertexColors: true, roughness: 1, envMapIntensity: 0.35 });
    this.mats.cut = std({ map: cut, roughness: 1, envMapIntensity: 0.4, side: DS, ...off(0.5, 1) });
    this.mats.fairway = std({ map: fw, roughness: 0.92, envMapIntensity: 0.45, side: DS, ...off(0.75, 2) });
    this.mats.tee = std({ map: grn, roughness: 0.85, envMapIntensity: 0.45, side: DS, ...off(0.75, 2) });
    this.mats.fringe = std({ map: fringe, roughness: 0.9, envMapIntensity: 0.45, side: DS, ...off(0.75, 3) });
    this.mats.green = std({ map: grn, vertexColors: true, roughness: 0.75, envMapIntensity: 0.55, side: DS, ...off(1, 4) });
    this.mats.sand = std({ map: sand, vertexColors: true, roughness: 1, envMapIntensity: 0.4, side: DS, ...off(1, 5) });
    const deep = new THREE.Color(t.water).multiplyScalar(0.55);
    const shallow = new THREE.Color(t.water).lerp(new THREE.Color("#4f9c84"), 0.6).multiplyScalar(0.8);
    this.mats.water = makeWaterMaterial({
      normal: this.waterNormal, sunDir: this.sunDir,
      deep: "#" + deep.getHexString(), shallow: "#" + shallow.getHexString(),
      skyTop: "#5d93d6", horizon: t.fog,
    });
    this.mats.trunk = std({ color: "#5d4129", roughness: 1 });
    this.mats.leaf = std({ color: "#ffffff", roughness: 0.95, envMapIntensity: 0.45, flatShading: true });
    this.mats.backdrop = std({ vertexColors: true, roughness: 1, envMapIntensity: 0.3, flatShading: true, side: DS });
    this.mats.crowd = std({ color: "#ffffff", roughness: 0.9 });
    this.mats.skin = std({ color: "#c99a73", roughness: 0.9 });
    this.mats.marker = std({ color: "#e8433a", roughness: 0.5 });

    (this.scene.fog as THREE.Fog).color.set(t.fog);
    this.hemi.groundColor.set(t.rough);
    this.updateSky();
  }

  /** 0 = sunrise (first hole) … 0.5 = midday … 1 = sunset (last hole). */
  private tod = -1;
  setTimeOfDay(f: number) {
    if (Math.abs(f - this.tod) < 1e-4) return;
    this.tod = f;
    this.updateSky();
  }
  private sunAngles() {
    const t = this.theme;
    if (this.tod < 0) return { elev: t.sunElevation, az: t.sunAzimuth };
    const peak = clamp(t.sunElevation + 10, 30, 46);
    const elev = 2.5 + (peak - 2.5) * Math.pow(Math.sin(Math.PI * clamp(this.tod, 0, 1)), 0.85);
    return { elev, az: t.sunAzimuth + (this.tod - 0.5) * 150 };
  }
  private updateSky() {
    const t = this.theme;
    const { elev, az } = this.sunAngles();
    this.sunDir.setFromSphericalCoords(1, THREE.MathUtils.degToRad(90 - elev), THREE.MathUtils.degToRad(az));
    for (const s of [this.sky, this.envSky]) {
      const u = s.material.uniforms;
      const lw = 1 - smoothstep(3, 30, elev); // low-sun factor: hazier, redder sky
      u.turbidity.value = t.turbidity + 7 * lw; u.rayleigh.value = t.rayleigh + 2.4 * lw;
      u.mieCoefficient.value = 0.005 + 0.012 * lw; u.mieDirectionalG.value = 0.82 + 0.1 * lw;
      u.sunPosition.value.copy(this.sunDir);
    }
    if (!this.safe) {
      this.envRT?.dispose();
      this.envRT = this.pmrem.fromScene(this.envScene);
      this.scene.environment = this.envRT.texture;
    }
    // golden light, warm haze and softer sky light as the sun gets low
    const w = 1 - smoothstep(3, 30, elev);
    this.sun.color.set("#fff4df").lerp(new THREE.Color("#ff9446"), w * 0.9);
    this.sun.intensity = 2.6 - 1.15 * w;
    this.hemi.color.set("#dbecff").lerp(new THREE.Color("#ffb98f"), w * 0.65);
    this.hemi.intensity = (this.safe ? 1.6 : 0.6) * (1 - 0.3 * w);
    const fog = new THREE.Color(t.fog).lerp(new THREE.Color("#eea877"), w * 0.8);
    (this.scene.fog as THREE.Fog).color.copy(fog);
    this.renderer.toneMappingExposure = 1.05 + 0.08 * w - 0.08 * smoothstep(30, 50, elev);
    // a high sun turns the sky near-white: tone down its reflected light so the scene keeps contrast
    this.bloomStrength = 0.2 * (1 - 0.75 * smoothstep(20, 42, elev));
    if (this.bloom) this.bloom.strength = this.bloomStrength;
    (this.scene as unknown as { environmentIntensity: number }).environmentIntensity = 1 - 0.6 * smoothstep(12, 42, elev);
    const wm = this.mats.water as THREE.ShaderMaterial | undefined;
    if (wm?.uniforms) { wm.uniforms.uHorizon.value.copy(fog); wm.uniforms.uSunColor.value.copy(this.sun.color).multiplyScalar(1.1); }
  }

  // ------------------------------------------------------------ hole
  groundAt(x: number, z: number) { return groundH(this.hole, x, z); }

  private disposeGroup(g: THREE.Group) {
    g.traverse((o) => {
      if (o instanceof THREE.InstancedMesh) o.dispose();
      const geo = (o as THREE.Mesh).geometry as THREE.BufferGeometry | undefined;
      if (geo && !geo.userData.shared) geo.dispose();
      const mat = (o as THREE.Mesh).material as THREE.Material | undefined;
      if (mat && !Array.isArray(mat) && mat.userData.own) mat.dispose();
    });
    g.clear();
  }

  loadHole(h: Hole) {
    this.hole = h;
    this.crowd = null; this.react = null;
    this.disposeGroup(this.holeGroup);
    const g = this.holeGroup;
    g.add(this.buildGround(h));
    g.add(this.buildRibbon(h, 2.6, 0.03, this.mats.cut));
    g.add(this.buildRibbon(h, 0, 0.055, this.mats.fairway));
    g.add(this.buildTeeBox(h));
    g.add(this.buildFringe(h));
    g.add(this.buildGreen(h));
    for (const b of h.bunkers) g.add(this.buildBunker(h, b));
    const wm = this.buildWater(h);
    if (wm) g.add(wm);
    if (h.houses?.length) g.add(this.buildHouses(h));
    if (h.hazards?.length) g.add(this.buildTussocks(h));
    if (h.roads?.length) for (const r of h.roads) g.add(this.buildRoad(h, r));
    g.add(this.buildTrees(h));
    g.add(this.buildCrowd(h));
    g.add(this.buildBackdrop(h));
    if (this.theme.peaks) g.add(this.buildPeaks(h));
    this.chevrons = this.buildChevrons(h);
    g.add(this.chevrons);
    this.puttGrid = this.buildPuttGrid(h);
    g.add(this.puttGrid);

    this.flag.position.set(h.pin.x, groundH(h, h.pin.x, h.pin.z), h.pin.z);
    this.puttDots.count = 0;
    this.puttEnd.visible = false;
    this.trailN = 0; this.trail.geometry.setDrawRange(0, 0); this.trail.visible = false;
    this.setPuttMode(this.puttMode);
  }

  private buildGround(h: Hole): THREE.Mesh {
    const bb = bounds(h), fine = 170;
    const axis = (a: number, b: number) => {
      const out: number[] = [];
      // 3-yd cells across the playing area so the ground follows the fairway rolls; 5-yd further out
      for (let v = a; v < b; v += (v > a + 130 && v < b - 130) ? 3 : 5) out.push(v);
      out.push(b);
      const outer: number[] = [];
      let step = 20, v = a;
      while (v > a - 4000) { v -= step; step *= 1.55; outer.unshift(v); }
      const outer2: number[] = [];
      step = 20; v = b;
      while (v < b + 4000) { v += step; step *= 1.55; outer2.push(v); }
      return [...outer, ...out, ...outer2];
    };
    const xs = axis(bb.minX - fine, bb.maxX + fine), zs = axis(bb.minZ - fine, bb.maxZ + fine);
    const nz = zs.length;
    const pos: number[] = [], col: number[] = [], uv: number[] = [], idx: number[] = [];
    const g = h.green;
    for (const x of xs) {
      for (const z of zs) {
        let y = terrainH(h, x, z);
        const dg = Math.hypot(x - g.x, z - g.z);
        if (dg < g.r - 1.5) y -= 0.7;
        for (const b of h.bunkers) if (((x - b.x) / b.rx) ** 2 + ((z - b.z) / b.rz) ** 2 < 0.72) { y -= 0.45; break; }
        pos.push(x, y, z);
        const f = clamp(0.86 + (h.hmap ? 0 : 0.06 * (y - (h.plateau ?? 0))) + 0.05 * Math.sin(x * 0.06) * Math.cos(z * 0.045), 0.7, 1.1);
        // steep faces become rock: tint the grass texture toward brown-grey
        let rock = 0;
        if (h.plateau) {
          const e = 1.2, sl = Math.hypot(terrainH(h, x + e, z) - terrainH(h, x - e, z), terrainH(h, x, z + e) - terrainH(h, x, z - e)) / (2 * e);
          rock = smoothstep(0.55, 1.1, sl);
        }
        const strata = (0.78 + 0.2 * Math.sin(y * 3.1 + x * 0.04 + z * 0.03)) * (0.92 + 0.08 * Math.sin(x * 0.7 + z * 0.9));
        let hz = 0; // native grass hazards: golden tussock tint
        if (h.hazards) for (const w of h.hazards) hz = Math.max(hz, 1 - smoothstep(0.85, 1.05, Math.hypot((x - w.x) / w.rx, (z - w.z) / w.rz)));
        const cr = lerp(f, 1.95 * strata, rock), cg = lerp(f, 0.92 * strata, rock), cb = lerp(f * 0.98, 1.95 * strata, rock);
        col.push(lerp(cr, f * 1.45, hz), lerp(cg, f * 1.12, hz), lerp(cb, f * 0.55, hz));
        uv.push(x / 9, z / 9);
      }
    }
    for (let i = 0; i < xs.length - 1; i++) for (let j = 0; j < nz - 1; j++) {
      const a = i * nz + j, b = (i + 1) * nz + j, c = i * nz + j + 1, d = (i + 1) * nz + j + 1;
      idx.push(a, c, b, b, c, d);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute("color", new THREE.Float32BufferAttribute(col, 3));
    geo.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
    geo.setIndex(idx); geo.computeVertexNormals();
    const m = new THREE.Mesh(geo, this.mats.ground);
    m.receiveShadow = true;
    return m;
  }

  private buildRibbon(h: Hole, extra: number, yOff: number, mat: THREE.Material): THREE.Mesh {
    const pd = pathData(h), cols = 13;
    const pos: number[] = [], uv: number[] = [], idx: number[] = [];
    let row = 0, prev = false;
    const start = (h.fwStart ?? 12) - (extra > 0 ? 4 : 0);
    for (const p of pd.pts) {
      const dg = Math.hypot(p.x - h.green.x, p.z - h.green.z);
      const inc = p.s >= start && dg > h.green.r + 1.2 && waterInfluence(h, p.x, p.z) < 0.35;
      if (!inc) { prev = false; continue; }
      const hw = p.hw + extra, base = row * cols;
      // on clifftop holes, pull each side of the ribbon back from the cliff edge
      const side = (sg: number) => {
        let w = hw;
        if (h.plateau) while (w > 1 && lowland(h, p.x + p.nx * w * sg, p.z + p.nz * w * sg) > 0.01) w -= 0.75;
        return w;
      };
      const wl = side(-1), wr = side(1);
      for (let c = 0; c < cols; c++) {
        const f = (c / (cols - 1)) * 2 - 1;
        const ww = f < 0 ? wl : wr;
        const x = p.x + p.nx * ww * f, z = p.z + p.nz * ww * f;
        pos.push(x, terrainH(h, x, z) + yOff, z);
        uv.push(((f + 1) * hw) / 9, p.s / 24);
      }
      if (prev) for (let c = 0; c < cols - 1; c++) {
        const a = base - cols + c, b = a + 1, cc = base + c, d = cc + 1;
        idx.push(a, cc, b, b, cc, d);
      }
      row++; prev = true;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
    geo.setIndex(idx); geo.computeVertexNormals();
    const m = new THREE.Mesh(geo, mat);
    m.receiveShadow = true;
    return m;
  }

  private buildTeeBox(h: Hole): THREE.Group {
    const grp = new THREE.Group();
    const pd = pathData(h), p0 = pd.pts[0], p1 = pd.pts[Math.min(3, pd.pts.length - 1)];
    let tx = p1.x - p0.x, tz = p1.z - p0.z;
    const l = Math.hypot(tx, tz) || 1; tx /= l; tz /= l;
    const nx = tz, nz = -tx, cx = h.tee.x - tx * 1.5, cz = h.tee.z - tz * 1.5;
    const pts: number[] = [], uv: number[] = [], ti: number[] = [], NA = 5, NB = 7;
    for (let j = 0; j < NB; j++) for (let i = 0; i < NA; i++) {
      const a = -4 + 8 * i / (NA - 1), b = -6 + 12 * j / (NB - 1);
      const x = cx + nx * a + tx * b, z = cz + nz * a + tz * b;
      pts.push(x, terrainH(h, x, z) + 0.07, z); uv.push(x / 3.5, z / 3.5);
    }
    for (let j = 0; j < NB - 1; j++) for (let i = 0; i < NA - 1; i++) {
      const a = j * NA + i, b = a + 1, c = a + NA, d = c + 1;
      ti.push(a, c, b, b, c, d);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(pts, 3));
    geo.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
    geo.setIndex(ti); geo.computeVertexNormals();
    const box = new THREE.Mesh(geo, this.mats.tee);
    box.receiveShadow = true;
    grp.add(box);
    for (const side of [-1.8, 1.8]) {
      const mk = new THREE.Mesh(this.geo.marker, this.mats.marker);
      const x = h.tee.x + nx * side + tx * 1.2, z = h.tee.z + nz * side + tz * 1.2;
      mk.position.set(x, terrainH(h, x, z) + 0.3, z); mk.castShadow = true;
      grp.add(mk);
    }
    return grp;
  }

  private polar(cx: number, cz: number, radii: number[], segs: number, yAt: (x: number, z: number) => number,
    colAt?: (x: number, z: number, ri: number) => number, uvScale = 3.5): THREE.BufferGeometry {
    const pos: number[] = [], uv: number[] = [], col: number[] = [], idx: number[] = [];
    const startCenter = radii[0] === 0;
    if (startCenter) {
      pos.push(cx, yAt(cx, cz), cz); uv.push(cx / uvScale, cz / uvScale);
      const c = colAt ? colAt(cx, cz, 0) : 1; col.push(c, c, c);
    }
    const ringStart = startCenter ? 1 : 0;
    for (let ri = ringStart; ri < radii.length; ri++) {
      const r = radii[ri];
      for (let s = 0; s < segs; s++) {
        const a = (s / segs) * Math.PI * 2, x = cx + Math.cos(a) * r, z = cz + Math.sin(a) * r;
        pos.push(x, yAt(x, z), z); uv.push(x / uvScale, z / uvScale);
        const c = colAt ? colAt(x, z, ri) : 1; col.push(c, c, c);
      }
    }
    const off = startCenter ? 1 : 0;
    if (startCenter) for (let s = 0; s < segs; s++) idx.push(0, off + s, off + ((s + 1) % segs));
    const rings = radii.length - ringStart;
    for (let r = 0; r < rings - 1; r++) for (let s = 0; s < segs; s++) {
      const a = off + r * segs + s, b = off + r * segs + ((s + 1) % segs), c = a + segs, d = b + segs;
      idx.push(a, c, b, b, c, d);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
    if (colAt) geo.setAttribute("color", new THREE.Float32BufferAttribute(col, 3));
    geo.setIndex(idx); geo.computeVertexNormals();
    return geo;
  }

  private buildGreen(h: Hole): THREE.Mesh {
    const g = h.green, radii: number[] = [0];
    for (let r = 0.8; r < g.r; r += 0.8) radii.push(r);
    radii.push(g.r);
    const geo = this.polar(g.x, g.z, radii, 64, (x, z) => groundH(h, x, z) + 0.06,
      (x, z) => clamp(0.86 + 0.24 * clamp((greenH(h, x, z) + 0.8) / 1.6, 0, 1), 0.8, 1.12), 3.5);
    const m = new THREE.Mesh(geo, this.mats.green);
    m.receiveShadow = true;
    return m;
  }

  private buildFringe(h: Hole): THREE.Mesh {
    const g = h.green;
    const geo = this.polar(g.x, g.z, [g.r - 0.5, g.r + 0.8, g.r + FRINGE], 64, (x, z) => groundH(h, x, z) + 0.055, undefined, 6);
    const m = new THREE.Mesh(geo, this.mats.fringe);
    m.receiveShadow = true;
    return m;
  }

  private buildBunker(h: Hole, b: Ellipse): THREE.Mesh {
    // polar in normalized ellipse space
    const pos: number[] = [], uv: number[] = [], col: number[] = [], idx: number[] = [];
    const rings = [0, 0.35, 0.6, 0.8, 0.92, 1.0], segs = 40;
    for (let ri = 0; ri < rings.length; ri++) {
      const n = rings[ri], count = ri === 0 ? 1 : segs;
      for (let s = 0; s < count; s++) {
        const a = (s / segs) * Math.PI * 2, x = b.x + Math.cos(a) * b.rx * n, z = b.z + Math.sin(a) * b.rz * n;
        pos.push(x, terrainH(h, x, z) + 0.08, z); uv.push(x / 5, z / 5);
        const f = 1.04 - 0.26 * n * n; col.push(f, f, f);
      }
    }
    for (let s = 0; s < segs; s++) idx.push(0, 1 + s, 1 + ((s + 1) % segs));
    for (let r = 1; r < rings.length - 1; r++) for (let s = 0; s < segs; s++) {
      const a = 1 + (r - 1) * segs + s, bb = 1 + (r - 1) * segs + ((s + 1) % segs), c = a + segs, d = bb + segs;
      idx.push(a, c, bb, bb, c, d);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
    geo.setAttribute("color", new THREE.Float32BufferAttribute(col, 3));
    geo.setIndex(idx); geo.computeVertexNormals();
    const m = new THREE.Mesh(geo, this.mats.sand);
    m.receiveShadow = true;
    return m;
  }

  private flatGeo(pts: number[][], tris: number[]): THREE.BufferGeometry {
    const h = this.hole!, pos: number[] = [], dep: number[] = [];
    for (const [x, z] of pts) { pos.push(x, WATER_LEVEL, z); dep.push(WATER_LEVEL - groundH(h, x, z)); }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute("depth", new THREE.Float32BufferAttribute(dep, 1));
    geo.setIndex(tris);
    return geo;
  }
  /** One grid mesh for all of a hole's water (handles chains of lake circles without overlap artefacts). */
  private buildWater(h: Hole): THREE.Mesh | null {
    if (!h.water.length && !h.cross.length) return null;
    let x0 = Infinity, x1 = -Infinity, z0 = Infinity, z1 = -Infinity;
    for (const w of h.water) { x0 = Math.min(x0, w.x - w.rx * 1.35); x1 = Math.max(x1, w.x + w.rx * 1.35); z0 = Math.min(z0, w.z - w.rz * 1.35); z1 = Math.max(z1, w.z + w.rz * 1.35); }
    for (const c of h.cross) { x0 = Math.min(x0, c.xmin - 6); x1 = Math.max(x1, c.xmax + 6); z0 = Math.min(z0, c.z0 - 6); z1 = Math.max(z1, c.z1 + 6); }
    const st = 2, nx = Math.ceil((x1 - x0) / st), nz = Math.ceil((z1 - z0) / st);
    const wet = (x: number, z: number) => {
      for (const w of h.water) if (((x - w.x) / w.rx) ** 2 + ((z - w.z) / w.rz) ** 2 < 1.32 * 1.32) return true;
      for (const c of h.cross) if (x > c.xmin - 6 && x < c.xmax + 6 && z > c.z0 - 3 && z < c.z1 + 3) return true;
      return false;
    };
    const W = new Uint8Array((nx + 1) * (nz + 1));
    for (let j = 0; j <= nz; j++) for (let i = 0; i <= nx; i++) W[j * (nx + 1) + i] = wet(x0 + i * st, z0 + j * st) ? 1 : 0;
    const pts: number[][] = [], tris: number[] = [], map = new Int32Array((nx + 1) * (nz + 1)).fill(-1);
    const vid = (i: number, j: number) => {
      const k = j * (nx + 1) + i;
      if (map[k] < 0) { map[k] = pts.length; pts.push([x0 + i * st, z0 + j * st]); }
      return map[k];
    };
    for (let j = 0; j < nz; j++) for (let i = 0; i < nx; i++) {
      const k = j * (nx + 1) + i;
      if (!(W[k] | W[k + 1] | W[k + nx + 1] | W[k + nx + 2])) continue;
      const a = vid(i, j), b = vid(i + 1, j), c = vid(i, j + 1), d = vid(i + 1, j + 1);
      tris.push(a, c, b, b, c, d);
    }
    if (!tris.length) return null;
    return new THREE.Mesh(this.flatGeo(pts, tris), this.mats.water);
  }

  /** Clumps of tall native grass filling the hazard areas. */
  private buildTussocks(h: Hole): THREE.InstancedMesh {
    const geo = new THREE.ConeGeometry(0.55, 1.5, 5, 1, true).translate(0, 0.6, 0);
    const mat = new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 1, side: THREE.DoubleSide, flatShading: true });
    mat.userData.own = true;
    const R = makeRng((h.seed ?? 1) * 7 + 11), pts: { x: number; z: number; s: number }[] = [];
    const cap = this.safe ? 900 : this.high ? 3200 : 1800;
    for (const w of h.hazards!) {
      const n = Math.min(cap, Math.round(Math.PI * w.rx * w.rz / (this.high ? 5 : 9)));
      for (let k = 0; k < n && pts.length < cap; k++) {
        const a = R() * Math.PI * 2, r = Math.sqrt(R()) * 0.96;
        pts.push({ x: w.x + Math.cos(a) * r * w.rx, z: w.z + Math.sin(a) * r * w.rz, s: 0.7 + R() * 0.8 });
      }
    }
    const im = new THREE.InstancedMesh(geo, mat, Math.max(1, pts.length));
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), v = new THREE.Vector3(), sc = new THREE.Vector3(), c = new THREE.Color();
    const tones = ["#b59a52", "#a38a45", "#c4ab62", "#8f8a46", "#9c7f3e"];
    pts.forEach((p, i) => {
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), R() * 6.28);
      m.compose(v.set(p.x, groundH(h, p.x, p.z) - 0.1, p.z), q, sc.set(p.s, p.s * (0.8 + R() * 0.6), p.s));
      im.setMatrixAt(i, m); im.setColorAt(i, c.set(tones[(R() * tones.length) | 0]));
    });
    im.count = pts.length;
    im.castShadow = !this.safe; im.receiveShadow = true;
    return im;
  }

  /** Instanced houses: walls, pitched (or flat) roofs, backyard pools. */
  private buildHouses(h: Hole): THREE.Group {
    const grp = new THREE.Group(), list = h.houses!;
    const n = list.length;
    const wallGeo = new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0);
    const roofShape = new THREE.Shape();
    roofShape.moveTo(-0.5, 0); roofShape.lineTo(0.5, 0); roofShape.lineTo(0, 1); roofShape.closePath();
    const roofGeo = new THREE.ExtrudeGeometry(roofShape, { depth: 1, bevelEnabled: false }).translate(0, 0, -0.5);
    const flatGeo = new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0);
    const poolGeo = new THREE.BoxGeometry(1, 1, 1);
    const winGeo = new THREE.BoxGeometry(1, 1, 1);
    const wallM = new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.9 });
    const roofM = new THREE.MeshStandardMaterial({ color: "#ffffff", roughness: 0.75, flatShading: true });
    const poolM = new THREE.MeshStandardMaterial({ color: "#3fc6e0", roughness: 0.15, metalness: 0.1, emissive: "#0c4f5c", emissiveIntensity: 0.4 });
    const winM = new THREE.MeshStandardMaterial({ color: "#2b3a44", roughness: 0.2, metalness: 0.4 });
    for (const mm of [wallM, roofM, poolM, winM]) mm.userData.own = true;
    const walls = new THREE.InstancedMesh(wallGeo, wallM, n);
    const roofs = new THREE.InstancedMesh(roofGeo, roofM, n);
    const pools = new THREE.InstancedMesh(poolGeo, poolM, n);
    const wins = new THREE.InstancedMesh(winGeo, winM, n * 2);
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), up = new THREE.Vector3(0, 1, 0), v = new THREE.Vector3(), sc = new THREE.Vector3();
    let pn = 0, wn = 0;
    list.forEach((b, i) => {
      const y = groundH(h, b.x, b.z) - 0.2;
      q.setFromAxisAngle(up, b.rot);
      const big = b.w > 30;
      m.compose(v.set(b.x, y, b.z), q, sc.set(b.w, b.h + 0.2, b.d)); walls.setMatrixAt(i, m);
      walls.setColorAt(i, new THREE.Color(b.wall));
      if (b.flat || big) m.compose(v.set(b.x, y + b.h + 0.2, b.z), q, sc.set(b.w + 1.2, 0.5, b.d + 1.2));
      else m.compose(v.set(b.x, y + b.h + 0.2, b.z), q, sc.set(b.w + 1.4, Math.min(3, b.w * 0.22), b.d + 1));
      roofs.setMatrixAt(i, m); roofs.setColorAt(i, new THREE.Color(b.roof));
      if (b.flat || big) { /* flat roofs share the triangular instance, squashed */ }
      // dark window band on the side facing the course (local -z)
      const fx = Math.sin(b.rot), fz = Math.cos(b.rot);
      for (const lvl of b.h > 4 ? [1.4, 4.1] : [1.5]) {
        if (wn >= n * 2) break;
        m.compose(v.set(b.x + fx * (b.d / 2 + 0.03), y + lvl + 0.2, b.z + fz * (b.d / 2 + 0.03)), q, sc.set(b.w * (big ? 0.92 : 0.7), big ? 1.6 : 1.1, 0.06));
        wins.setMatrixAt(wn++, m);
      }
      if (b.pool && !big) {
        m.compose(v.set(b.x - fx * (b.d / 2 + 5), groundH(h, b.x - fx * (b.d / 2 + 5), b.z - fz * (b.d / 2 + 5)) - 0.05, b.z - fz * (b.d / 2 + 5)), q, sc.set(Math.min(8, b.w * 0.6), 0.2, 4));
        pools.setMatrixAt(pn++, m);
      }
    });
    // big flat-roofed buildings: swap their roof prism for a slab
    const slabs = list.filter((b) => b.flat || b.w > 30);
    if (slabs.length) {
      const sl = new THREE.InstancedMesh(flatGeo, roofM, slabs.length);
      slabs.forEach((b, i) => {
        const y = groundH(h, b.x, b.z) - 0.2;
        q.setFromAxisAngle(up, b.rot);
        m.compose(v.set(b.x, y + b.h + 0.2, b.z), q, sc.set(b.w + 1.6, 0.45, b.d + 1.6)); sl.setMatrixAt(i, m);
        sl.setColorAt(i, new THREE.Color(b.roof));
      });
      sl.castShadow = true; sl.receiveShadow = true; grp.add(sl);
      // hide the prisms on those
      list.forEach((b, i) => { if (b.flat || b.w > 30) { m.makeScale(0, 0, 0); roofs.setMatrixAt(i, m); } });
    }
    pools.count = pn; wins.count = wn;
    for (const im of [walls, roofs]) { im.castShadow = true; im.receiveShadow = true; }
    grp.add(walls, roofs, wins);
    if (pn) grp.add(pools);
    return grp;
  }

  private buildRoad(h: Hole, r: { pts: [number, number][]; w: number }): THREE.Mesh {
    const pos: number[] = [], idx: number[] = [];
    const P = r.pts;
    for (let i = 0; i < P.length; i++) {
      const a = P[Math.max(0, i - 1)], b = P[Math.min(P.length - 1, i + 1)];
      let tx = b[0] - a[0], tz = b[1] - a[1];
      const l = Math.hypot(tx, tz) || 1; tx /= l; tz /= l;
      const nx = tz * r.w / 2, nz = -tx * r.w / 2;
      for (const sg of [-1, 1]) {
        const x = P[i][0] + nx * sg, z = P[i][1] + nz * sg;
        pos.push(x, groundH(h, x, z) + 0.06, z);
      }
      if (i > 0) { const k = i * 2; idx.push(k - 2, k, k - 1, k - 1, k, k + 1); }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    geo.setIndex(idx); geo.computeVertexNormals();
    const mesh = new THREE.Mesh(geo, this.roadMat);
    mesh.receiveShadow = true;
    return mesh;
  }
  private roadMat = new THREE.MeshStandardMaterial({ color: "#55595c", roughness: 0.95, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -2 });

  private buildTrees(h: Hole): THREE.Group {
    const trees = buildTrees(h, this.theme.trees, this.treeDensity);
    const grp = new THREE.Group();
    const pines = trees.filter((t) => t.kind === 0), broads = trees.filter((t) => t.kind === 1);
    const R = makeRng((h.seed ?? 1) * 11);
    const pineCols = ["#24502c", "#2d5a32", "#355f38", "#2a4a2c", "#3a6a3a"].map((c) => new THREE.Color(c));
    const broadCols = ["#3d7a3a", "#4a8a3f", "#356b33", "#5b8f3a", "#6a9a40"].map((c) => new THREE.Color(c));
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), sv = new THREE.Vector3(), pv = new THREE.Vector3();
    const set = (im: THREE.InstancedMesh, i: number, x: number, y: number, z: number, sx: number, sy: number, sz: number, rot = 0) => {
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), rot);
      m.compose(pv.set(x, y, z), q, sv.set(sx, sy, sz)); im.setMatrixAt(i, m);
    };
    if (pines.length) {
      const trunk = new THREE.InstancedMesh(this.geo.trunk, this.mats.trunk, pines.length);
      const low = new THREE.InstancedMesh(this.geo.cone, this.mats.leaf, pines.length);
      const top = new THREE.InstancedMesh(this.geo.cone, this.mats.leaf, pines.length);
      pines.forEach((t, i) => {
        const y0 = terrainH(h, t.x, t.z), rot = R() * 6.28;
        set(trunk, i, t.x, y0 + t.h * 0.18, t.z, 1, t.h * 0.36, 1);
        set(low, i, t.x, y0 + t.h * 0.42, t.z, t.r, t.h * 0.5, t.r, rot);
        set(top, i, t.x, y0 + t.h * 0.72, t.z, t.r * 0.68, t.h * 0.42, t.r * 0.68, rot);
        const c = pineCols[(R() * pineCols.length) | 0];
        low.setColorAt(i, c); top.setColorAt(i, c.clone().offsetHSL(0, 0, 0.03));
      });
      for (const im of [trunk, low, top]) { im.castShadow = true; im.receiveShadow = true; grp.add(im); }
    }
    if (broads.length) {
      const trunk = new THREE.InstancedMesh(this.geo.trunk, this.mats.trunk, broads.length);
      const crown = new THREE.InstancedMesh(this.geo.blob, this.mats.leaf, broads.length);
      const lobe = new THREE.InstancedMesh(this.geo.blob, this.mats.leaf, broads.length);
      broads.forEach((t, i) => {
        const y0 = terrainH(h, t.x, t.z), th = t.h * 0.5, rot = R() * 6.28;
        set(trunk, i, t.x, y0 + th / 2, t.z, 1.15, th, 1.15);
        set(crown, i, t.x, y0 + th + t.r * 0.7, t.z, t.r, t.r * 0.85, t.r, rot);
        const ox = Math.cos(rot) * t.r * 0.55, oz = Math.sin(rot) * t.r * 0.55;
        set(lobe, i, t.x + ox, y0 + th + t.r * 0.45, t.z + oz, t.r * 0.7, t.r * 0.6, t.r * 0.7, rot);
        const c = broadCols[(R() * broadCols.length) | 0];
        crown.setColorAt(i, c); lobe.setColorAt(i, c.clone().offsetHSL(0, 0.02, -0.03));
      });
      for (const im of [trunk, crown, lobe]) { im.castShadow = true; im.receiveShadow = true; grp.add(im); }
    }
    return grp;
  }

  private buildCrowd(h: Hole): THREE.Group {
    const R = makeRng((h.seed ?? 1) * 23 + 7);
    const spots: { x: number; z: number; face: number }[] = [];
    const pd = pathData(h), last = pd.pts[pd.pts.length - 1], prev = pd.pts[Math.max(0, pd.pts.length - 8)];
    let ax = last.x - prev.x, az = last.z - prev.z;
    const al = Math.hypot(ax, az) || 1; ax /= al; az /= al;
    const okSpot = (x: number, z: number) => surfaceAt(h, x, z) === "rough" && waterInfluence(h, x, z) < 0.05;
    for (let a = 0; a < Math.PI * 2; a += 0.11) {
      const dx = Math.cos(a), dz = Math.sin(a);
      if (dx * -ax + dz * -az > 0.4) continue; // keep the approach open
      const rings = Math.max(1, Math.round(2 * (this.theme.crowd ?? 1)));
      for (let ring = 0; ring < rings; ring++) {
        if (R() < 0.18) continue;
        const rr = h.green.r + FRINGE + 5 + ring * 2.2 + R() * 1.2;
        const x = h.green.x + dx * rr, z = h.green.z + dz * rr;
        if (okSpot(x, z)) spots.push({ x, z, face: Math.atan2(h.green.x - x, h.green.z - z) });
      }
    }
    const p0 = pd.pts[0], p1 = pd.pts[Math.min(4, pd.pts.length - 1)];
    let tx = p1.x - p0.x, tz = p1.z - p0.z;
    const tl = Math.hypot(tx, tz) || 1; tx /= tl; tz /= tl;
    const nx = tz, nz = -tx;
    const rows = Math.max(2, Math.round(3 * (this.theme.crowd ?? 1)));
    for (let row = 0; row < rows; row++) for (let k = -6; k <= 6; k++) {
      if (R() < 0.15) continue;
      const x = h.tee.x - tx * (9 + row * 2.3) + nx * k * 1.9 + (R() - 0.5) * 0.6;
      const z = h.tee.z - tz * (9 + row * 2.3) + nz * k * 1.9 + (R() - 0.5) * 0.6;
      if (okSpot(x, z)) spots.push({ x, z, face: Math.atan2(tx, tz) });
    }
    for (const side of [-1, 1]) for (let k = 0; k < 7; k++) {
      const x = h.tee.x + nx * side * (12 + (k % 2) * 2) + tx * (k * 1.6 - 9);
      const z = h.tee.z + nz * side * (12 + (k % 2) * 2) + tz * (k * 1.6 - 9);
      if (okSpot(x, z)) spots.push({ x, z, face: Math.atan2(h.tee.x - x, h.tee.z - z) });
    }
    const n = spots.length, grp = new THREE.Group();
    if (!n) return grp;
    const bodies = new THREE.InstancedMesh(this.geo.body, this.mats.crowd, n);
    const heads = new THREE.InstancedMesh(this.geo.head, this.mats.skin, n);
    const caps = new THREE.InstancedMesh(this.geo.cap, this.mats.crowd, n);
    const shirts = ["#d94f4f", "#4f7fd9", "#e8b53a", "#5bb06a", "#9b6fc0", "#f0f0f0", "#e08a46", "#2f3b4c", "#e46aa0"].map((c) => new THREE.Color(c));
    const m = new THREE.Matrix4(), q = new THREE.Quaternion(), up = new THREE.Vector3(0, 1, 0), one = new THREE.Vector3(1, 1, 1);
    let capN = 0;
    spots.forEach((s, i) => {
      const y = terrainH(h, s.x, s.z), sc = 0.92 + R() * 0.16;
      q.setFromAxisAngle(up, s.face + (R() - 0.5) * 0.5);
      m.compose(new THREE.Vector3(s.x, y + 0.6 * sc, s.z), q, new THREE.Vector3(sc, sc, sc)); bodies.setMatrixAt(i, m);
      bodies.setColorAt(i, shirts[(R() * shirts.length) | 0]);
      m.compose(new THREE.Vector3(s.x, y + 1.43 * sc, s.z), q, one); heads.setMatrixAt(i, m);
      if (R() < 0.4) {
        m.compose(new THREE.Vector3(s.x, y + 1.62 * sc, s.z), q, one); caps.setMatrixAt(capN, m);
        caps.setColorAt(capN, shirts[(R() * shirts.length) | 0]); capN++;
      }
    });
    caps.count = capN;
    bodies.castShadow = true; heads.castShadow = true;
    // remember everyone's pose so the gallery can react
    const people: Person[] = [];
    let ci = 0;
    const tmp = new THREE.Matrix4();
    for (let i = 0; i < n; i++) {
      bodies.getMatrixAt(i, tmp);
      const p = new THREE.Vector3(), qq = new THREE.Quaternion(), ss = new THREE.Vector3();
      tmp.decompose(p, qq, ss);
      let cap = -1;
      if (ci < capN) { caps.getMatrixAt(ci, tmp); const cp = new THREE.Vector3().setFromMatrixPosition(tmp); if (Math.hypot(cp.x - p.x, cp.z - p.z) < 0.01) cap = ci++; }
      people.push({ p, q: qq, s: ss.x, ph: R() * 6.28, cap });
    }
    this.crowd = { bodies, heads, caps, people };
    grp.add(bodies, heads);
    if (capN) grp.add(caps);
    return grp;
  }

  /** Distant volcanic plugs (Glass House Mountains style) on the horizon toward a compass bearing. */
  private buildPeaks(h: Hole): THREE.Group {
    const grp = new THREE.Group();
    const F = (h as unknown as { _frame?: { fe: number; fn: number; re: number; rn: number } })._frame;
    const mat = new THREE.MeshBasicMaterial({ color: "#5d7184", fog: false, transparent: true, opacity: 0.85 });
    mat.userData.own = true;
    const sky = new THREE.Color(this.theme.fog);
    const plugs = [[128, 3600, 260, 150], [136, 4300, 170, 120], [142, 3300, 210, 95], [150, 4800, 300, 170], [158, 3900, 150, 90], [165, 5200, 230, 140], [118, 5600, 120, 110]];
    for (const [brg, dist, ht, wid] of plugs) {
      const b = THREE.MathUtils.degToRad(brg), de = Math.sin(b), dn = Math.cos(b); // compass bearing → east/north
      let lx = de, lz = dn;
      if (F) { const xr = de * F.re + dn * F.rn, zf = de * F.fe + dn * F.fn; lx = -xr; lz = zf; } // into hole space (mirrored x)
      const geo = new THREE.ConeGeometry(wid, ht, 9, 4);
      const p = geo.attributes.position as THREE.BufferAttribute;
      for (let i = 0; i < p.count; i++) { // knobbly, slightly lopsided plugs
        const y = p.getY(i), k = 1 + 0.18 * Math.sin(i * 1.7 + brg) + (y > ht * 0.2 ? 0.25 : 0);
        p.setXYZ(i, p.getX(i) * k, y, p.getZ(i) * k * 0.85);
      }
      geo.computeVertexNormals();
      const m = new THREE.Mesh(geo, mat.clone());
      (m.material as THREE.MeshBasicMaterial).color.copy(sky).lerp(new THREE.Color("#4f6475"), 0.55 - dist / 20000);
      m.position.set(lx * dist, ht / 2 - 60, lz * dist);
      grp.add(m);
    }
    return grp;
  }
  private buildBackdrop(h: Hole): THREE.Mesh {
    const bb = bounds(h), cx = (bb.minX + bb.maxX) / 2, cz = (bb.minZ + bb.maxZ) / 2;
    const R0 = Math.max(bb.maxX - bb.minX, bb.maxZ - bb.minZ) / 2 + 380;
    const segs = 128, rows = 7, pos: number[] = [], col: number[] = [], idx: number[] = [];
    const c1 = new THREE.Color(this.theme.rough).multiplyScalar(0.75), c2 = new THREE.Color("#8aa3ae");
    const seed = (h.seed ?? 1) * 0.7;
    for (let i = 0; i <= segs; i++) {
      const a = (i / segs) * Math.PI * 2;
      const peak = 24 + 46 * (0.5 + 0.5 * Math.sin(a * 3 + seed) * Math.cos(a * 5 + 0.4)) + 12 * Math.sin(a * 11 + seed);
      for (let j = 0; j <= rows; j++) {
        const u = j / rows, r = R0 + u * 420, y = Math.pow(Math.sin(Math.PI * u), 1.2) * peak;
        const px = cx + Math.cos(a) * r, pz = cz + Math.sin(a) * r;
        const base = h.hmap ? sampleHM(h.hmap, px, pz) : 0; // sit on the real terrain's edge height
        pos.push(px, base + y - 0.3, pz);
        const c = c1.clone().lerp(c2, Math.min(1, y / 75)); col.push(c.r, c.g, c.b);
      }
    }
    for (let i = 0; i < segs; i++) for (let j = 0; j < rows; j++) {
      const a = i * (rows + 1) + j, b = (i + 1) * (rows + 1) + j;
      idx.push(a, b, a + 1, a + 1, b, b + 1);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    geo.setAttribute("color", new THREE.Float32BufferAttribute(col, 3));
    geo.setIndex(idx); geo.computeVertexNormals();
    return new THREE.Mesh(geo, this.mats.backdrop);
  }

  private buildChevrons(h: Hole): THREE.InstancedMesh {
    const g = h.green, data: Chev[] = [], st = 2.3;
    const R = makeRng((h.seed ?? 1) * 5);
    for (let x = -g.r; x <= g.r; x += st) for (let z = -g.r; z <= g.r; z += st) {
      if (Math.hypot(x, z) > g.r - 0.9) continue;
      const wx = g.x + x + (R() - 0.5) * 0.4, wz = g.z + z + (R() - 0.5) * 0.4;
      const gr = greenGrad(h, wx, wz), mag = Math.hypot(gr.gx, gr.gz);
      if (mag < 0.006) continue;
      data.push({ x: wx, z: wz, dx: -gr.gx / mag, dz: -gr.gz / mag, speed: 0.25 + mag * 7, phase: R() });
    }
    const im = new THREE.InstancedMesh(this.chevGeo, this.chevMat, Math.max(1, data.length));
    im.count = data.length;
    im.frustumCulled = false;
    const cG = new THREE.Color("#8dffb8"), cY = new THREE.Color("#ffe066"), cR = new THREE.Color("#ff5d4d");
    data.forEach((d, i) => {
      const gr = greenGrad(h, d.x, d.z), t = clamp(Math.hypot(gr.gx, gr.gz) / 0.08, 0, 1);
      im.setColorAt(i, t < 0.5 ? cG.clone().lerp(cY, t * 2) : cY.clone().lerp(cR, (t - 0.5) * 2));
    });
    this.chevData = data;
    return im;
  }

  private buildPuttGrid(h: Hole): THREE.LineSegments {
    const g = h.green, R = g.r + 1.2, st = 1.5, sub = 0.6, pos: number[] = [];
    const add = (x0: number, z0: number, x1: number, z1: number) => {
      if (Math.hypot(x0 - g.x, z0 - g.z) > R || Math.hypot(x1 - g.x, z1 - g.z) > R) return;
      pos.push(x0, groundH(h, x0, z0) + 0.12, z0, x1, groundH(h, x1, z1) + 0.12, z1);
    };
    for (let a = -R; a <= R; a += st) for (let b = -R; b < R; b += sub) {
      add(g.x + a, g.z + b, g.x + a, g.z + b + sub);
      add(g.x + b, g.z + a, g.x + b + sub, g.z + a);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    const ls = new THREE.LineSegments(geo, this.gridMat);
    ls.visible = false;
    return ls;
  }

  // ------------------------------------------------------------ per-frame setters
  setPuttMode(on: boolean) {
    this.puttMode = on;
    if (this.puttGrid) this.puttGrid.visible = on;
  }

  setPuttPreview(path: { x: number; z: number }[] | null) {
    if (!path || path.length < 2) { this.puttDots.count = 0; this.puttEnd.visible = false; return; }
    const h = this.hole, gap = 0.6, gold = new THREE.Color("#ffd166"), white = new THREE.Color("#ffffff");
    let n = 0, carry = gap * 0.5, total = 0;
    for (let i = 1; i < path.length; i++) total += Math.hypot(path[i].x - path[i - 1].x, path[i].z - path[i - 1].z);
    let walked = 0;
    for (let i = 1; i < path.length && n < 160; i++) {
      const a = path[i - 1], b = path[i], L = Math.hypot(b.x - a.x, b.z - a.z);
      while (carry <= L && n < 160) {
        const t = carry / (L || 1), x = a.x + (b.x - a.x) * t, z = a.z + (b.z - a.z) * t;
        this.dummy.position.set(x, groundH(h, x, z) + 0.12, z);
        this.dummy.rotation.set(0, 0, 0); this.dummy.scale.setScalar(1); this.dummy.updateMatrix();
        this.puttDots.setMatrixAt(n, this.dummy.matrix);
        this.puttDots.setColorAt(n, white.clone().lerp(gold, (walked + carry) / (total || 1)));
        n++; carry += gap;
      }
      carry -= L; walked += L;
    }
    this.puttDots.count = n;
    this.puttDots.instanceMatrix.needsUpdate = true;
    if (this.puttDots.instanceColor) this.puttDots.instanceColor.needsUpdate = true;
    const e = path[path.length - 1];
    this.puttEnd.position.set(e.x, groundH(h, e.x, e.z) + 0.13, e.z);
    this.puttEnd.visible = true;
  }

  setBall(x: number, z: number, airH: number) {
    const gy = groundH(this.hole, x, z);
    this.ball.position.set(x, gy + airH + BALL_R, z);
    const dist = this.camera.position.distanceTo(this.ball.position);
    this.ball.scale.setScalar(Math.max(1, Math.min(7, dist / 34)));
    this.ballShadow.position.set(x, gy + 0.09, z);
    this.ballShadow.scale.setScalar(Math.max(0.4, 1 + airH * 0.04));
    (this.ballShadow.material as THREE.MeshBasicMaterial).opacity = Math.max(0.06, 0.25 - airH * 0.006);
    if (this.trailActive && this.trailN < 120) {
      const i = this.trailN * 3, p = this.ball.position;
      if (this.trailN === 0 || Math.hypot(p.x - this.trailPos[i - 3], p.y - this.trailPos[i - 2], p.z - this.trailPos[i - 1]) > 0.8) {
        this.trailPos[i] = p.x; this.trailPos[i + 1] = p.y; this.trailPos[i + 2] = p.z;
        this.trailN++;
        this.trail.geometry.setDrawRange(0, this.trailN);
        this.trail.geometry.attributes.position.needsUpdate = true;
      }
    }
  }
  trailStart() {
    this.trailActive = true; this.trailN = 0; this.trailFade = 0;
    (this.trail.material as THREE.LineBasicMaterial).opacity = 0.6;
    this.trail.geometry.setDrawRange(0, 0);
    this.trail.visible = true;
  }
  trailStop() { this.trailActive = false; this.trailFade = 2.2; }

  splash(x: number, z: number) {
    for (let k = 0; k < 2; k++) {
      const m = new THREE.Mesh(this.geo.splash, new THREE.MeshBasicMaterial({ color: "#ffffff", transparent: true, opacity: 0.85, depthWrite: false }));
      m.position.set(x, WATER_LEVEL + 0.04, z);
      this.scene.add(m);
      this.splashes.push({ m, t: -k * 0.25 });
    }
  }

  setGolfer(ballX: number, ballZ: number, heading: number, clubAngleDeg: number, visible: boolean) {
    this.golfer.visible = visible;
    const hx = Math.sin(heading), hz = Math.cos(heading);
    const gx = ballX + hz * 1.6, gz = ballZ - hx * 1.6; // stand on the player's left (right-handed)
    this.golfer.position.set(gx, terrainH(this.hole, gx, gz), gz);
    this.golfer.rotation.y = Math.atan2(hx, hz);
    this.clubPivot.rotation.x = (clubAngleDeg * Math.PI) / 180;
  }

  setAim(ball: { x: number; z: number }, heading: number, reach: number, visible: boolean) {
    this.aimLine.visible = visible; this.aimRing.visible = visible;
    if (!visible) return;
    const hx = Math.sin(heading), hz = Math.cos(heading), pts: THREE.Vector3[] = [];
    for (let s = 1.5; s <= reach; s += 3) pts.push(new THREE.Vector3(ball.x + hx * s, groundH(this.hole, ball.x + hx * s, ball.z + hz * s) + 0.18, ball.z + hz * s));
    if (pts.length < 2) pts.push(new THREE.Vector3(ball.x + hx * reach, 0.2, ball.z + hz * reach));
    this.aimLine.geometry.setFromPoints(pts);
    this.aimLine.computeLineDistances();
    const ex = ball.x + hx * reach, ez = ball.z + hz * reach;
    this.aimRing.position.set(ex, groundH(this.hole, ex, ez) + 0.14, ez);
    this.aimRing.scale.setScalar(0.5 + reach / 260);
  }

  setWind(x: number, z: number, mph: number) {
    this.wind = { x, z, mph };
    this.clothPivot.rotation.y = Math.atan2(-z, x);
  }

  setCamera(px: number, py: number, pz: number, lx: number, ly: number, lz: number) {
    this.camera.up.set(0, 1, 0);
    this.camera.position.set(px, py, pz);
    this.camera.lookAt(lx, ly, lz);
    this.followShadow(lx, lz);
  }
  setTopCamera(cx: number, cz: number, height: number) {
    this.camera.up.set(0, 0, 1);
    this.camera.position.set(cx, height, cz);
    this.camera.lookAt(cx, 0, cz);
    this.followShadow(cx, cz);
  }
  private followShadow(x: number, z: number) {
    this.sun.position.copy(this.sunDir).multiplyScalar(200).add(new THREE.Vector3(x, 0, z));
    this.sun.target.position.set(x, 0, z);
  }

  // ------------------------------------------------------------ animate + render
  update(dt: number, t: number) {
    this.updateCrowd(dt);
    const wm = this.mats.water as THREE.ShaderMaterial | undefined;
    if (wm?.uniforms) wm.uniforms.uTime.value = t;

    // flag cloth wave
    const pa = this.cloth.geometry.attributes.position as THREE.BufferAttribute;
    const amp = 0.06 + this.wind.mph * 0.006, spd = 4 + this.wind.mph * 0.3;
    for (let i = 0; i < pa.count; i++) {
      const bx = this.clothBase[i * 3];
      pa.setZ(i, Math.sin(bx * 3.4 - t * spd) * bx * amp + Math.sin(bx * 7 - t * spd * 1.7) * bx * amp * 0.25);
    }
    pa.needsUpdate = true;
    this.cloth.geometry.computeVertexNormals();

    // flowing slope chevrons
    if (this.chevrons && this.hole) {
      const g = this.hole.green;
      const near = this.camera.position.distanceTo(new THREE.Vector3(g.x, 0, g.z)) < 260;
      this.chevrons.visible = near;
      if (near) {
        const base = this.puttMode ? 1.15 : 0.8;
        for (let i = 0; i < this.chevData.length; i++) {
          const c = this.chevData[i], ph = (c.phase + t * c.speed) % 1, off = (ph - 0.5) * 1.6;
          const x = c.x + c.dx * off, z = c.z + c.dz * off;
          const s = base * (0.45 + 0.55 * Math.sin(ph * Math.PI));
          this.dummy.position.set(x, groundH(this.hole, x, z) + 0.14, z);
          this.dummy.rotation.set(0, Math.atan2(c.dx, c.dz), 0);
          this.dummy.scale.set(s, 1, s);
          this.dummy.updateMatrix();
          this.chevrons.setMatrixAt(i, this.dummy.matrix);
        }
        this.chevrons.instanceMatrix.needsUpdate = true;
      }
    }

    if (!this.trailActive && this.trailFade > 0) {
      this.trailFade -= dt;
      (this.trail.material as THREE.LineBasicMaterial).opacity = 0.6 * clamp(this.trailFade / 2.2, 0, 1);
      if (this.trailFade <= 0) this.trail.visible = false;
    }
    for (let i = this.splashes.length - 1; i >= 0; i--) {
      const s = this.splashes[i];
      s.t += dt;
      const k = Math.max(0, s.t);
      s.m.scale.setScalar(0.4 + k * 5);
      (s.m.material as THREE.MeshBasicMaterial).opacity = 0.85 * clamp(1 - k / 1.1, 0, 1);
      if (s.t > 1.1) { this.scene.remove(s.m); (s.m.material as THREE.Material).dispose(); this.splashes.splice(i, 1); }
    }
    this.clouds.rotation.y += dt * 0.002;
  }

  render() {
    if (this.composer) this.composer.render();
    else this.renderer.render(this.scene, this.camera);
  }
}
