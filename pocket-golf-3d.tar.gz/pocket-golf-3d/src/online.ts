// Players, scores and leaderboards backed by a Google Apps Script web app (Google Sheets).
// Works offline: scores queue in localStorage and upload when a connection is available.

export interface Player { name: string; pin: string; hcap: number; difficulty: number; }
export interface BoardRow { name: string; score: number; }
export interface BoardPair { gross: BoardRow[]; net: BoardRow[]; }
export interface CourseBoard { holes: Record<string, BoardPair>; rounds: Record<string, BoardPair>; at: number; }
/** One finished hole. The sheet keeps one row per round (RoundID) and fills in each hole's column. */
export interface HoleItem {
  roundId: string; course: string; holes: number; hole: number; strokes: number;
  pars: number[]; recv: number[]; bag: string; hcap: number; difficulty: number; ts: number;
  name: string; pin: string;
}
/** Local leaderboard/PB bookkeeping for a just-finished hole or completed segment. */
export interface LocalScore { type: "hole" | "round"; course: string; key: string; strokes: number; net: number; }

const LS = {
  get(k: string) { try { return localStorage.getItem(k); } catch { return null; } },
  set(k: string, v: string) { try { localStorage.setItem(k, v); } catch { /* storage unavailable */ } },
  del(k: string) { try { localStorage.removeItem(k); } catch { /* storage unavailable */ } },
};

export class Online {
  url = "";
  player: Player | null = null;
  private boards = new Map<string, CourseBoard>();
  private flushing = false;
  /** called whenever a board or the player changes so the UI can refresh */
  onChange: () => void = () => {};

  constructor() {
    const raw = LS.get("pg3d.player");
    if (raw) try { this.player = JSON.parse(raw); } catch { /* ignore */ }
    window.addEventListener("online", () => this.flush());
  }

  /** Endpoint comes from ?lb=…, then config.json next to the game, then a previously saved value. */
  async init() {
    const q = new URLSearchParams(location.search).get("lb");
    if (q) { this.url = q; LS.set("pg3d.lbUrl", q); }
    if (!this.url) {
      try {
        const r = await fetch("config.json", { cache: "no-cache" });
        if (r.ok) { const c = await r.json(); if (c.leaderboardUrl) { this.url = String(c.leaderboardUrl).trim(); LS.set("pg3d.lbUrl", this.url); } }
      } catch { /* offline or opened as a local file */ }
    }
    if (!this.url) this.url = LS.get("pg3d.lbUrl") ?? "";
    if (this.player && this.url) this.refreshPlayer();
    this.flush();
    this.onChange();
  }
  get enabled() { return !!this.url; }

  // ------------------------------------------------------------------ transport
  private async get(params: Record<string, string>) {
    const u = new URL(this.url);
    for (const [k, v] of Object.entries(params)) u.searchParams.set(k, v);
    const r = await fetch(u.toString(), { redirect: "follow" });
    return r.json();
  }
  private async post(body: unknown) {
    // text/plain keeps this a "simple" request (no CORS preflight, which Apps Script can't answer)
    const r = await fetch(this.url, { method: "POST", redirect: "follow", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify(body) });
    return r.json();
  }

  // ------------------------------------------------------------------ players
  private save() {
    if (this.player) LS.set("pg3d.player", JSON.stringify(this.player)); else LS.del("pg3d.player");
    this.onChange();
  }
  async login(name: string, pin: string): Promise<string | null> {
    if (!this.enabled) return "Leaderboards aren't set up yet.";
    try {
      const r = await this.get({ action: "login", name, pin });
      if (!r.ok) return r.error || "Couldn't sign in.";
      this.player = { name: r.player.name, pin, hcap: +r.player.hcap || 0, difficulty: +r.player.difficulty || 0 };
      this.save();
      return null;
    } catch { return "No connection — try again when you're online."; }
  }
  async register(name: string, pin: string): Promise<string | null> {
    if (!this.enabled) return "Leaderboards aren't set up yet.";
    try {
      const r = await this.post({ action: "register", name, pin });
      if (!r.ok) return r.error || "Couldn't create player.";
      this.player = { name: r.player.name, pin, hcap: +r.player.hcap || 0, difficulty: +r.player.difficulty || 0 };
      this.save();
      return null;
    } catch { return "No connection — try again when you're online."; }
  }
  signOut() { this.player = null; this.save(); }
  /** Pick up handicap / difficulty changes made in the sheet. */
  private async refreshPlayer() {
    const p = this.player;
    if (!p) return;
    try {
      const r = await this.get({ action: "login", name: p.name, pin: p.pin });
      if (r.ok && this.player) { this.player.hcap = +r.player.hcap || 0; this.player.difficulty = +r.player.difficulty || 0; this.save(); }
    } catch { /* offline: keep cached values */ }
  }

  // ------------------------------------------------------------------ scores
  private queue(): HoleItem[] { try { return JSON.parse(LS.get("pg3d.queue2") || "[]"); } catch { return []; } }
  /** Queue a finished hole for upload (signed-in players only). */
  submitHole(item: Omit<HoleItem, "name" | "pin" | "ts" | "difficulty">) {
    const p = this.player;
    if (!p) return;
    const q = this.queue();
    q.push({ ...item, name: p.name, pin: p.pin, difficulty: p.difficulty, ts: Date.now() });
    LS.set("pg3d.queue2", JSON.stringify(q.slice(-600)));
    this.flush();
  }
  /** Record a hole or completed segment locally: personal best + instant leaderboard merge. */
  record(sc: LocalScore) {
    const pbKey = `pg3d.pb.${sc.course}.${sc.key}`;
    const prev = LS.get(pbKey);
    if (!prev || sc.strokes < +prev) LS.set(pbKey, String(sc.strokes));
    const p = this.player;
    if (p) this.mergeLocal(sc.course, sc.type, sc.key, p.name, sc.strokes, sc.net);
  }
  localPB(course: string, key: string): number | null { const v = LS.get(`pg3d.pb.${course}.${key}`); return v ? +v : null; }
  pending() { return this.queue().length; }
  async flush() {
    if (!this.enabled || this.flushing || !navigator.onLine) return;
    const q = this.queue();
    if (!q.length) return;
    this.flushing = true;
    try {
      const r = await this.post({ action: "holes", items: q });
      if (r.ok) {
        const left = this.queue().slice(q.length); // anything queued while we were uploading
        LS.set("pg3d.queue2", JSON.stringify(left));
        for (const c of new Set(q.map((i) => i.course))) this.boards.delete(c);
      }
    } catch { /* stay queued */ }
    this.flushing = false;
  }

  // ------------------------------------------------------------------ leaderboards
  board(course: string) { return this.boards.get(course) ?? null; }
  async loadBoard(course: string, force = false): Promise<CourseBoard | null> {
    if (!this.enabled) return null;
    const have = this.boards.get(course);
    if (have && !force && Date.now() - have.at < 60_000) return have;
    try {
      const r = await this.get({ action: "board", course });
      if (!r.ok) return have ?? null;
      const b: CourseBoard = { holes: r.holes || {}, rounds: r.rounds || {}, at: Date.now() };
      // re-apply holes still waiting to upload so your own scores show immediately
      for (const it of this.queue()) if (it.course === course) mergeInto(b, "hole", String(it.hole), it.name, it.strokes, it.strokes - (it.recv[it.hole - 1] || 0));
      this.boards.set(course, b);
      this.onChange();
      return b;
    } catch { return have ?? null; }
  }
  private mergeLocal(course: string, type: "hole" | "round", key: string, name: string, gross: number, net: number) {
    const b = this.boards.get(course);
    if (b) { mergeInto(b, type, key, name, gross, net); this.onChange(); }
  }
}

function mergeInto(b: CourseBoard, type: "hole" | "round", key: string, name: string, gross: number, net: number) {
  const tbl = type === "hole" ? b.holes : b.rounds;
  const pair = tbl[key] ?? (tbl[key] = { gross: [], net: [] });
  const upd = (list: BoardRow[], v: number) => {
    const me = list.find((r) => r.name.toLowerCase() === name.toLowerCase());
    if (me) { if (v < me.score) me.score = v; } else list.push({ name, score: v });
    list.sort((a, c) => a.score - c.score);
    if (list.length > 10) list.length = 10;
  };
  upd(pair.gross, gross); upd(pair.net, net);
}

/** Rank of `score` within a sorted list (1-based, ties share the rank). */
export function rankOf(list: BoardRow[], score: number) { return list.filter((r) => r.score < score).length + 1; }

/**
 * Handicap strokes received on a hole. Stroke index comes from hole length relative to par;
 * a 9-hole course uses half the handicap.
 */
export function strokesReceived(hcap: number, si: number, holes: number): number {
  const A = Math.round(holes >= 18 ? hcap : hcap / 2);
  if (A === 0) return 0;
  if (A > 0) return Math.floor(A / holes) + (si <= A % holes ? 1 : 0);
  const g = -A; // plus handicap gives strokes back on the easiest holes
  return -(Math.floor(g / holes) + (si > holes - (g % holes) ? 1 : 0));
}
