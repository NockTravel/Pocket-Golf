import { World } from "./world";
import { Game } from "./game";

type Mode = "high" | "low" | "safe";
/** GPUs known to mangle half-float render targets / env lighting get Safe mode by default. */
function riskyGpu(): boolean {
  try {
    const c = document.createElement("canvas");
    const gl = c.getContext("webgl2") || c.getContext("webgl");
    if (!gl) return true;
    const dbg = gl.getExtension("WEBGL_debug_renderer_info");
    const name = String(dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER));
    const halfOk = !!(gl.getExtension("EXT_color_buffer_half_float") || gl.getExtension("EXT_color_buffer_float"));
    (gl.getExtension("WEBGL_lose_context") as { loseContext(): void } | null)?.loseContext();
    return /Mali|PowerVR|Adreno \(TM\) [3-5]\d\d/i.test(name) || !halfOk;
  } catch { return false; }
}
function pickMode(): Mode {
  const q = new URLSearchParams(location.search).get("gfx");
  if (q === "high" || q === "low" || q === "safe") return q;
  try {
    const saved = localStorage.getItem("pg3d.quality");
    if (saved === "high" || saved === "low" || saved === "safe") return saved;
  } catch { /* storage unavailable */ }
  if (riskyGpu()) return "safe";
  const mobile = /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent) || Math.min(innerWidth, innerHeight) < 520;
  return mobile ? "low" : "high";
}

const canvas = document.getElementById("scene") as HTMLCanvasElement;
const mode = pickMode();

function showGfxFail(msg?: string) {
  try { localStorage.setItem("pg3d.quality", "safe"); } catch { /* storage unavailable */ }
  const el = document.getElementById("gfxFail");
  if (!el) return;
  if (msg) document.getElementById("gfxMsg")!.innerHTML = msg;
  el.classList.remove("hidden");
  document.getElementById("gfxReload")!.onclick = () => location.reload();
}

// If the phone's GPU resets, three.js can't recover the textures it uploaded: drop to Safe mode
// and offer a reload rather than leaving a blank screen.
let lost = false;
canvas.addEventListener("webglcontextlost", (e) => { e.preventDefault(); lost = true; showGfxFail(); }, false);
canvas.addEventListener("webglcontextrestored", () => location.reload(), false);

let world: World, game: Game;
try {
  world = new World(canvas, mode === "high", mode === "safe");
  game = new Game(world, mode === "high");
} catch (err) {
  console.error(err);
  showGfxFail(mode === "safe"
    ? "3D graphics couldn't start on this device right now. Chrome usually blocks 3D for a while after a graphics crash."
    : "3D graphics couldn't start. The game has switched to <b>Safe</b> mode, which is much lighter.");
  throw err;
}
game.attachInput(canvas);
if (location.search.includes("debug")) (window as unknown as { __game: Game }).__game = game;

let last = performance.now();
function frame(now: number) {
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;
  if (!lost) { game.update(dt); world.render(); }
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

// Installable / offline when served over HTTPS (e.g. GitHub Pages)
if ("serviceWorker" in navigator && location.protocol === "https:") {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch(() => { /* not available in this context */ });
  });
}
