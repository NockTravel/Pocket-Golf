import { World } from "./world";
import { Game } from "./game";

type Mode = "high" | "low" | "safe";
/** GPUs known to mangle half-float render targets / env lighting get Safe mode by default. */
function riskyGpu(): boolean {
  try {
    const c = document.createElement("canvas");
    const gl = c.getContext("webgl2") || c.getContext("webgl");
    if (!gl) return true;
    const dbg = gl.getExtension("WEBGL_debug_renderer_info");
    const name = String(dbg ? gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER));
    const halfOk = !!(gl.getExtension("EXT_color_buffer_half_float") || gl.getExtension("EXT_color_buffer_float"));
    (gl.getExtension("WEBGL_lose_context") as { loseContext(): void } | null)?.loseContext();
    return /Mali|PowerVR|Adreno \(TM\) [3-5]\d\d/i.test(name) || !halfOk;
  } catch { return false; }
}
function pickMode(): Mode {
  const q = new URLSearchParams(location.search).get("gfx");
  if (q === "high" || q === "low" || q === "safe") return q;
  try {
    const saved = localStorage.getItem("pg3d.quality");
    if (saved === "high" || saved === "low" || saved === "safe") return saved;
  } catch { /* storage unavailable */ }
  if (riskyGpu()) return "safe";
  const mobile = /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent) || Math.min(innerWidth, innerHeight) < 520;
  return mobile ? "low" : "high";
}

const canvas = document.getElementById("scene") as HTMLCanvasElement;
const mode = pickMode();
const world = new World(canvas, mode === "high", mode === "safe");
const game = new Game(world, mode === "high");
game.attachInput(canvas);
if (location.search.includes("debug")) (window as unknown as { __game: Game }).__game = game;

// If the browser drops the GPU context (memory pressure, driver reset), reload cleanly instead of
// leaving untextured / black surfaces behind.
canvas.addEventListener("webglcontextlost", (e) => { e.preventDefault(); }, false);
canvas.addEventListener("webglcontextrestored", () => location.reload(), false);

let last = performance.now();
function frame(now: number) {
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;
  game.update(dt);
  world.render();
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

// Installable / offline when served over HTTPS (e.g. GitHub Pages)
if ("serviceWorker" in navigator && location.protocol === "https:") {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch(() => { /* not available in this context */ });
  });
}
