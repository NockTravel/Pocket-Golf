import { Hole, Surface, surfaceAt, greenGrad, onGreen, onFringe, bounds, groundH, lowland } from "./holes";

export type LieKey = "tee" | "fairway" | "rough" | "bunker";
/** 1 great · 2 good · 3 ok · 4 hard · 5 poor */
export type Rating = 1 | 2 | 3 | 4 | 5;
export interface Club {
  id: string; name: string; short: string;
  max: number; roll: number; curve: number; swing: number; loft: number;
  /** impact sweet-spot width multiplier (bigger = easier to strike straight) */
  sweet: number;
  /** power-meter speed multiplier (bigger = harder to judge distance) */
  pspeed: number;
  lies: Record<LieKey, Rating>;
  blurb: string;
}
export const CLUBS: Club[] = [
  { id: "driver", name: "Driver", short: "DR", max: 285, roll: 22, curve: 1.15, swing: 1.0, loft: 0.11, sweet: 0.88, pspeed: 1.0,
    lies: { tee: 1, fairway: 4, rough: 5, bunker: 5 }, blurb: "Max distance off the tee. Hard to hit off the deck, useless from rough." },
  { id: "wood3", name: "3 Wood", short: "3W", max: 250, roll: 18, curve: 0.9, swing: 0.95, loft: 0.13, sweet: 1.0, pspeed: 1.0,
    lies: { tee: 2, fairway: 2, rough: 3, bunker: 5 }, blurb: "Big distance from the tee or fairway. Playable, not easy, from rough." },
  { id: "hybrid", name: "4 Hybrid", short: "4H", max: 215, roll: 14, curve: 0.78, swing: 0.85, loft: 0.16, sweet: 1.05, pspeed: 1.0,
    lies: { tee: 2, fairway: 2, rough: 2, bunker: 4 }, blurb: "The all-rounder. Decent off the tee, good from fairway and rough." },
  { id: "iron5", name: "5 Iron", short: "5i", max: 195, roll: 10, curve: 0.55, swing: 0.8, loft: 0.19, sweet: 1.3, pspeed: 1.3,
    lies: { tee: 2, fairway: 2, rough: 3, bunker: 4 }, blurb: "Tight, straight flight — easy to aim, harder to judge the power." },
  { id: "pw", name: "Pitching Wedge", short: "PW", max: 135, roll: 5, curve: 0.5, swing: 0.65, loft: 0.3, sweet: 1.15, pspeed: 1.0,
    lies: { tee: 2, fairway: 1, rough: 2, bunker: 3 }, blurb: "Accurate approach club from fairway or rough. Okay from sand." },
  { id: "sw", name: "Sand Wedge", short: "SW", max: 95, roll: 3, curve: 0.45, swing: 0.6, loft: 0.4, sweet: 1.2, pspeed: 1.0,
    lies: { tee: 2, fairway: 2, rough: 2, bunker: 1 }, blurb: "Escapes bunkers with ease. Short, accurate, lots of check." },
  { id: "putter", name: "Putter", short: "P", max: 40, roll: 0, curve: 0.05, swing: 0.18, loft: 0, sweet: 1.0, pspeed: 1.0,
    lies: { tee: 5, fairway: 3, rough: 5, bunker: 5 }, blurb: "Always in the bag." },
];
export const PUTTER = CLUBS[CLUBS.length - 1];
export const BAG_SIZE = 4; // including the compulsory putter
export const DEFAULT_BAG = ["driver", "hybrid", "pw", "putter"];
export const clubById = (id: string) => CLUBS.find((c) => c.id === id) ?? PUTTER;

const LIE_EFFECT: Record<Rating, { pm: number; disp: number; ms: number; sweet: number }> = {
  1: { pm: 1.0, disp: 0.0, ms: 1.0, sweet: 1.1 },
  2: { pm: 0.97, disp: 0.03, ms: 1.04, sweet: 1.0 },
  3: { pm: 0.88, disp: 0.1, ms: 1.12, sweet: 0.82 },
  4: { pm: 0.78, disp: 0.18, ms: 1.22, sweet: 0.66 },
  5: { pm: 0.62, disp: 0.3, ms: 1.35, sweet: 0.5 },
};
export function lieKey(lie: Surface): LieKey {
  return lie === "tee" ? "tee" : lie === "bunker" ? "bunker" : lie === "rough" || lie === "hazard" ? "rough" : "fairway";
}
export function lieRating(c: Club, lie: Surface): Rating {
  if (c.id === "putter") return lie === "green" ? 1 : lie === "fringe" ? 2 : c.lies[lieKey(lie)];
  return c.lies[lieKey(lie)];
}

/** Pick the most sensible club in the bag for the distance and lie. */
export function chooseClub(bag: Club[], d: number, lie: Surface): Club {
  if (lie === "green" || (lie === "fringe" && d < 28)) return PUTTER;
  const opts = bag.filter((c) => c.id !== "putter" && lieRating(c, lie) <= 4);
  const pool = opts.length ? opts : bag.filter((c) => c.id !== "putter");
  if (!pool.length) return PUTTER;
  const eff = (c: Club) => c.max * LIE_EFFECT[lieRating(c, lie)].pm;
  const fits = pool.filter((c) => eff(c) >= d * 0.97).sort((a, b) => eff(a) - eff(b));
  if (fits.length) return fits[0];
  // nothing reaches: longest club that's at least "ok" from here, else longest overall
  const ok = pool.filter((c) => lieRating(c, lie) <= 3).sort((a, b) => eff(b) - eff(a));
  return ok[0] ?? pool.sort((a, b) => eff(b) - eff(a))[0];
}

/** Hidden per-player modifier (0 = normal). Higher = faster meters, smaller sweet spots, wilder wind. */
export interface Difficulty { pm: number; disp: number; ms: number; sweet: number; pspeed: number; }
export function difficulty(c: Club, lie: Surface, mod = 0): Difficulty {
  const e = LIE_EFFECT[lieRating(c, lie)];
  let pm = e.pm, disp = e.disp, ms = e.ms, sweet = e.sweet * c.sweet;
  if (lie === "rough" && c.id !== "putter") pm *= 0.95;
  if (lie === "bunker" && c.id !== "sw") pm *= 0.9;
  if (c.id === "putter" && lie !== "green" && lie !== "fringe") { pm = 0.6; disp = 0.06; }
  if (c.id === "driver") disp += 0.05; // a little extra random left/right, even when struck well
  ms *= 1 + 0.12 * mod;
  sweet *= Math.max(0.5, 1 - 0.12 * mod);
  return { pm, disp, ms, sweet, pspeed: c.pspeed };
}

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

/** Lateral curve for an impact offset. `k` scales the pure / shaped windows (bigger = more forgiving). */
export function shapeCurve(off: number, c: Club, carry: number, k = 1): number {
  const a = Math.abs(off), s = off < 0 ? -1 : 1, p = 0.1 * k, w = 0.28 * k;
  let mag: number;
  if (a <= p) mag = (a / p) * 0.12;
  else if (a <= w) mag = 0.12 + ((a - p) / (w - p)) * 0.33;
  else mag = 0.45 + ((a - w) / Math.max(0.05, 1 - w)) * 1.05;
  return s * mag * c.curve * carry * 0.14;
}
/** Impact-meter zones (fractions of the bar) for a sweet-spot multiplier. */
export function impactZones(k: number) {
  const p = 0.1 * k / 2, w = 0.28 * k / 2;
  return { pure: [0.5 - p, 0.5 + p], shaped: [0.5 - w, 0.5 + w] };
}

export interface Vec2 { x: number; z: number; }
export interface ShotParams {
  club: Club; power: number; off: number; th: number; diff: Difficulty;
  origin: Vec2; wind: { x: number; z: number };
}
export interface FlightResult { rest: Vec2; water: boolean; holed: boolean; /** which penalty area: open water or native grass */ hazard?: "water" | "grass"; }

function clampB(h: Hole, p: Vec2): Vec2 {
  const b = bounds(h);
  return { x: clamp(p.x, b.minX - 70, b.maxX + 70), z: clamp(p.z, b.minZ - 70, b.maxZ + 70) };
}
function dropOut(h: Hole, a: Vec2, b: Vec2): Vec2 {
  for (let t = 0.9; t >= 0; t -= 0.05) {
    const x = lerp(a.x, b.x, t), z = lerp(a.z, b.z, t);
    const sf = surfaceAt(h, x, z);
    if (sf !== "water" && sf !== "hazard" && (!h.plateau || lowland(h, x, z) < 0.05)) return { x, z };
  }
  return { x: a.x, z: a.z };
}

// Step-integrated roll with green slope + surface friction.
function rollPutt(h: Hole, start: Vec2, th: number, v0: number) {
  let pos = { x: start.x, z: start.z };
  let vel = { x: Math.sin(th) * v0, z: Math.cos(th) * v0 };
  const dt = 0.03, path: Vec2[] = [{ ...pos }];
  let holed = false;
  for (let i = 0; i < 600; i++) {
    const og = onGreen(h, pos.x, pos.z), sp = Math.hypot(vel.x, vel.z);
    if (sp < 0.3) break;
    const fric = og ? 15 / (h.greenSpeed ?? 1) : onFringe(h, pos.x, pos.z) ? 24 : 46;
    const nd = Math.max(0, sp - fric * dt);
    vel.x = (vel.x / sp) * nd; vel.z = (vel.z / sp) * nd;
    if (og) { const g = greenGrad(h, pos.x, pos.z); vel.x -= g.gx * 45 * dt; vel.z -= g.gz * 45 * dt; }
    pos = clampB(h, { x: pos.x + vel.x * dt, z: pos.z + vel.z * dt });
    if (i % 2 === 0) path.push({ ...pos });
    if (Math.hypot(pos.x - h.pin.x, pos.z - h.pin.z) < 0.7 && nd < 22) { holed = true; pos = { ...h.pin }; path.push({ ...pos }); break; }
  }
  path.push({ ...pos });
  return { path, rest: pos, dur: Math.max(0.4, path.length * 0.045), holed };
}
/** Predicted roll line for a putt struck to roll `dist` yards on a flat green. */
export function previewPutt(h: Hole, start: Vec2, th: number, dist: number): Vec2[] {
  return rollPutt(h, start, th, Math.sqrt(2 * 16 * Math.max(1, dist))).path;
}

type Seg = "carry" | "roll" | "putt" | "splash" | "done";

// ---- landing behaviour per surface
const REST: Record<Surface, number> = { fairway: 0.46, tee: 0.46, green: 0.36, fringe: 0.38, rough: 0.25, bunker: 0.04, water: 0, hazard: 0.1 };
const IMPACT: Record<Surface, number> = { fairway: 0.2, tee: 0.2, green: 0.28, fringe: 0.3, rough: 0.5, bunker: 0.88, water: 1, hazard: 0.9 };
const ROLLF: Record<Surface, number> = { fairway: 8.5, tee: 8.5, green: 6.5, fringe: 10, rough: 24, bunker: 70, water: 99, hazard: 99 };
// how strongly back/top spin bites on impact, and how far it may pull the ball back
const SPINK: Record<Surface, number> = { fairway: 6, tee: 6, green: 9.5, fringe: 9, rough: 2.5, bunker: 0, water: 0, hazard: 0 };
const MINBACK: Record<Surface, number> = { fairway: -2.5, tee: -2.5, green: -5, fringe: -3.5, rough: 0, bunker: 0, water: 0, hazard: 0 };
const NATURAL_BACKSPIN: Record<string, number> = { driver: 0, wood3: 0.05, hybrid: 0.15, iron5: 0.25, pw: 0.4, sw: 0.55, putter: 0 };
const G = 30, SIM_DT = 1 / 60;

export interface FlightEvent { type: "bounce" | "land"; surface: Surface; strength: number; }
interface Sample { x: number; z: number; y: number; ev?: FlightEvent; }

export class Flight {
  seg: Seg;
  pos: Vec2;
  h = 0;
  spin = { h: 0, v: 0 };
  finished = false;
  result: FlightResult | null = null;
  /** bounce / landing events since last drained by the game */
  events: FlightEvent[] = [];

  private hole: Hole;
  private club: Club;
  private clk = 0;
  private g!: (u: number) => Vec2;
  private apex = 0; private carry = 0; private hx = 0; private hz = 0; private px = 0; private pz = 0;
  private o: Vec2; private carryDur = 0.6;
  private prev: Vec2 = { x: 0, z: 0 };
  private landing: Vec2 = { x: 0, z: 0 }; private rest: Vec2 = { x: 0, z: 0 };
  private water = false; private holed = false;
  /** set when the ball ends in a penalty area */
  hazard: "water" | "grass" | undefined;
  private path: Vec2[] = []; private dur = 0;
  private run: Sample[] = []; private runI = 0;

  constructor(h: Hole, p: ShotParams) {
    this.hole = h;
    this.club = p.club;
    const c = p.club, pow = clamp(p.power, 0, 1), th = p.th, d = p.diff;
    this.hx = Math.sin(th); this.hz = Math.cos(th); this.px = this.hz; this.pz = -this.hx;
    this.o = { x: p.origin.x, z: p.origin.z };
    this.pos = { ...this.o };
    this.prev = { ...this.o };

    if (c.id === "putter") {
      const v0 = Math.sqrt(2 * 16 * Math.max(2, pow * c.max * d.pm));
      const r = rollPutt(h, this.o, th + d.disp * (Math.random() - 0.5) * 0.2, v0);
      this.path = r.path; this.dur = r.dur; this.rest = r.rest; this.holed = r.holed;
      this.seg = "putt";
      return;
    }
    const off = p.off + d.disp * (Math.random() - 0.5) * 2;
    this.carry = pow * c.max * d.pm;
    // height difference changes the carry (about a yard per yard of drop), refined once
    if (h.hmap) for (let it = 0; it < 2; it++) {
      const lx = this.o.x + Math.sin(th) * this.carry, lz = this.o.z + Math.cos(th) * this.carry;
      const dy = groundH(h, this.o.x, this.o.z) - groundH(h, lx, lz);
      this.carry = clamp(pow * c.max * d.pm + dy * 0.9, pow * c.max * d.pm * 0.7, pow * c.max * d.pm * 1.3);
    }
    this.apex = this.carry * c.loft;
    this.carryDur = Math.max(0.5, this.carry / 230 + 0.5);
    const wf = 1.15 * (this.carry / 100);
    const curveTot = shapeCurve(off, c, this.carry, d.sweet);
    const o = this.o, hx = this.hx, hz = this.hz, px = this.px, pz = this.pz, carry = this.carry, wind = p.wind;
    this.g = (u: number) => {
      const lat = curveTot * u * u;
      return { x: o.x + hx * carry * u + px * lat + wind.x * wf * u, z: o.z + hz * carry * u + pz * lat + wind.z * wf * u };
    };
    this.seg = "carry";
  }

  private finishCarry() {
    const h = this.hole;
    this.landing = clampB(h, this.pos);
    const ls = surfaceAt(h, this.landing.x, this.landing.z);
    if (ls === "water" || ls === "hazard") {
      this.water = true; this.hazard = ls === "water" ? "water" : "grass";
      this.rest = dropOut(h, this.o, this.landing); this.seg = "splash"; this.clk = 0;
      this.events.push({ type: "land", surface: ls, strength: 1 });
      return;
    }
    let dx = this.pos.x - this.prev.x, dz = this.pos.z - this.prev.z;
    const dl = Math.hypot(dx, dz) || 1; dx /= dl; dz /= dl;
    this.simulateRun(dx, dz);
    this.seg = "roll"; this.clk = 0; this.runI = 0;
  }

  /** Bounce + roll simulation on the real terrain (slopes, surfaces, spin, hazards, cup). */
  private simulateRun(ux: number, uz: number) {
    const h = this.hole, c = this.club;
    const fr = clamp(this.carry / c.max, 0.3, 1.1);
    let vh = Math.sqrt(c.roll) * 4.7 * (0.5 + 0.5 * fr) * (0.85 + Math.random() * 0.3);
    let vx = ux * vh, vz = uz * vh;
    let vy = -Math.min(Math.sqrt(2 * G * Math.max(this.apex, 1)), 32) * 0.86;
    let x = this.landing.x, z = this.landing.z, y = 0;
    let sv = this.spin.v + (NATURAL_BACKSPIN[c.id] ?? 0) * fr, sh = this.spin.h;
    let rolling = false, bounces = 0;
    const out: Sample[] = [];
    const grad = (px: number, pz: number) => {
      const e = 0.35;
      return { gx: (groundH(h, px + e, pz) - groundH(h, px - e, pz)) / (2 * e), gz: (groundH(h, px, pz + e) - groundH(h, px, pz - e)) / (2 * e) };
    };
    for (let i = 0; i < 900; i++) {
      const s = surfaceAt(h, x, z);
      let ev: FlightEvent | undefined;
      if (!rolling && y <= 0 && vy < 0) {
        // ---- impact with the ground
        if (s === "water" || s === "hazard") { this.water = true; this.hazard = s === "water" ? "water" : "grass"; out.push({ x, z, y: 0, ev: { type: "land", surface: s, strength: 1 } }); break; }
        const sp = Math.hypot(vx, vz);
        if (sp > 0.01) { ux = vx / sp; uz = vz / sp; }
        const k = bounces === 0 ? 1 : 0.3;
        let nh = sp * (1 - IMPACT[s]) - sv * SPINK[s] * k;
        nh = Math.max(nh, MINBACK[s] * Math.max(0, sv));
        if (sv <= 0) nh = Math.max(nh, 0);
        const lat = sh * 3.2 * k * (SPINK[s] / 9);
        vx = ux * nh + uz * lat; vz = uz * nh - ux * lat;
        // backspin deadens the bounce a touch, topspin keeps it lively
        const gs = s === "green" ? (h.greenSpeed ?? 1) : 1;
        const e = REST[s] * clamp(1 - sv * 0.18, 0.7, 1.2) * (1 + 0.15 * (gs - 1));
        ev = { type: bounces === 0 ? "land" : "bounce", surface: s, strength: clamp(-vy / 26, 0.1, 1) };
        vy = -vy * e;
        y = 0;
        sv *= 0.3; sh *= 0.3;
        bounces++;
        if (vy < 1.6) { vy = 0; rolling = true; }
      }
      if (!rolling) {
        vy -= G * SIM_DT;
        y = Math.max(0, y + vy * SIM_DT);
        x += vx * SIM_DT; z += vz * SIM_DT;
      } else {
        if (s === "water" || s === "hazard") { this.water = true; this.hazard = s === "water" ? "water" : "grass"; out.push({ x, z, y: 0 }); break; }
        const sp = Math.hypot(vx, vz);
        const og = s === "green";
        const g = og ? greenGrad(h, x, z) : grad(x, z);
        const gm = Math.hypot(g.gx, g.gz), lim = og ? 1 : Math.min(1, 1.6 / Math.max(gm, 1e-6));
        g.gx *= lim; g.gz *= lim;
        const slopeA = gm * lim * (og ? 45 : 22);
        const fric = s === "green" ? ROLLF[s] / (h.greenSpeed ?? 1) : ROLLF[s];
        if (sp < 0.35 && slopeA < fric * 0.85) { out.push({ x, z, y: 0, ev }); break; }
        const nd = Math.max(0, sp - fric * SIM_DT);
        if (sp > 0) { vx = (vx / sp) * nd; vz = (vz / sp) * nd; }
        vx -= g.gx * (og ? 45 : 22) * SIM_DT; vz -= g.gz * (og ? 45 : 22) * SIM_DT;
        x += vx * SIM_DT; z += vz * SIM_DT;
      }
      const cl = clampB(h, { x, z }); x = cl.x; z = cl.z;
      if (y < 0.25 && Math.hypot(x - h.pin.x, z - h.pin.z) < 0.7 && Math.hypot(vx, vz) < 24) {
        this.holed = true; x = h.pin.x; z = h.pin.z; out.push({ x, z, y: 0, ev }); break;
      }
      out.push({ x, z, y, ev });
    }
    if (out.length === 0) out.push({ x, z, y: 0 });
    const last = out[out.length - 1];
    this.rest = this.water ? dropOut(h, this.landing, last) : { x: last.x, z: last.z };
    this.run = out;
  }

  update(dt: number) {
    if (this.finished) return;
    this.clk += dt;
    if (this.seg === "carry") {
      const u = clamp(this.clk / this.carryDur, 0, 1);
      const b = this.g(u);
      const lS = this.spin.h * this.carry * 0.035 * u * u;
      this.prev = this.pos;
      this.pos = { x: b.x + this.px * lS, z: b.z + this.pz * lS };
      const gE = this.g(1), y0 = groundH(this.hole, this.o.x, this.o.z), y1 = groundH(this.hole, gE.x, gE.z);
      const yNow = groundH(this.hole, this.pos.x, this.pos.z);
      this.h = Math.max(0, y0 + (y1 - y0) * u + this.apex * Math.sin(Math.PI * u) - yNow);
      if (u >= 1) this.finishCarry();
    } else if (this.seg === "roll") {
      const target = Math.min(this.run.length - 1, Math.floor(this.clk / SIM_DT));
      while (this.runI < target) {
        this.runI++;
        const ev = this.run[this.runI].ev;
        if (ev) this.events.push(ev);
      }
      const s = this.run[this.runI];
      this.pos = { x: s.x, z: s.z }; this.h = s.y;
      if (this.runI >= this.run.length - 1) {
        if (this.water) { this.seg = "splash"; this.clk = 0; this.h = 0; }
        else this.done();
      }
    } else if (this.seg === "putt") {
      const fr = clamp(this.clk / this.dur, 0, 1), idx = fr * (this.path.length - 1);
      const i0 = Math.floor(idx), i1 = Math.min(this.path.length - 1, i0 + 1), ft = idx - i0;
      this.pos = { x: lerp(this.path[i0].x, this.path[i1].x, ft), z: lerp(this.path[i0].z, this.path[i1].z, ft) };
      this.h = 0;
      if (fr >= 1) this.done();
    } else if (this.seg === "splash") {
      this.h = 0; if (this.clk > 0.6) this.done();
    }
  }
  private done() {
    this.seg = "done"; this.finished = true;
    this.result = { rest: this.rest, water: this.water, holed: this.holed, hazard: this.hazard };
  }
}
