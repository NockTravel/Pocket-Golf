// Procedural canvas textures — no image files needed.
import * as THREE from "three";

const cl = (v: number) => (v < 0 ? 0 : v > 255 ? 255 : v);
function hexRGB(hex: string): [number, number, number] {
  const v = parseInt(hex.replace("#", "").slice(0, 6), 16);
  return [(v >> 16) & 255, (v >> 8) & 255, v & 255];
}
function rnd(seed: number) {
  let s = (Math.floor(seed * 7919) % 2147483646) + 1;
  return () => (s = (s * 16807) % 2147483647) / 2147483647;
}
function mk(size: number) {
  const c = document.createElement("canvas");
  c.width = c.height = size;
  return c;
}
function valueNoise(size: number, cells: number, r: () => number): Float32Array {
  const g: number[] = [];
  for (let i = 0; i < cells * cells; i++) g.push(r());
  const at = (x: number, y: number) => g[(y % cells) * cells + (x % cells)];
  const out = new Float32Array(size * size);
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const fx = (x / size) * cells, fy = (y / size) * cells;
    const x0 = Math.floor(fx), y0 = Math.floor(fy), tx = fx - x0, ty = fy - y0;
    const sx = tx * tx * (3 - 2 * tx), sy = ty * ty * (3 - 2 * ty);
    const a = at(x0, y0), b = at(x0 + 1, y0), c = at(x0, y0 + 1), d = at(x0 + 1, y0 + 1);
    out[y * size + x] = a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy;
  }
  return out;
}
function finish(c: HTMLCanvasElement, srgb = true) {
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  t.needsUpdate = true;
  return t;
}

export function grassTexture(base: string, seed = 1, size = 256, contrast = 0.16) {
  const [r0, g0, b0] = hexRGB(base);
  const c = mk(size), g = c.getContext("2d")!, img = g.createImageData(size, size), R = rnd(seed);
  const n1 = valueNoise(size, 6, R), n2 = valueNoise(size, 24, R);
  for (let i = 0; i < size * size; i++) {
    const f = 1 + ((n1[i] - 0.5) * 0.9 + (n2[i] - 0.5) * 0.6 + (R() - 0.5) * 0.7) * contrast;
    const blade = R() < 0.05 ? 0.1 : 0;
    img.data[i * 4] = cl(r0 * f); img.data[i * 4 + 1] = cl(g0 * (f + blade)); img.data[i * 4 + 2] = cl(b0 * f * 0.97);
    img.data[i * 4 + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  return finish(c);
}

/** Two-tone mown stripes (bands along V) with grass noise. */
export function stripeTexture(a: string, b: string, seed = 2, size = 256, contrast = 0.1) {
  const A = hexRGB(a), B = hexRGB(b);
  const c = mk(size), g = c.getContext("2d")!, img = g.createImageData(size, size), R = rnd(seed);
  const n = valueNoise(size, 16, R), half = size / 2;
  for (let y = 0; y < size; y++) {
    const base = y < half ? A : B;
    const d = Math.min(Math.abs(y - half), y, size - y);
    const blend = d < 6 ? 0.5 * (1 - d / 6) : 0;
    const other = y < half ? B : A;
    for (let x = 0; x < size; x++) {
      const i = y * size + x;
      const f = 1 + ((n[i] - 0.5) * 0.8 + (R() - 0.5) * 0.6) * contrast;
      for (let k = 0; k < 3; k++) img.data[i * 4 + k] = cl((base[k] * (1 - blend) + other[k] * blend) * f);
      img.data[i * 4 + 3] = 255;
    }
  }
  g.putImageData(img, 0, 0);
  return finish(c);
}

export function sandTexture(base: string, seed = 3, size = 256) {
  const [r0, g0, b0] = hexRGB(base);
  const c = mk(size), g = c.getContext("2d")!, img = g.createImageData(size, size), R = rnd(seed);
  const n = valueNoise(size, 12, R);
  for (let i = 0; i < size * size; i++) {
    let f = 1 + (n[i] - 0.5) * 0.12 + (R() - 0.5) * 0.16;
    if (R() < 0.01) f *= 0.82;
    img.data[i * 4] = cl(r0 * f); img.data[i * 4 + 1] = cl(g0 * f); img.data[i * 4 + 2] = cl(b0 * f); img.data[i * 4 + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  return finish(c);
}

/** Tiling ripple normal map for water. */
export function waterNormalTexture(size = 512) {
  const c = mk(size), g = c.getContext("2d")!, img = g.createImageData(size, size);
  // many tileable waves in scattered directions -> organic ripples with no grid pattern
  let sd = 7;
  const rnd = () => ((sd = (sd * 16807) % 2147483647) / 2147483647);
  const waves: number[][] = [];
  for (let i = 0; i < 26; i++) {
    const mag = 2 + Math.floor(rnd() * (i < 8 ? 5 : 14)), ang = rnd() * Math.PI * 2;
    const fx = Math.round(Math.cos(ang) * mag), fy = Math.round(Math.sin(ang) * mag);
    if (fx === 0 && fy === 0) continue;
    waves.push([fx, fy, rnd() * 6.28, 1 / Math.pow(Math.hypot(fx, fy), 1.15)]);
  }
  const H = (x: number, y: number) => {
    let h = 0;
    for (const [fx, fy, p, a] of waves) {
      const v = Math.sin(((fx * x + fy * y) / size) * Math.PI * 2 + p);
      h += a * (1 - Math.abs(v)) * 1.4; // sharpened crests
    }
    return h;
  };
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const dx = (H(x + 1, y) - H(x - 1, y)) * 9, dy = (H(x, y + 1) - H(x, y - 1)) * 9;
    const l = Math.hypot(dx, dy, 1), i = (y * size + x) * 4;
    img.data[i] = cl((-dx / l * 0.5 + 0.5) * 255);
    img.data[i + 1] = cl((-dy / l * 0.5 + 0.5) * 255);
    img.data[i + 2] = cl((1 / l * 0.5 + 0.5) * 255);
    img.data[i + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  return finish(c, false);
}

/** Soft white blob for cloud sprites. */
export function blobTexture(size = 128) {
  const c = mk(size), g = c.getContext("2d")!;
  const grd = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  grd.addColorStop(0, "rgba(255,255,255,0.95)");
  grd.addColorStop(0.5, "rgba(255,255,255,0.55)");
  grd.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = grd; g.fillRect(0, 0, size, size);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
