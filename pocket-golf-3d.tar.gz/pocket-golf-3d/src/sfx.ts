// Tiny WebAudio synth — no audio files.
export class Sfx {
  enabled = true;
  private ctx: AudioContext | null = null;

  unlock() {
    if (this.ctx) { if (this.ctx.state === "suspended") void this.ctx.resume(); return; }
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AC();
    } catch { this.ctx = null; }
  }

  private noise(dur: number, freq: number, q: number, gain: number, type: BiquadFilterType) {
    const c = this.ctx;
    if (!c || !this.enabled) return;
    const len = Math.max(1, Math.floor(c.sampleRate * dur));
    const buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = c.createBufferSource(); src.buffer = buf;
    const f = c.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
    const g = c.createGain(); g.gain.value = gain;
    src.connect(f).connect(g).connect(c.destination);
    src.start();
  }
  private tone(freq: number, dur: number, gain: number, type: OscillatorType = "sine", slideTo?: number, delay = 0) {
    const c = this.ctx;
    if (!c || !this.enabled) return;
    const t0 = c.currentTime + delay;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t0);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain, t0 + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g).connect(c.destination);
    o.start(t0); o.stop(t0 + dur + 0.02);
  }

  /** noise through a filter whose frequency and gain follow envelopes — whooshes and crowd swells */
  private sweep(dur: number, type: BiquadFilterType, f0: number, f1: number, q: number, peak: number, attack: number, delay = 0, echo = false) {
    const c = this.ctx;
    if (!c || !this.enabled) return;
    const t0 = c.currentTime + delay, len = Math.max(1, Math.floor(c.sampleRate * dur));
    const buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    const src = c.createBufferSource(); src.buffer = buf;
    const f = c.createBiquadFilter(); f.type = type; f.Q.value = q;
    f.frequency.setValueAtTime(f0, t0); f.frequency.exponentialRampToValueAtTime(f1, t0 + dur);
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(peak, t0 + attack);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(f).connect(g).connect(c.destination);
    if (echo) {
      const dl = c.createDelay(1); dl.delayTime.value = 0.19;
      const fb = c.createGain(); fb.gain.value = 0.35;
      const wet = c.createGain(); wet.gain.value = 0.4;
      g.connect(dl); dl.connect(fb).connect(dl); dl.connect(wet).connect(c.destination);
    }
    src.start(t0); src.stop(t0 + dur + 0.05);
  }

  /** Flushed, full-power, centred strike: big crack + echo, ball whoosh, crowd "ooooh" and applause. */
  perfect(driver: boolean) {
    this.noise(0.09, 2600, 0.6, 0.85, "highpass");
    this.tone(110, 0.32, 0.6, "sine", 45);
    this.tone(driver ? 2300 : 1700, 0.18, 0.16, "triangle", driver ? 1500 : 1200);
    this.sweep(0.5, "bandpass", 3800, 900, 1.2, 0.28, 0.005, 0.0, true); // crack echoing off the trees
    this.sweep(1.6, "bandpass", 500, 2600, 3, 0.18, 0.5, 0.05);           // ball tearing away
    this.sweep(1.8, "bandpass", 380, 620, 4, 0.14, 0.7, 0.35);            // crowd "ooooh"
    this.sweep(2.2, "bandpass", 1500, 1200, 0.35, 0.16, 0.25, 1.4);       // applause
  }
  /** Ball hitting the ground: soft thud on grass, crisp tick on the green, dull puff in sand. */
  bounce(surface: string, strength: number, first: boolean) {
    const s = 0.35 + strength * 0.65;
    if (surface === "bunker") { this.noise(0.18, 700, 0.6, 0.25 * s, "lowpass"); return; }
    if (surface === "green" || surface === "fringe") {
      this.tone(first ? 260 : 300, 0.08, 0.28 * s, "sine", 150);
      this.noise(0.03, 2400, 0.8, 0.08 * s, "highpass");
      return;
    }
    this.tone(150, 0.1, 0.3 * s, "sine", 80);
    this.noise(0.06, surface === "rough" ? 900 : 1500, 0.7, 0.12 * s, "lowpass");
  }

  strike(power: number) { this.noise(0.06, 3200, 0.7, 0.35 + power * 0.3, "highpass"); this.tone(160, 0.14, 0.35, "sine", 70); }
  putt() { this.tone(950, 0.06, 0.18, "triangle"); this.noise(0.03, 3500, 1, 0.12, "highpass"); }
  cup() { this.tone(700, 0.14, 0.25, "sine"); this.tone(1050, 0.22, 0.22, "sine", undefined, 0.11); }
  splash() { this.noise(0.6, 900, 0.5, 0.35, "lowpass"); }
  cheer() { this.noise(1.4, 1300, 0.35, 0.16, "bandpass"); }
  click() { this.tone(1400, 0.03, 0.08, "square"); }
}
