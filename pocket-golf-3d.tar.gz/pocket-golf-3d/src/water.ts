import * as THREE from "three";

/**
 * Stylised-realistic water: depth-tinted body, two scrolling normal layers,
 * Fresnel sky reflection, sharp sun glints, animated shoreline foam and
 * soft transparency in the shallows. Expects a per-vertex `depth` attribute
 * (water depth at that point; <= 0 means the bank is above the waterline).
 */
export function makeWaterMaterial(opts: {
  normal: THREE.Texture; sunDir: THREE.Vector3; deep: string; shallow: string; skyTop: string; horizon: string;
}): THREE.ShaderMaterial {
  const uniforms = THREE.UniformsUtils.merge([THREE.UniformsLib.fog, {
    uTime: { value: 0 },
    uSunDir: { value: new THREE.Vector3() },
    uSunColor: { value: new THREE.Color("#fff3d6") },
    uDeep: { value: new THREE.Color(opts.deep) },
    uShallow: { value: new THREE.Color(opts.shallow) },
    uSkyTop: { value: new THREE.Color(opts.skyTop) },
    uHorizon: { value: new THREE.Color(opts.horizon) },
  }]);
  // assign shared objects after merge (merge clones values)
  uniforms.uNormal = { value: opts.normal };
  uniforms.uSunDir.value = opts.sunDir;

  return new THREE.ShaderMaterial({
    uniforms,
    fog: true,
    transparent: true,
    depthWrite: false,
    side: THREE.DoubleSide,
    vertexShader: /* glsl */ `
      attribute float depth;
      uniform float uTime;
      varying vec3 vWorld;
      varying float vDepth;
      #include <fog_pars_vertex>
      void main() {
        vec4 wp = modelMatrix * vec4(position, 1.0);
        // slow swell, faded out at the shore so the waterline stays put
        float sw = clamp(depth * 2.0, 0.0, 1.0);
        wp.y += (sin(wp.x * 0.35 + uTime * 1.3) * 0.5 + sin(wp.z * 0.27 - uTime * 1.1) * 0.5) * 0.035 * sw;
        vWorld = wp.xyz;
        vDepth = depth;
        vec4 mvPosition = viewMatrix * wp;
        gl_Position = projectionMatrix * mvPosition;
        #include <fog_vertex>
      }`,
    fragmentShader: /* glsl */ `
      uniform float uTime;
      uniform sampler2D uNormal;
      uniform vec3 uSunDir, uSunColor, uDeep, uShallow, uSkyTop, uHorizon;
      varying vec3 vWorld;
      varying float vDepth;
      #include <fog_pars_fragment>
      vec3 nrm(vec2 uv) { return texture2D(uNormal, uv).xyz * 2.0 - 1.0; }
      void main() {
        vec2 p = vWorld.xz;
        vec3 toCam = cameraPosition - vWorld;
        float dist = length(toCam);
        vec3 V = toCam / dist;
        vec3 n1 = nrm(p / 23.0 + vec2(uTime * 0.016, uTime * 0.010));
        vec3 n2 = nrm(p / 9.0 + vec2(-uTime * 0.024, uTime * 0.017));
        vec3 n3 = nrm(p / 3.4 + vec2(uTime * 0.04, -uTime * 0.035));
        // ripples calm down with distance (and the fine layer fades first) to avoid shimmer
        float far = smoothstep(15.0, 150.0, dist);
        vec2 t = n1.xy + n2.xy * 0.6 + n3.xy * 0.35 * (1.0 - far);
        float str = mix(0.16, 0.045, far);
        vec3 N = normalize(vec3(t.x * str, 1.0, t.y * str));

        float d = clamp(vDepth / 0.85, 0.0, 1.0);
        vec3 body = mix(uShallow, uDeep, smoothstep(0.0, 1.0, d));
        body *= 0.75 + 0.3 * max(dot(N, uSunDir), 0.0);
        float ca = abs(n2.x + n3.y);
        body += uShallow * (1.0 - d) * smoothstep(0.7, 1.2, ca) * 0.25 * (1.0 - far);

        float fres = 0.04 + 0.96 * pow(1.0 - max(dot(N, V), 0.0), 5.0);
        vec3 R = reflect(-V, N);
        // mirrored scene: dark treeline just above the horizon, then sky
        vec3 skyR = mix(uHorizon, uSkyTop, pow(clamp((R.y - 0.05) / 0.6, 0.0, 1.0), 0.6));
        vec3 trees = vec3(0.07, 0.15, 0.09);
        vec3 refl = mix(trees, skyR, smoothstep(0.03, 0.16, R.y));
        vec3 col = mix(body, refl, clamp(fres, 0.0, 0.85));

        vec3 H = normalize(uSunDir + V);
        float nh = max(dot(N, H), 0.0);
        col += uSunColor * (pow(nh, 700.0) * 3.0 + pow(nh, 90.0) * 0.18);

        // shoreline foam: thin pulsing lace at the bank
        float pulse = 0.07 + 0.04 * sin(uTime * 1.4 + p.x * 0.5 + p.y * 0.35);
        float band = 1.0 - smoothstep(0.0, pulse, max(vDepth, 0.0));
        float brk = nrm(p / 2.4 + vec2(uTime * 0.05, uTime * 0.03)).x * 0.5 + 0.5;
        float foam = band * smoothstep(0.5, 0.75, brk + band * 0.2);
        col = mix(col, vec3(0.93, 0.96, 0.97), foam * 0.6);

        float alpha = mix(0.6, 0.97, smoothstep(0.0, 0.4, d));
        alpha = max(alpha, foam * 0.7);
        alpha = max(alpha, fres * mix(0.55, 0.95, d));
        gl_FragColor = vec4(col, alpha);
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
        #include <fog_fragment>
      }`,
  });
}
