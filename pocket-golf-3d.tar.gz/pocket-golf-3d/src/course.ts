import { Hole, FRINGE, House, Road, pathData, surfaceAt, makeRng, nearestOnPath, pathAt, bounds, sampleHM } from "./holes";
import pelican from "./courses/pelican.json";
import sunshine from "./courses/sunshine.json";
import coastal from "./courses/coastal.json";
import cliffs from "./courses/cliffs.json";
import maleny from "./courses/maleny.json";

export interface Theme {
  rough: string; fairway: string; fairway2: string; green: string; fringe: string;
  sand: string; water: string; fog: string;
  trees: "pine" | "broad" | "mix";
  sunElevation: number; sunAzimuth: number; turbidity: number; rayleigh: number;
  hills: number;
  /** crowd size multiplier around tees and greens (default 1) */
  crowd?: number;
  /** green speed: 1 normal, ~1.6 very fast (less power needed, slopes bite harder) */
  greenSpeed?: number;
  /** draw distant volcanic peaks on the south-eastern horizon (needs a survey course for real bearings) */
  peaks?: boolean;
}
export const DEFAULT_THEME: Theme = {
  rough: "#3f7a37", fairway: "#5aa84c", fairway2: "#66b556", green: "#6fbf55", fringe: "#5fae4c",
  sand: "#e8d9a8", water: "#2a7fb0", fog: "#c9dde8", trees: "mix",
  sunElevation: 38, sunAzimuth: 150, turbidity: 6, rayleigh: 1.6, hills: 1,
};

export interface Course { id: string; name: string; tagline: string; theme: Theme; holes: Hole[]; }

// Course files are authored with +x = right of the player; the renderer's view has
// +x on screen-left, so mirror every x coordinate once on load.
// ---------------------------------------------------------------- real-world (survey) courses
// A course may carry a terrain grid ("dem") in map metres (MGA easting/northing) and holes whose
// coordinates are given in those metres ("frame": "mga"). Those holes are converted to the game's
// local yards (tee at the origin, green straight up the screen) and get a height map sampled from the DEM.
const YD = 1.0936;
interface Dem { e0: number; n0: number; step: number; w: number; h: number; base: number; data: string; }
interface DemGrid { e0: number; n0: number; step: number; w: number; h: number; z: Float32Array; }
function decodeDem(d: Dem): DemGrid {
  const bin = atob(d.data), n = d.w * d.h, z = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    let v = bin.charCodeAt(i * 2) | (bin.charCodeAt(i * 2 + 1) << 8);
    if (v & 0x8000) v -= 0x10000;
    z[i] = d.base + v / 10; // decimetres above base
  }
  return { e0: d.e0, n0: d.n0, step: d.step, w: d.w, h: d.h, z };
}
/** Height in metres at easting/northing (row 0 = northern edge), clamped at the grid edge. */
function demAt(g: DemGrid, e: number, n: number) {
  const fx = Math.min(g.w - 1.001, Math.max(0, (e - g.e0) / g.step)), fy = Math.min(g.h - 1.001, Math.max(0, (g.n0 - n) / g.step));
  const i = Math.floor(fx), j = Math.floor(fy), u = fx - i, v = fy - j, z = g.z, w = g.w;
  return (z[j * w + i] * (1 - u) + z[j * w + i + 1] * u) * (1 - v) + (z[(j + 1) * w + i] * (1 - u) + z[(j + 1) * w + i + 1] * u) * v;
}
type Frame = { te: number; tn: number; fe: number; fn: number; re: number; rn: number };
function mgaFrame(h: any): Frame {
  const te = h.tee.e, tn = h.tee.n, ge = h.green.e, gn = h.green.n;
  const L = Math.hypot(ge - te, gn - tn) || 1, fe = (ge - te) / L, fn = (gn - tn) / L;
  return { te, tn, fe, fn, re: fn, rn: -fe }; // right-hand side of the tee→green line
}
/** Convert every map-metre coordinate on the hole into local yards (+x = player's right, +z = towards the green). */
function mgaToLocal(h: any) {
  const F = mgaFrame(h);
  const L = (e: number, n: number) => {
    const de = e - F.te, dn = n - F.tn;
    return { x: (de * F.re + dn * F.rn) * YD, z: (de * F.fe + dn * F.fn) * YD + 5 };
  };
  const pt = (o: any) => { const p = L(o.e, o.n); o.x = p.x; o.z = p.z; delete o.e; delete o.n; };
  h._frame = F;
  pt(h.tee); pt(h.green);
  h.pin = h.pin ? (pt(h.pin), h.pin) : { x: h.green.x, z: h.green.z };
  if (Array.isArray(h.path)) h.path = h.path.map((p: number[]) => { const q = L(p[0], p[1]); return [q.x, q.z]; });
  for (const k of ["bunkers", "water", "hazards"]) for (const o of h[k] ?? []) pt(o);
  for (const b of h.buildings ?? []) pt(b);
}
/** Sample the DEM into a local height map (engine coords, after mirroring), heights in yards relative to the tee. */
function buildHeightMap(h: Hole & { _frame: Frame }, g: DemGrid) {
  const F = h._frame, b = bounds(h), M = 190, step = 3.5;
  const x0 = b.minX - M, z0 = b.minZ - M, nx = Math.ceil((b.maxX - b.minX + 2 * M) / step) + 1, nz = Math.ceil((b.maxZ - b.minZ + 2 * M) / step) + 1;
  const data = new Float32Array(nx * nz);
  const toEN = (x: number, z: number) => { const xr = -x / YD, zf = (z - 5) / YD; return [F.te + F.re * xr + F.fe * zf, F.tn + F.rn * xr + F.fn * zf]; };
  const [te, tn] = toEN(h.tee.x, h.tee.z), y0 = demAt(g, te, tn);
  for (let j = 0; j < nz; j++) for (let i = 0; i < nx; i++) {
    const [e, n] = toEN(x0 + i * step, z0 + j * step);
    data[j * nx + i] = (demAt(g, e, n) - y0) * YD;
  }
  h.hmap = { x0, z0, step, nx, nz, data };
  // the green keeps ~30% of the hillside's fall as its tilt (that's what the putting physics and slope arrows use)
  const r = h.green.r, gx = h.green.x, gz = h.green.z, hm = h.hmap;
  const sx = (sampleHM(hm, gx + r, gz) - sampleHM(hm, gx - r, gz)) / (2 * r), sz = (sampleHM(hm, gx, gz + r) - sampleHM(hm, gx, gz - r)) / (2 * r);
  const cap = (v: number) => Math.max(-0.045, Math.min(0.045, v));
  h.green.tx = cap(h.green.tx + sx * 0.3); h.green.tz = cap(h.green.tz + sz * 0.3);
}

function mirrorHole(h: any) {
  h.tee.x = -h.tee.x; h.pin.x = -h.pin.x; h.green.x = -h.green.x; h.green.tx = -h.green.tx;
  for (const m of h.green.mounds) m.dx = -m.dx;
  if (Array.isArray(h.path)) h.path = h.path.map((p: number[]) => [-p[0], p[1]]);
  if (typeof h.dogAmp === "number") h.dogAmp = -h.dogAmp;
  for (const w of h.water) w.x = -w.x;
  for (const b of h.bunkers) b.x = -b.x;
  for (const c of h.cross) { const a = c.xmin; c.xmin = -c.xmax; c.xmax = -a; }
  for (const c of h.cliffs ?? []) c.x = -c.x;
  for (const c of h.hazards ?? []) c.x = -c.x;
}

type E = { x: number; z: number; rx: number; rz: number };
const nearestEdge = (e: E, cx: number, cz: number) => {
  let best = Infinity;
  for (let a = 0; a < Math.PI * 2; a += 0.12) best = Math.min(best, Math.hypot(e.x + Math.cos(a) * e.rx - cx, e.z + Math.sin(a) * e.rz - cz));
  return best;
};
const contains = (e: E, x: number, z: number) => ((x - e.x) / e.rx) ** 2 + ((z - e.z) / e.rz) ** 2 < 1;
/** Nudge hazards so they never overlap the green/fringe or the tee box (author-friendly). */
function pushClear(e: E, cx: number, cz: number, gap: number) {
  for (let it = 0; it < 12; it++) {
    const d = nearestEdge(e, cx, cz);
    if (d >= gap && !contains(e, cx, cz)) return;
    let dx = e.x - cx, dz = e.z - cz;
    const L = Math.hypot(dx, dz) || 1; dx /= L; dz /= L;
    const need = contains(e, cx, cz) ? gap + Math.max(e.rx, e.rz) : gap - d + 0.15;
    e.x += dx * need; e.z += dz * need;
  }
}
function resolveOverlaps(h: Hole) {
  const g = h.green;
  for (const b of h.bunkers) { pushClear(b, g.x, g.z, g.r + FRINGE + 0.8); pushClear(b, h.tee.x, h.tee.z, 9); }
  for (const w of h.water) {
    if (!contains(w, g.x, g.z)) pushClear(w, g.x, g.z, g.r + FRINGE + 1.5); // island greens sit inside on purpose
    pushClear(w, h.tee.x, h.tee.z, 10);
  }
}


// ---------------------------------------------------------------- authoring helpers
// Course files may describe lakes and housing relative to the fairway instead of in raw
// coordinates. side "L"/"R" is the player's left/right; s0..s1 are yards along the path;
// off is the distance from the centreline to the near edge (lakes) or house fronts (homes).
type Side = "L" | "R";
interface LakeSpec { side: Side; s0: number; s1: number; off: number; w: number; }
interface HomeSpec { side: Side; s0: number; s1: number; off: number; road?: boolean; storeys?: number; pools?: number; }
interface BuildingSpec { x: number; z: number; w: number; d: number; h: number; rot?: number; wall?: string; roof?: string; flat?: boolean; }

const WALLS = ["#f4efe6", "#ebe4d6", "#ddd6c8", "#f7f4ee", "#d3cbbd", "#e9e6e1", "#cfd6d8"];
const ROOFS = ["#8a3b2e", "#5b6066", "#3d4247", "#b0593f", "#9aa0a6", "#6e4a3a", "#2f3a45"];

function sampleAt(h: Hole, s: number) {
  const pd = pathData(h);
  const pts = pd.pts;
  let i = 1;
  while (i < pts.length - 1 && pts[i].s < s) i++;
  const a = pts[i - 1], b = pts[i], t = Math.max(0, Math.min(1, (s - a.s) / Math.max(1e-6, b.s - a.s)));
  return { x: a.x + (b.x - a.x) * t, z: a.z + (b.z - a.z) * t, nx: a.nx + (b.nx - a.nx) * t, nz: a.nz + (b.nz - a.nz) * t, total: pd.total };
}
/** world +n is the player's LEFT (the renderer shows +x on screen-left) */
const sideSign = (sd: Side) => (sd === "L" ? 1 : -1);

function expandLakes(h: Hole, lakes: LakeSpec[]) {
  const total = pathData(h).total;
  for (const L of lakes) {
    const r = L.w / 2, step = r * 0.75, sg = sideSign(L.side);
    for (let s = Math.max(0, L.s0); s <= Math.min(total + 30, L.s1); s += step) {
      const p = sampleAt(h, Math.min(s, total));
      const extra = s > total ? s - total : 0; // allow lakes to run past the green
      const c = L.off + r;
      const x = p.x + p.nx * c * sg + (s > total ? 0 : 0), z = p.z + p.nz * c * sg + extra;
      // keep clear of tee and green complex
      if (Math.hypot(x - h.tee.x, z - h.tee.z) < r + 10) continue;
      if (Math.hypot(x - h.green.x, z - h.green.z) < r + h.green.r + FRINGE + 2) continue;
      h.water.push({ x, z, rx: r * 1.05, rz: r * 1.05 });
    }
  }
}

/** Slide any bunker that a lake now overlaps back toward the fairway centreline (or drop it). */
function keepBunkersDry(h: Hole) {
  const wet = (b: { x: number; z: number; rx: number; rz: number }) =>
    h.water.some((w) => Math.hypot((b.x - w.x) / (w.rx + Math.max(b.rx, b.rz) + 2), (b.z - w.z) / (w.rz + Math.max(b.rx, b.rz) + 2)) < 1);
  const g = h.green;
  const ok = (b: { x: number; z: number; rx: number; rz: number }) =>
    !wet(b) && Math.hypot(b.x - g.x, b.z - g.z) >= g.r + FRINGE + Math.max(b.rx, b.rz) + 0.8 &&
    Math.hypot(b.x - h.tee.x, b.z - h.tee.z) > 12;
  h.bunkers = h.bunkers.filter((b) => {
    if (ok(b)) return true;
    const dg = Math.hypot(b.x - g.x, b.z - g.z);
    if (dg < g.r + FRINGE + 16) {
      // greenside: swing around the green to the nearest dry spot
      const a0 = Math.atan2(b.z - g.z, b.x - g.x), rr = Math.max(dg, g.r + FRINGE + Math.max(b.rx, b.rz) + 1);
      for (let k = 1; k <= 12; k++) for (const sg of [1, -1]) {
        const a = a0 + sg * k * 0.26, c = { ...b, x: g.x + Math.cos(a) * rr, z: g.z + Math.sin(a) * rr };
        if (ok(c)) { b.x = c.x; b.z = c.z; return true; }
      }
      return false;
    }
    // fairway bunker: mirror across the centreline to the dry side
    const np = nearestOnPath(h, b.x, b.z), p = pathAt(h, np.s);
    const m = { ...b, x: 2 * p.x - b.x, z: 2 * p.z - b.z };
    if (ok(m)) { b.x = m.x; b.z = m.z; return true; }
    for (let i = 0; i < 30; i++) {
      const dx = p.x - b.x, dz = p.z - b.z, l = Math.hypot(dx, dz) || 1;
      if (l < 2) break;
      b.x += (dx / l) * 1.2; b.z += (dz / l) * 1.2;
      if (ok(b)) return true;
    }
    return false;
  });
}

function expandHomes(h: Hole, homes: HomeSpec[], seed: number): { houses: House[]; roads: Road[] } {
  const R = makeRng(seed);
  const houses: House[] = [], roads: Road[] = [];
  const total = pathData(h).total;
  const clearOf = (x: number, z: number, rad: number) => {
    for (let a = 0; a < 6.28; a += 0.8) {
      const px = x + Math.cos(a) * rad, pz = z + Math.sin(a) * rad;
      const sf = surfaceAt(h, px, pz);
      if (sf !== "rough") return false;
    }
    for (const w of h.water) if (Math.hypot((x - w.x) / (w.rx + rad + 3), (z - w.z) / (w.rz + rad + 3)) < 1) return false;
    if (Math.hypot(x - h.tee.x, z - h.tee.z) < 20 || Math.hypot(x - h.green.x, z - h.green.z) < h.green.r + 22) return false;
    for (const o of houses) if (Math.hypot(o.x - x, o.z - z) < 12) return false;
    return true;
  };
  for (const H of homes) {
    const sg = sideSign(H.side), road: [number, number][] = [];
    for (let s = Math.max(0, H.s0); s <= Math.min(total, H.s1); s += 15 + R() * 3) {
      const p = sampleAt(h, s);
      const w = 11 + R() * 4, d = 12 + R() * 5;
      const off = H.off + d / 2 + (R() - 0.5) * 3;
      const x = p.x + p.nx * off * sg, z = p.z + p.nz * off * sg;
      const rx = p.nx * sg, rz = p.nz * sg; // outward
      road.push([p.x + p.nx * (H.off + 24) * sg, p.z + p.nz * (H.off + 24) * sg]);
      if (!clearOf(x, z, 7)) continue;
      const two = R() < (H.storeys ?? 0.35);
      houses.push({
        x, z, rot: Math.atan2(-rx, -rz), w, d, h: two ? 5.8 : 3.2,
        wall: WALLS[(R() * WALLS.length) | 0], roof: ROOFS[(R() * ROOFS.length) | 0],
        pool: R() < (H.pools ?? 0.45), flat: R() < 0.12,
      });
    }
    if (H.road !== false && road.length > 1) roads.push({ pts: road, w: 7 });
  }
  return { houses, roads };
}

export function normalizeCourse(src: any, id: string): Course {
  const o = JSON.parse(JSON.stringify(src));
  if (!o || !Array.isArray(o.holes) || o.holes.length === 0) throw new Error("No holes[] found");
  const theme: Theme = { ...DEFAULT_THEME, ...(o.theme || {}) };
  const dem = o.dem ? decodeDem(o.dem) : null;
  delete o.dem;
  o.holes.forEach((h: any, i: number) => {
    if (h.frame === "mga") mgaToLocal(h);
    for (const k of ["par", "tee", "pin", "green", "fwHalf"]) if (!(k in h)) throw new Error(`Hole ${i + 1} missing "${k}"`);
    if (!h.green || typeof h.green.r !== "number") throw new Error(`Hole ${i + 1} green malformed`);
    h.water ??= []; h.cross ??= []; h.bunkers ??= [];
    h.green.mounds ??= []; h.green.tx ??= 0; h.green.tz ??= 0;
    h.name ??= `Hole ${i + 1}`;
    h.hills ??= theme.hills;
    h.plateau ??= o.plateau ?? 0;
    h.cliffs ??= [];
    h.hazards ??= [];
    h.greenSpeed ??= theme.greenSpeed ?? 1;
    h.seed ??= i * 3.7 + id.length * 1.3;
    if (!o.noMirror) mirrorHole(h);
    for (const b of (h.buildings ?? []) as BuildingSpec[]) if (!o.noMirror) b.x = -b.x;
    if (dem && h._frame) buildHeightMap(h, dem);
    resolveOverlaps(h as Hole);
    if (Array.isArray(h.lakes)) expandLakes(h as Hole, h.lakes);
    if (Array.isArray(h.lakes)) keepBunkersDry(h as Hole);
    const extra: House[] = ((h.buildings ?? []) as BuildingSpec[]).map((b) => ({
      x: b.x, z: b.z, rot: b.rot ?? 0, w: b.w, d: b.d, h: b.h, wall: b.wall ?? "#efe9df", roof: b.roof ?? "#4a5560", flat: b.flat ?? false,
    }));
    if (Array.isArray(h.homes)) {
      const r = expandHomes(h as Hole, h.homes, (i + 1) * 97 + id.length);
      h.houses = [...extra, ...r.houses]; h.roads = r.roads;
    } else if (extra.length) h.houses = extra;
  });
  return { id, name: o.name ?? "Custom course", tagline: o.tagline ?? "", theme, holes: o.holes as Hole[] };
}

export function parseCourse(text: string): Course {
  let o: any;
  try { o = JSON.parse(text); } catch { throw new Error("Not valid JSON"); }
  return normalizeCourse(o, "custom-" + (o?.name ?? "course").toString().toLowerCase().replace(/[^a-z0-9]+/g, "-"));
}

export const COURSES: Course[] = [normalizeCourse(coastal, "coastal"), normalizeCourse(cliffs, "cliffs"), normalizeCourse(pelican, "pelican"), normalizeCourse(maleny, "maleny"), normalizeCourse(sunshine, "sunshine")];
