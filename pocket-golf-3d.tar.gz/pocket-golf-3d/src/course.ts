import { Hole, FRINGE } from "./holes";
import sunshine from "./courses/sunshine.json";
import coastal from "./courses/coastal.json";
import cliffs from "./courses/cliffs.json";

export interface Theme {
  rough: string; fairway: string; fairway2: string; green: string; fringe: string;
  sand: string; water: string; fog: string;
  trees: "pine" | "broad" | "mix";
  sunElevation: number; sunAzimuth: number; turbidity: number; rayleigh: number;
  hills: number;
}
export const DEFAULT_THEME: Theme = {
  rough: "#3f7a37", fairway: "#5aa84c", fairway2: "#66b556", green: "#6fbf55", fringe: "#5fae4c",
  sand: "#e8d9a8", water: "#2a7fb0", fog: "#c9dde8", trees: "mix",
  sunElevation: 38, sunAzimuth: 150, turbidity: 6, rayleigh: 1.6, hills: 1,
};

export interface Course { id: string; name: string; tagline: string; theme: Theme; holes: Hole[]; }

// Course files are authored with +x = right of the player; the renderer's view has
// +x on screen-left, so mirror every x coordinate once on load.
function mirrorHole(h: any) {
  h.tee.x = -h.tee.x; h.pin.x = -h.pin.x; h.green.x = -h.green.x; h.green.tx = -h.green.tx;
  for (const m of h.green.mounds) m.dx = -m.dx;
  if (Array.isArray(h.path)) h.path = h.path.map((p: number[]) => [-p[0], p[1]]);
  if (typeof h.dogAmp === "number") h.dogAmp = -h.dogAmp;
  for (const w of h.water) w.x = -w.x;
  for (const b of h.bunkers) b.x = -b.x;
  for (const c of h.cross) { const a = c.xmin; c.xmin = -c.xmax; c.xmax = -a; }
  for (const c of h.cliffs ?? []) c.x = -c.x;
}

type E = { x: number; z: number; rx: number; rz: number };
const nearestEdge = (e: E, cx: number, cz: number) => {
  let best = Infinity;
  for (let a = 0; a < Math.PI * 2; a += 0.12) best = Math.min(best, Math.hypot(e.x + Math.cos(a) * e.rx - cx, e.z + Math.sin(a) * e.rz - cz));
  return best;
};
const contains = (e: E, x: number, z: number) => ((x - e.x) / e.rx) ** 2 + ((z - e.z) / e.rz) ** 2 < 1;
/** Nudge hazards so they never overlap the green/fringe or the tee box (author-friendly). */
function pushClear(e: E, cx: number, cz: number, gap: number) {
  for (let it = 0; it < 12; it++) {
    const d = nearestEdge(e, cx, cz);
    if (d >= gap && !contains(e, cx, cz)) return;
    let dx = e.x - cx, dz = e.z - cz;
    const L = Math.hypot(dx, dz) || 1; dx /= L; dz /= L;
    const need = contains(e, cx, cz) ? gap + Math.max(e.rx, e.rz) : gap - d + 0.15;
    e.x += dx * need; e.z += dz * need;
  }
}
function resolveOverlaps(h: Hole) {
  const g = h.green;
  for (const b of h.bunkers) { pushClear(b, g.x, g.z, g.r + FRINGE + 0.8); pushClear(b, h.tee.x, h.tee.z, 9); }
  for (const w of h.water) {
    if (!contains(w, g.x, g.z)) pushClear(w, g.x, g.z, g.r + FRINGE + 1.5); // island greens sit inside on purpose
    pushClear(w, h.tee.x, h.tee.z, 10);
  }
}

export function normalizeCourse(src: any, id: string): Course {
  const o = JSON.parse(JSON.stringify(src));
  if (!o || !Array.isArray(o.holes) || o.holes.length === 0) throw new Error("No holes[] found");
  const theme: Theme = { ...DEFAULT_THEME, ...(o.theme || {}) };
  o.holes.forEach((h: any, i: number) => {
    for (const k of ["par", "tee", "pin", "green", "fwHalf"]) if (!(k in h)) throw new Error(`Hole ${i + 1} missing "${k}"`);
    if (!h.green || typeof h.green.r !== "number") throw new Error(`Hole ${i + 1} green malformed`);
    h.water ??= []; h.cross ??= []; h.bunkers ??= [];
    h.green.mounds ??= []; h.green.tx ??= 0; h.green.tz ??= 0;
    h.name ??= `Hole ${i + 1}`;
    h.hills ??= theme.hills;
    h.plateau ??= o.plateau ?? 0;
    h.cliffs ??= [];
    h.seed ??= i * 3.7 + id.length * 1.3;
    if (!o.noMirror) mirrorHole(h);
    resolveOverlaps(h as Hole);
  });
  return { id, name: o.name ?? "Custom course", tagline: o.tagline ?? "", theme, holes: o.holes as Hole[] };
}

export function parseCourse(text: string): Course {
  let o: any;
  try { o = JSON.parse(text); } catch { throw new Error("Not valid JSON"); }
  return normalizeCourse(o, "custom-" + (o?.name ?? "course").toString().toLowerCase().replace(/[^a-z0-9]+/g, "-"));
}

export const COURSES: Course[] = [normalizeCourse(coastal, "coastal"), normalizeCourse(cliffs, "cliffs"), normalizeCourse(sunshine, "sunshine")];
