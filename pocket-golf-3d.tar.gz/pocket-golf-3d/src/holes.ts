// Course geometry + surface helpers.
// World convention: x = lateral, z = downrange, y = up (yards).
// (Course files are authored with +x = right; course.ts mirrors them on load.)

export type Ellipse = { x: number; z: number; rx: number; rz: number };
export type CrossBand = { z0: number; z1: number; xmin: number; xmax: number };
export type Mound = { dx: number; dz: number; amp: number; spread: number };

export interface GreenDef {
  x: number; z: number; r: number;
  tx: number; tz: number;
  mounds: Mound[];
}

export interface Hole {
  par: number;
  name: string;
  tee: { x: number; z: number };
  pin: { x: number; z: number };
  path?: [number, number][];        // fairway centreline control points, tee -> green
  dogAmp?: number; dogZ0?: number; dogZ1?: number; // legacy simple dogleg
  fwHalf: number;
  fwStart?: number;
  green: GreenDef;
  water: Ellipse[];
  cross: CrossBand[];
  bunkers: Ellipse[];
  hills?: number;
  seed?: number;
  /** clifftop height (yds): everything sits on a plateau except the `cliffs` lowlands and around water */
  plateau?: number;
  /** lowland zones ringed by cliff faces (only used when plateau > 0) */
  cliffs?: Ellipse[];
  len?: number;
}

export type Surface = "tee" | "green" | "fringe" | "fairway" | "rough" | "bunker" | "water";
export const WATER_LEVEL = -0.35;
export const FRINGE = 2.2;

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const smoothstep = (a: number, b: number, x: number) => {
  const t = clamp((x - a) / (b - a), 0, 1);
  return t * t * (3 - 2 * t);
};

export function makeRng(seed: number) {
  let s = Math.floor(Math.abs(seed * 9301 + 49297)) % 233280 || 1;
  return () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
}

// ---------------------------------------------------------------- path
export interface PathSample { x: number; z: number; tx: number; tz: number; nx: number; nz: number; s: number; hw: number; }
export interface PathData { pts: PathSample[]; total: number; bb: { minX: number; maxX: number; minZ: number; maxZ: number } }
const pathCache = new WeakMap<Hole, PathData>();

function legacyX(h: Hole, z: number) {
  const a = h.dogAmp ?? 0, z0 = h.dogZ0 ?? 1, z1 = h.dogZ1 ?? 2;
  return a * smoothstep(z0, z1, z);
}
function controlPts(h: Hole): [number, number][] {
  if (h.path && h.path.length >= 2) return h.path;
  const out: [number, number][] = [];
  const z0 = h.tee.z, z1 = h.green.z;
  for (let k = 0; k <= 10; k++) { const z = z0 + ((z1 - z0) * k) / 10; out.push([legacyX(h, z), z]); }
  out[0] = [h.tee.x, h.tee.z];
  out[out.length - 1] = [h.green.x, h.green.z];
  return out;
}
const cr = (a: number, b: number, c: number, d: number, t: number) => {
  const t2 = t * t, t3 = t2 * t;
  return 0.5 * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3);
};

export function pathData(h: Hole): PathData {
  const cached = pathCache.get(h);
  if (cached) return cached;
  const cp = controlPts(h);
  const raw: { x: number; z: number }[] = [];
  for (let i = 0; i < cp.length - 1; i++) {
    const p0 = cp[Math.max(0, i - 1)], p1 = cp[i], p2 = cp[i + 1], p3 = cp[Math.min(cp.length - 1, i + 2)];
    const steps = Math.max(4, Math.ceil(Math.hypot(p2[0] - p1[0], p2[1] - p1[1]) / 3.5));
    for (let k = 0; k < steps; k++) {
      const t = k / steps;
      raw.push({ x: cr(p0[0], p1[0], p2[0], p3[0], t), z: cr(p0[1], p1[1], p2[1], p3[1], t) });
    }
  }
  const last = cp[cp.length - 1];
  raw.push({ x: last[0], z: last[1] });

  const seed = h.seed ?? 0;
  const pts: PathSample[] = [];
  let s = 0;
  const bb = { minX: Infinity, maxX: -Infinity, minZ: Infinity, maxZ: -Infinity };
  for (let i = 0; i < raw.length; i++) {
    if (i > 0) s += Math.hypot(raw[i].x - raw[i - 1].x, raw[i].z - raw[i - 1].z);
    const a = raw[Math.max(0, i - 1)], b = raw[Math.min(raw.length - 1, i + 1)];
    let tx = b.x - a.x, tz = b.z - a.z;
    const tl = Math.hypot(tx, tz) || 1; tx /= tl; tz /= tl;
    const hw = h.fwHalf * (1 + 0.16 * Math.sin(s * 0.035 + seed) + 0.07 * Math.sin(s * 0.11 + seed * 2.3));
    pts.push({ x: raw[i].x, z: raw[i].z, tx, tz, nx: tz, nz: -tx, s, hw });
    bb.minX = Math.min(bb.minX, raw[i].x - hw); bb.maxX = Math.max(bb.maxX, raw[i].x + hw);
    bb.minZ = Math.min(bb.minZ, raw[i].z - hw); bb.maxZ = Math.max(bb.maxZ, raw[i].z + hw);
  }
  const g = h.green;
  bb.minX = Math.min(bb.minX, g.x - g.r, h.tee.x - 10); bb.maxX = Math.max(bb.maxX, g.x + g.r, h.tee.x + 10);
  bb.minZ = Math.min(bb.minZ, g.z - g.r, h.tee.z - 10); bb.maxZ = Math.max(bb.maxZ, g.z + g.r, h.tee.z + 10);
  const pd = { pts, total: s, bb };
  pathCache.set(h, pd);
  return pd;
}
export const bounds = (h: Hole) => pathData(h).bb;

export function pathAt(h: Hole, s: number): PathSample {
  const { pts } = pathData(h);
  if (s <= 0) return pts[0];
  if (s >= pts[pts.length - 1].s) return pts[pts.length - 1];
  let lo = 0, hi = pts.length - 1;
  while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (pts[mid].s < s) lo = mid; else hi = mid; }
  const a = pts[lo], b = pts[hi], t = (s - a.s) / (b.s - a.s || 1);
  const L = (u: number, v: number) => u + (v - u) * t;
  return { x: L(a.x, b.x), z: L(a.z, b.z), tx: L(a.tx, b.tx), tz: L(a.tz, b.tz), nx: L(a.nx, b.nx), nz: L(a.nz, b.nz), s, hw: L(a.hw, b.hw) };
}

export function nearestOnPath(h: Hole, x: number, z: number): { d: number; s: number; hw: number } {
  const { pts } = pathData(h);
  let best = Infinity, bs = 0, bhw = pts[0].hw;
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i], b = pts[i + 1];
    const vx = b.x - a.x, vz = b.z - a.z, L = vx * vx + vz * vz || 1;
    let t = ((x - a.x) * vx + (z - a.z) * vz) / L;
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    const px = a.x + vx * t, pz = a.z + vz * t, d = (x - px) * (x - px) + (z - pz) * (z - pz);
    if (d < best) { best = d; bs = a.s + (b.s - a.s) * t; bhw = a.hw + (b.hw - a.hw) * t; }
  }
  return { d: Math.sqrt(best), s: bs, hw: bhw };
}

// ---------------------------------------------------------------- green
export function greenH(h: Hole, x: number, z: number): number {
  const g = h.green, lx = x - g.x, lz = z - g.z;
  let hgt = g.tx * lx + g.tz * lz;
  for (const m of g.mounds) hgt += m.amp * Math.exp(-((lx - m.dx) ** 2 + (lz - m.dz) ** 2) / m.spread);
  return hgt;
}
export function greenGrad(h: Hole, x: number, z: number) {
  const e = 0.5;
  return { gx: (greenH(h, x + e, z) - greenH(h, x - e, z)) / (2 * e), gz: (greenH(h, x, z + e) - greenH(h, x, z - e)) / (2 * e) };
}
export const onGreen = (h: Hole, x: number, z: number) => Math.hypot(x - h.green.x, z - h.green.z) <= h.green.r;
export const onFringe = (h: Hole, x: number, z: number) => Math.hypot(x - h.green.x, z - h.green.z) <= h.green.r + FRINGE;

const ellD = (x: number, z: number, e: Ellipse) => Math.sqrt(((x - e.x) / e.rx) ** 2 + ((z - e.z) / e.rz) ** 2);

export function surfaceAt(h: Hole, x: number, z: number): Surface {
  if (Math.hypot(x - h.tee.x, z - h.tee.z) < 4.5) return "tee";
  const dg = Math.hypot(x - h.green.x, z - h.green.z);
  if (dg <= h.green.r) return "green";
  if (dg <= h.green.r + FRINGE) return "fringe";
  for (const c of h.cross) if (z >= c.z0 && z <= c.z1 && x >= c.xmin && x <= c.xmax) return "water";
  for (const w of h.water) if (ellD(x, z, w) <= 1) return "water";
  for (const b of h.bunkers) if (ellD(x, z, b) <= 1) return "bunker";
  const np = nearestOnPath(h, x, z);
  if (np.s >= (h.fwStart ?? 12) && np.d <= np.hw && lowland(h, x, z) < 0.5) return "fairway";
  return "rough";
}

// ---------------------------------------------------------------- terrain
function terrainRaw(x: number, z: number, seed: number): number {
  x += seed * 13.7; z += seed * 7.3;
  return (
    2.6 * Math.sin(x * 0.045 + 0.7) * Math.cos(z * 0.03) +
    1.7 * Math.sin(z * 0.018 + x * 0.008) +
    1.2 * Math.cos(x * 0.02 - z * 0.025) +
    0.55 * Math.sin(x * 0.11 + z * 0.07)
  );
}
// signed distance outside a crossing band (negative inside)
function bandSD(c: CrossBand, x: number, z: number): number {
  const dx = Math.max(c.xmin - x, 0, x - c.xmax), dz = Math.max(c.z0 - z, 0, z - c.z1);
  if (dx > 0 || dz > 0) return Math.hypot(dx, dz);
  return -Math.min(x - c.xmin, c.xmax - x, z - c.z0, c.z1 - z);
}
export function waterInfluence(h: Hole, x: number, z: number): number {
  let k = 0;
  for (const w of h.water) k = Math.max(k, 1 - smoothstep(0.62, 1.0, ellD(x, z, w)));
  for (const c of h.cross) k = Math.max(k, 1 - smoothstep(-3, 0.5, bandSD(c, x, z)));
  if (k > 0) k *= smoothstep(h.green.r + FRINGE, h.green.r + FRINGE + 1.5, Math.hypot(x - h.green.x, z - h.green.z));
  return k;
}
/**
 * Make the drawn shoreline coincide with the hazard edge used by the physics:
 * ground is held below the waterline inside water and above it just outside.
 */
function waterClamp(h: Hole, x: number, z: number, y: number): number {
  let depth = -1, floor = -Infinity;
  for (const w of h.water) {
    const n = ellD(x, z, w);
    if (n < 1) depth = Math.max(depth, (1 - n) * Math.min(w.rx, w.rz));
    else if (n < 1.5) floor = Math.max(floor, WATER_LEVEL + 0.1 + (n - 1) * 0.7);
  }
  for (const c of h.cross) {
    const sd = bandSD(c, x, z);
    if (sd <= 0) depth = Math.max(depth, -sd);
    else if (sd < 9) floor = Math.max(floor, WATER_LEVEL + 0.1 + sd * 0.05);
  }
  if (depth >= 0) {
    // island greens (and their fringe) stay dry
    if (Math.hypot(x - h.green.x, z - h.green.z) <= h.green.r + FRINGE + 0.4) return Math.max(y, WATER_LEVEL + 0.15);
    return Math.max(WATER_LEVEL - 0.95, Math.min(y, WATER_LEVEL - 0.1 - depth * 0.12));
  }
  return floor > -Infinity ? Math.max(y, floor) : y;
}
function bunkerDepth(h: Hole, x: number, z: number): number {
  let d = 0;
  for (const b of h.bunkers) { const n = ellD(x, z, b); if (n < 1) d = Math.max(d, 0.32 * (1 - n * n)); }
  return d;
}
function edgeFalloff(h: Hole, x: number, z: number): number {
  const bb = bounds(h);
  const dx = Math.max(bb.minX - 100 - x, 0, x - (bb.maxX + 100));
  const dz = Math.max(bb.minZ - 100 - z, 0, z - (bb.maxZ + 100));
  return 1 - smoothstep(0, 60, Math.max(dx, dz));
}
// mid-scale rolls that live on the fairway itself (wavelength ~30-60 yds)
function undulation(x: number, z: number, seed: number): number {
  x += seed * 5.1; z += seed * 3.3;
  return (
    0.95 * Math.sin(x * 0.11 + z * 0.045) * Math.cos(z * 0.09 - x * 0.03) +
    0.6 * Math.sin(z * 0.16 + 1.7 + Math.sin(x * 0.05) * 1.5) +
    0.3 * Math.cos(x * 0.21 - z * 0.13)
  );
}
/** 1 = down in a lowland (below the cliffs), 0 = up on the plateau. Faces are ~3.5 yds wide with a ragged edge. */
export function lowland(h: Hole, x: number, z: number): number {
  if (!h.plateau) return 0;
  const rag = Math.sin(x * 0.31 + z * 0.07) * Math.sin(z * 0.37 - x * 0.11) * 1.4 + Math.sin(x * 0.9 + z * 1.1) * 0.35;
  let t = Infinity;
  const ell = (e: Ellipse, grow: number) => {
    const rx = e.rx * grow, rz = e.rz * grow;
    const n = Math.sqrt(((x - e.x) / rx) ** 2 + ((z - e.z) / rz) ** 2);
    t = Math.min(t, (n - 1) * Math.min(rx, rz));
  };
  for (const c of h.cliffs ?? []) ell(c, 1);
  for (const w of h.water) ell(w, 1.3);
  for (const c of h.cross) t = Math.min(t, bandSD(c, x, z) - 7);
  // keep the green complex and tee on the clifftop
  const keep = Math.min(Math.hypot(x - h.green.x, z - h.green.z) - h.green.r - FRINGE - 1, Math.hypot(x - h.tee.x, z - h.tee.z) - 7);
  if (keep < 0) t = Math.max(t, -keep);
  return 1 - smoothstep(-3.5, 0, t + rag);
}
export function terrainH(h: Hole, x: number, z: number): number {
  const e = edgeFalloff(h, x, z);
  if (e <= 0) return 0;
  const np = nearestOnPath(h, x, z);
  const mFw = clamp((np.d - (np.hw + 4)) / 20, 0, 1);
  // areas that must stay calm: green complex, tee, water banks
  let mFlat = 1;
  const dg = Math.hypot(x - h.green.x, z - h.green.z);
  if (dg < h.green.r + 15) mFlat = Math.min(mFlat, clamp((dg - h.green.r - 1) / 14, 0, 1));
  const dt = Math.hypot(x - h.tee.x, z - h.tee.z);
  if (dt < 28) mFlat = Math.min(mFlat, clamp((dt - 10) / 18, 0, 1));
  for (const w of h.water) { const n = ellD(x, z, w); if (n < 2.4) mFlat = Math.min(mFlat, clamp((n - 1.15) / 1.0, 0, 1)); }
  for (const c of h.cross) { const sd = bandSD(c, x, z); if (sd < 26) mFlat = Math.min(mFlat, clamp((sd - 3) / 18, 0, 1)); }
  const hills = h.hills ?? 1;
  const big = Math.min(0.42 + 0.58 * mFw, 0.12 + 0.88 * mFlat);
  let y = terrainRaw(x, z, h.seed ?? 0) * hills * big * e;
  // rolling fairway / semi-rough humps (fade out into the rough where the big hills take over)
  y += undulation(x, z, h.seed ?? 0) * 0.85 * hills * (1 - mFw * 0.6) * smoothstep(0, 1, mFlat) * e;
  // greens sit on a gently pushed-up pad
  if (dg < h.green.r + 14) y = Math.max(y, 0.25) * (1 - smoothstep(h.green.r, h.green.r + 14, dg)) + y * smoothstep(h.green.r, h.green.r + 14, dg) + 0.35 * (1 - smoothstep(h.green.r + 1, h.green.r + 12, dg));
  const k = waterInfluence(h, x, z);
  if (k > 0) y += (WATER_LEVEL - 0.55 - y) * k;
  if (h.plateau) y += h.plateau * (1 - lowland(h, x, z)) * e;
  y = waterClamp(h, x, z, y);
  return y - bunkerDepth(h, x, z);
}
export function groundH(h: Hole, x: number, z: number): number {
  const dg = Math.hypot(x - h.green.x, z - h.green.z);
  const w = 1 - smoothstep(h.green.r, h.green.r + 3, dg);
  return terrainH(h, x, z) + (w > 0 ? greenH(h, x, z) * w : 0);
}

// ---------------------------------------------------------------- trees
export type Tree = { x: number; z: number; h: number; r: number; kind: 0 | 1 };
export function buildTrees(h: Hole, pref: "pine" | "broad" | "mix", density: number): Tree[] {
  const R = makeRng((h.seed ?? 1) * 17 + 3);
  const T: Tree[] = [];
  const kind = (): 0 | 1 => (pref === "pine" ? (R() < 0.85 ? 0 : 1) : pref === "broad" ? (R() < 0.12 ? 0 : 1) : R() < 0.5 ? 0 : 1);
  const ok = (x: number, z: number, minPath: number) => {
    if (surfaceAt(h, x, z) !== "rough") return false;
    if (waterInfluence(h, x, z) > 0.05) return false;
    if (h.plateau && lowland(h, x, z) > 0.02) return false;
    const np = nearestOnPath(h, x, z);
    if (np.d < np.hw + minPath) return false;
    if (Math.hypot(x - h.green.x, z - h.green.z) < h.green.r + 11) return false;
    if (Math.hypot(x - h.tee.x, z - h.tee.z) < 12) return false;
    return true;
  };
  const push = (x: number, z: number) => {
    const k = kind();
    T.push({ x, z, kind: k, h: k === 0 ? 9 + R() * 6 : 7 + R() * 4, r: k === 0 ? 2.4 + R() * 1.4 : 3 + R() * 1.8 });
  };
  const pd = pathData(h);
  const step = 13 / density;
  for (let s = 18; s < pd.total; s += step) {
    const p = pathAt(h, s);
    for (const side of [-1, 1]) {
      for (let row = 0; row < 2; row++) {
        const off = p.hw + 9 + row * 9 + R() * 10;
        const x = p.x + p.nx * off * side + (R() - 0.5) * 5, z = p.z + p.nz * off * side + (R() - 0.5) * 5;
        if (ok(x, z, 7)) push(x, z);
      }
    }
  }
  // forest scatter further out
  const bb = pd.bb;
  for (let i = 0; i < 700 * density; i++) {
    const x = bb.minX - 60 + R() * (bb.maxX - bb.minX + 120);
    const z = bb.minZ - 60 + R() * (bb.maxZ - bb.minZ + 120);
    if (ok(x, z, 24)) push(x, z);
  }
  // backdrop behind the green
  const end = pd.pts[pd.pts.length - 1];
  for (let k = -6; k <= 6; k++) {
    const x = h.green.x + end.tx * (h.green.r + 22 + R() * 8) + end.nx * k * 6;
    const z = h.green.z + end.tz * (h.green.r + 22 + R() * 8) + end.nz * k * 6;
    if (ok(x, z, 8)) push(x, z);
  }
  return T;
}
