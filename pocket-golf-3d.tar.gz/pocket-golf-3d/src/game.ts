import * as THREE from "three";
import { World } from "./world";
import { Hole, Surface, surfaceAt, pathData, pathAt, nearestOnPath, groundH, smoothstep } from "./holes";
import { Course, COURSES, parseCourse } from "./course";
import { Look, loadLook, saveLook, randomLook, lookSVG, HATS, HAIRS, HAT_COLORS, HAIR_COLORS, SHIRT_COLORS, PANTS_COLORS, SKIN_TONES } from "./look";
import { CLUBS, Club, chooseClub, difficulty, Difficulty, Flight, previewPutt, lieRating, impactZones, PUTTER, BAG_SIZE, DEFAULT_BAG, clubById } from "./physics";
import { Online, BoardPair, rankOf, strokesReceived } from "./online";
import { Sfx } from "./sfx";
import { Minimap } from "./minimap";

type Phase = "title" | "intro" | "aim" | "power" | "impact" | "swinging" | "flight" | "done" | "card";

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const $ = (id: string) => document.getElementById(id) as HTMLElement;
const store = {
  get(k: string) { try { return localStorage.getItem(k); } catch { return null; } },
  set(k: string, v: string) { try { localStorage.setItem(k, v); } catch { /* storage unavailable */ } },
};
const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]!);
const LIE: Record<Surface, string> = { tee: "Tee", green: "Green", fringe: "Fringe", fairway: "Fairway", rough: "Rough", bunker: "Bunker", water: "Water", hazard: "Hazard" };
const relPar = (n: number) => (n === 0 ? "E" : n > 0 ? `+${n}` : `${n}`);
/** plus handicaps show as +2.0 */
function fmtHcap(h: number) { return h < 0 ? `+${(-h).toFixed(1)}` : (Math.round(h * 10) / 10).toFixed(1); }
function loadBag(): Club[] {
  const ids = (store.get("pg3d.bag") || DEFAULT_BAG.join(",")).split(",");
  const clubs = ids.map(clubById).filter((c, i, a) => a.indexOf(c) === i && c.id !== "putter");
  const pick = clubs.length === BAG_SIZE - 1 ? clubs : DEFAULT_BAG.filter((id) => id !== "putter").map(clubById);
  return [...pick, PUTTER];
}
function scoreName(s: number, par: number) {
  if (s === 1) return "Hole in one!";
  const d = s - par;
  return d <= -3 ? "Albatross!" : d === -2 ? "Eagle!" : d === -1 ? "Birdie!" : d === 0 ? "Par" : d === 1 ? "Bogey" : d === 2 ? "Double bogey" : `+${d}`;
}
function scoreClass(s: number, par: number) {
  const d = s - par;
  return s === 1 || d <= -2 ? "eagle" : d === -1 ? "birdie" : d === 0 ? "par" : d === 1 ? "bogey" : "dbl";
}

export class Game {
  private sfx = new Sfx();
  private mini: Minimap;
  private courses: Course[] = [...COURSES];
  private course: Course;
  private hole!: Hole;
  private holeI = 0;
  private scores: number[] = [];

  private ball = { x: 0, z: 0 };
  private strokes = 0;
  private club: Club = CLUBS[0];
  private bag: Club[] = loadBag();
  private bagDraft: string[] = [];
  online = new Online();
  private si: number[] = [];
  private roundId = "";
  /** which part of an 18-hole course this round covers */
  private play: "18" | "9f" | "9b" = "18";
  private firstHole = 0;
  private lastHole = 0;
  private recv: number[] = [];
  private heading = 0;
  private wind = { x: 0, z: 0, mph: 0 };
  private phase: Phase = "title";

  private flight: Flight | null = null;
  private heroShot = false;
  private look: Look = loadLook();
  private splashed = false;
  private pending: { power: number; off: number; club: Club; th: number; diff: Difficulty } | null = null;
  private curDiff: Difficulty = { pm: 1, disp: 0, ms: 1, sweet: 1, pspeed: 1 };
  private meter = { power: 0, pdir: 1, impact: 0, idir: 1, lp: 0, li: 0.5 };
  private golferAng = 12;
  private golferT = 0;
  private launched = false;

  private overhead = false;
  private aimDrag: { x: number; th0: number } | null = null;
  private spinDrag: { x: number; y: number; h0: number; v0: number } | null = null;
  private cam = { p: new THREE.Vector3(0, 8, -10), l: new THREE.Vector3(0, 0, 40) };
  private camSnap = true;
  private introT = 0;
  private time = 0;
  private ray = new THREE.Raycaster();
  private plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
  private puttKey = "";
  private toastT = 0;
  private hintShown = store.get("pg3d.hint") === "1";

  constructor(private world: World, private high: boolean) {
    this.mini = new Minimap($("minimap") as HTMLCanvasElement);
    this.sfx.enabled = store.get("pg3d.sound") !== "off";
    const last = store.get("pg3d.course");
    this.course = this.courses.find((c) => c.id === last) ?? this.courses[0];
    this.buildClubs();
    this.bindUI();
    this.applyCourseVisual();
    this.applyLook();
    this.showTitle();
    this.online.onChange = () => this.onOnlineChange();
    this.online.init();
  }
  /** hidden per-player difficulty (set in the Players sheet) */
  private get mod() { return this.online.player?.difficulty ?? 0; }

  // ================================================================ helpers
  private pin() { return this.hole.pin; }
  private distPin() { return Math.hypot(this.ball.x - this.pin().x, this.ball.z - this.pin().z); }
  private lie(): Surface { return surfaceAt(this.hole, this.ball.x, this.ball.z); }
  private yards(h: Hole) { return Math.round(pathData(h).total); }
  private roundRel() {
    let r = 0;
    this.scores.forEach((s, i) => { if (s) r += s - this.course.holes[i].par; });
    return r;
  }
  private aimReset() {
    const d = this.distPin();
    if (this.club.id === "putter" || d <= this.club.max * 1.02) {
      this.heading = Math.atan2(this.pin().x - this.ball.x, this.pin().z - this.ball.z);
      return;
    }
    const np = nearestOnPath(this.hole, this.ball.x, this.ball.z);
    const tgt = pathAt(this.hole, Math.min(pathData(this.hole).total, np.s + this.club.max * 0.86));
    this.heading = Math.atan2(tgt.x - this.ball.x, tgt.z - this.ball.z);
  }
  private newWind() {
    const k = 1 + 0.25 * this.mod;
    const a = Math.random() * Math.PI * 2, m = (3 + Math.random() * 16) * k;
    this.wind = { x: Math.sin(a) * m, z: Math.cos(a) * m, mph: m };
    this.world.setWind(this.wind.x, this.wind.z, m);
  }
  /** Harder players get a wind that shifts a little between shots. */
  private shiftWind() {
    if (this.mod <= 0) return;
    const a = Math.atan2(this.wind.x, this.wind.z) + (Math.random() - 0.5) * 0.5 * this.mod;
    const m = Math.max(1, this.wind.mph + (Math.random() - 0.5) * 5 * this.mod);
    this.wind = { x: Math.sin(a) * m, z: Math.cos(a) * m, mph: m };
    this.world.setWind(this.wind.x, this.wind.z, m);
  }
  private setImpactZones(k: number) {
    const z = impactZones(k), pct = (v: number) => (v * 100).toFixed(1) + "%";
    const set = (cls: string, a: number, b: number) => { const el = document.querySelector(`#impactWrap .zone.${cls}`) as HTMLElement | null; if (el) { el.style.left = pct(a); el.style.width = pct(b - a); } };
    set("draw", z.shaped[0], z.pure[0]); set("pure", z.pure[0], z.pure[1]); set("fade", z.pure[1], z.shaped[1]);
  }
  private toast(html: string, secs = 2.6) {
    const t = $("toast");
    t.innerHTML = html;
    t.classList.add("show");
    this.toastT = secs;
  }

  // ================================================================ title / course select
  /** Stroke index: hardest hole (longest for its par) = 1. */
  private computeSI() {
    const hs = this.course.holes, n = hs.length;
    const diffOf = (h: Hole) => this.yards(h) / (h.par === 3 ? 190 : h.par === 4 ? 400 : 520);
    const order = hs.map((h, i) => ({ i, d: diffOf(h) })).sort((a, b) => b.d - a.d);
    this.si = new Array(n);
    order.forEach((o, rank) => { this.si[o.i] = rank + 1; });
  }
  private hcap() { return this.online.player?.hcap ?? 0; }
  /** handicap strokes are fixed at the start of each round */
  private netFor(i: number, strokes: number) { return strokes - (this.recv[i] ?? 0); }
  private applyCourseVisual() {
    this.computeSI();
    this.world.setTheme(this.course.theme);
    this.hole = this.course.holes[0];
    this.holeI = 0;
    this.world.loadHole(this.hole);
    this.mini.setHole(this.hole, this.course.theme);
    this.ball = { ...this.hole.tee };
    this.newWind();
  }
  private applyLook() { this.world.setLook(this.look); }
  private openLooker() { this.renderLooker(); $("looker").classList.remove("hidden"); this.sfx.click(); }
  private renderLooker() {
    $("lookPreview").innerHTML = lookSVG(this.look);
    const wrap = $("lookOpts");
    wrap.innerHTML = "";
    const L = this.look as unknown as Record<string, string>;
    const set = (k: string, v: string) => { L[k] = v; this.applyLook(); this.renderLooker(); saveLook(this.look); this.sfx.click(); };
    const row = (label: string, build: (box: HTMLElement) => void) => {
      const r = document.createElement("div"); r.className = "look-row";
      r.innerHTML = `<div class="look-label">${label}</div>`;
      const box = document.createElement("div"); box.className = "chips"; build(box); r.appendChild(box); wrap.appendChild(r);
    };
    const chips = (k: string, opts: [string, string][]) => (box: HTMLElement) => {
      for (const [v, name] of opts) {
        const b = document.createElement("button"); b.className = "chip" + (L[k] === v ? " on" : ""); b.textContent = name;
        b.onclick = () => set(k, v); box.appendChild(b);
      }
    };
    const swatches = (k: string, cols: string[]) => (box: HTMLElement) => {
      for (const c of cols) {
        const b = document.createElement("button"); b.className = "sw" + (L[k].toLowerCase() === c.toLowerCase() ? " on" : "");
        b.style.setProperty("--c", c); b.setAttribute("aria-label", c);
        b.onclick = () => set(k, c); box.appendChild(b);
      }
    };
    row("Hat", chips("hat", HATS));
    if (this.look.hat !== "none") row("Hat colour", swatches("hatColor", HAT_COLORS));
    row("Hair", chips("hair", HAIRS));
    if (this.look.hair !== "bald") row("Hair colour", swatches("hairColor", HAIR_COLORS));
    row("Shirt", swatches("shirt", SHIRT_COLORS));
    row("Trousers", swatches("pants", PANTS_COLORS));
    row("Skin", swatches("skin", SKIN_TONES));
  }
  private showTitle() {
    this.phase = "title";
    this.overhead = false;
    for (const id of ["hud", "introCard", "resultCard", "scorecard", "menu", "help"]) $(id).classList.add("hidden");
    $("title").classList.remove("hidden");
    this.renderCourseList();
    this.syncQualityLabels();
  }
  private renderCourseList() {
    const wrap = $("courseList");
    wrap.innerHTML = "";
    for (const c of this.courses) {
      const par = c.holes.reduce((a, h) => a + h.par, 0);
      const best = store.get("pg3d.best." + c.id);
      const el = document.createElement("button");
      el.className = "course-card" + (c === this.course ? " sel" : "");
      el.style.setProperty("--cc", c.theme.fairway);
      el.style.setProperty("--cw", c.theme.water);
      el.innerHTML = `<div class="cc-swatch"></div><div class="cc-body"><div class="cc-name">${esc(c.name)}</div>
        <div class="cc-tag">${esc(c.tagline || "Custom course")}</div>
        <div class="cc-meta"><span>${c.holes.length} holes</span><span>Par ${par}</span><span>${best ? `Best ${best} (${relPar(+best - par)})` : "No rounds yet"}</span></div></div>`;
      el.onclick = () => {
        if (c === this.course) return;
        this.course = c;
        store.set("pg3d.course", c.id);
        this.applyCourseVisual();
        this.renderCourseList();
        this.sfx.click();
      };
      wrap.appendChild(el);
    }
  }
  private startRound() {
    this.sfx.unlock();
    this.scores = [];
    this.roundId = Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
    const n = this.course.holes.length, hc = this.hcap();
    this.recv = this.course.holes.map((_, i) => strokesReceived(hc, this.si[i] ?? 1, n));
    this.online.loadBoard(this.course.id, true);
    for (const id of ["title", "scorecard", "menu", "help", "resultCard"]) $(id).classList.add("hidden");
    $("hud").classList.remove("hidden");
    const N = this.course.holes.length;
    if (N < 18) this.play = "18";
    this.firstHole = this.play === "9b" ? 9 : 0;
    this.lastHole = this.play === "9f" ? 8 : N - 1;
    this.loadHole(this.firstHole);
  }

  // ================================================================ hole flow
  private loadHole(i: number) {
    this.holeI = i;
    this.hole = this.course.holes[i];
    // the round runs from sunrise on the first tee to sunset on the last green
    const span = this.lastHole - this.firstHole, f = span > 0 ? (i - this.firstHole) / span : 0.5;
    this.world.setTimeOfDay(f);
    this.world.loadHole(this.hole);
    this.mini.setHole(this.hole, this.course.theme);
    this.ball = { ...this.hole.tee };
    this.strokes = 0;
    this.flight = null;
    this.overhead = false;
    this.newWind();
    this.club = chooseClub(this.bag, this.distPin(), "tee");
    this.aimReset();
    this.golferAng = 12;
    this.phase = "intro";
    this.introT = 0;
    this.toastT = 0;
    $("toast").classList.remove("show");
    $("resultCard").classList.add("hidden");
    $("icNum").textContent = `${i + 1}`;
    $("icName").textContent = this.hole.name;
    const mins = Math.round((6 * 60 + f * 12.5 * 60) / 5) * 5, hh = Math.floor(mins / 60), mm = mins % 60;
    const clock = `${((hh + 11) % 12) + 1}:${String(mm).padStart(2, "0")} ${hh < 12 ? "am" : "pm"}`;
    const when = f < 0.08 ? "Sunrise" : f > 0.92 ? "Sunset" : f < 0.22 ? "Morning" : f > 0.75 ? "Golden hour" : "";
    $("icMeta").textContent = `Par ${this.hole.par} · ${this.yards(this.hole)} yds · ${when ? when + " " : ""}${clock}`;
    this.renderIntroBoard();
    const ic = $("introCard");
    ic.classList.remove("hidden");
    ic.classList.remove("fade");
    this.updateHUD();
  }
  private endIntro() {
    if (this.phase !== "intro") return;
    this.phase = "aim";
    this.camSnap = false;
    $("introCard").classList.add("fade");
    setTimeout(() => $("introCard").classList.add("hidden"), 350);
    if (!this.hintShown) $("hint").classList.remove("hidden");
    this.updateHUD();
  }
  private nextHole() {
    $("resultCard").classList.add("hidden");
    if (this.holeI < this.lastHole) this.loadHole(this.holeI + 1);
    else this.showScorecard(true);
  }

  // ================================================================ swing
  primary() {
    this.sfx.unlock();
    switch (this.phase) {
      case "intro": this.endIntro(); break;
      case "aim": this.startSwing(); break;
      case "power": this.lockPower(); break;
      case "impact": this.lockImpact(); break;
      case "done": this.nextHole(); break;
      default: break;
    }
  }
  private startSwing() {
    this.overhead = false;
    this.curDiff = difficulty(this.club, this.lie(), this.mod);
    this.setImpactZones(this.curDiff.sweet);
    this.phase = "power";
    this.meter.power = 0; this.meter.pdir = 1;
    $("hint").classList.add("hidden");
    if (this.curDiff.disp > 0.08) this.toast(`<b class="gold">Tricky lie</b> — less power & control`);
    this.updateHUD();
  }
  private lockPower() {
    this.meter.lp = this.meter.power;
    this.phase = "impact";
    this.meter.impact = 0; this.meter.idir = 1;
    this.updateHUD();
  }
  private lockImpact() {
    this.meter.li = this.meter.impact;
    this.phase = "swinging";
    this.golferT = 0;
    this.launched = false;
    this.pending = { power: this.meter.lp, off: (0.5 - this.meter.li) * 2, club: this.club, th: this.heading, diff: this.curDiff };
    this.updateHUD();
  }
  private launch() {
    const p = this.pending!;
    this.flight = new Flight(this.hole, { ...p, origin: { ...this.ball }, wind: this.wind });
    this.splashed = false;
    this.phase = "flight";
    this.world.trailStart();
    const a = Math.abs(p.off);
    this.heroShot = p.club.id !== "putter" && a <= 0.1 && p.power >= 0.95;
    if (p.club.id === "putter") this.sfx.putt();
    else if (this.heroShot) this.sfx.perfect(p.club.id === "driver");
    else this.sfx.strike(p.power);
    navigator.vibrate?.(p.club.id === "putter" ? 8 : this.heroShot ? [30, 40, 60] : 18);
    if (p.club.id !== "putter") {
      if (this.heroShot) this.toast(`<b class="gold">PERFECT!</b> Flushed it`, 1.8);
      else if (a <= 0.1) this.toast(`<b class="green">Pure strike!</b>`, 1.4);
      else if (a <= 0.28) this.toast(p.off > 0 ? "Draw" : "Fade", 1.2);
      else this.toast(`<b class="warn">${p.off > 0 ? "Hook!" : "Slice!"}</b>`, 1.4);
    }
    this.updateHUD();
  }
  private finalize() {
    const r = this.flight!.result!;
    this.flight = null;
    this.world.trailStop();
    this.ball = { x: r.rest.x, z: r.rest.z };
    this.strokes += r.water ? 2 : 1;
    const d = this.distPin();
    if (r.holed || d < 1.5) { this.holeOut(); return; }
    const lie = this.lie();
    this.club = chooseClub(this.bag, d, lie);
    this.shiftWind();
    this.aimReset();
    this.phase = "aim";
    const where = r.water ? (r.hazard === "grass" ? `<b class="warn">Lost in the long stuff!</b> +1 penalty, dropped` : `<b class="warn">Splash!</b> +1 penalty, dropped`) :
      lie === "green" ? `On the green · <b>${Math.round(d * 3)} ft</b>` :
      lie === "fringe" ? `On the fringe · <b>${Math.round(d * 3)} ft</b>` :
      `${LIE[lie]} · <b>${Math.round(d)}</b> yds to pin`;
    this.toast(where);
    this.updateHUD();
  }
  private holeOut() {
    this.ball = { ...this.pin() };
    this.scores[this.holeI] = this.strokes;
    this.phase = "done";
    this.toastT = 0;
    $("toast").classList.remove("show");
    this.sfx.cup();
    const diff = this.strokes - this.hole.par;
    // the gallery reacts: roar for birdie or better, applause for par, a groan when it's over par
    setTimeout(() => {
      if (diff <= -1) { this.sfx.roar(diff <= -2 ? 1.4 : 1); this.world.crowdReact("cheer"); }
      else if (diff === 0) { this.sfx.applause(); this.world.crowdReact("clap"); }
      else { this.sfx.groan(Math.min(1.4, 0.8 + diff * 0.25)); this.world.crowdReact("groan"); }
    }, 250);
    navigator.vibrate?.([20, 40, 20]);
    const last = this.holeI === this.lastHole;
    $("rcLabel").textContent = scoreName(this.strokes, this.hole.par);
    $("rcLabel").className = "rc-label " + scoreClass(this.strokes, this.hole.par);
    $("rcSub").textContent = `${this.strokes} stroke${this.strokes === 1 ? "" : "s"} · Par ${this.hole.par} · Round ${relPar(this.roundRel())}`;
    $("rcNext").textContent = last ? "See scorecard" : `Hole ${this.holeI + 2} →`;
    this.submitHole();
    this.renderStrip();
    this.renderResultBoard();
    $("resultCard").classList.remove("hidden");
    if (last && this.play === "18") {
      const tot = this.scores.reduce((a, b) => a + (b || 0), 0);
      const key = "pg3d.best." + this.course.id, prev = Number(store.get(key) || 0);
      if (!prev || tot < prev) store.set(key, String(tot));
    }
    this.updateHUD();
  }

  // ================================================================ online scores
  private submitHole() {
    const i = this.holeI, c = this.course, N = c.holes.length;
    this.online.submitHole({
      roundId: this.roundId, course: c.id, holes: N, hole: i + 1, strokes: this.strokes,
      pars: c.holes.map((h) => h.par), recv: this.recv, bag: this.bagCode(), hcap: this.hcap(), play: this.play,
    });
    this.online.record({ type: "hole", course: c.id, key: String(i + 1), strokes: this.strokes, net: this.netFor(i, this.strokes) });
    // completed segments: front 9 / back 9 / full 18 (or the whole of a 9-hole course)
    const seg = (key: string, a: number, b: number) => {
      let g = 0, n = 0;
      for (let k = a; k <= b; k++) { const sc = this.scores[k]; if (!sc) return; g += sc; n += this.netFor(k, sc); }
      this.online.record({ type: "round", course: c.id, key, strokes: g, net: n });
    };
    if (N >= 18) {
      if (i === 8) seg("9f", 0, 8);
      if (i === 17) { seg("9b", 9, 17); seg("18", 0, 17); }
    } else if (i === N - 1) seg(String(N), 0, N - 1);
  }
  private onOnlineChange() {
    const p = this.online.player, chip = $("tPlayer");
    chip.classList.toggle("hidden", !this.online.enabled);
    chip.innerHTML = p ? `Playing as <b>${esc(p.name)}</b> · hcap ${fmtHcap(p.hcap)}` : `Sign in for leaderboards`;
    if (this.phase === "intro") this.renderIntroBoard();
    if (!$("boards").classList.contains("hidden")) this.renderBoards();
  }
  private boardHtml(pair: BoardPair | undefined, me: string | undefined, rows = 3, foot = "") {
    const col = (title: string, list: { name: string; score: number }[]) => {
      if (!list.length) return `<div class="mb-col"><h4>${title}</h4><div class="mb-row"><span class="dim">No scores yet</span></div></div>`;
      let pos = 0, prev = NaN;
      const items = list.slice(0, rows).map((r, i) => {
        if (r.score !== prev) { pos = i + 1; prev = r.score; }
        const isMe = me && r.name.toLowerCase() === me.toLowerCase();
        return `<div class="mb-row${isMe ? " me" : ""}"><span><span class="pos">${pos}</span>${esc(r.name)}</span><b>${r.score}</b></div>`;
      }).join("");
      return `<div class="mb-col"><h4>${title}</h4>${items}</div>`;
    };
    return col("Off the stick", pair?.gross ?? []) + col("Handicap (net)", pair?.net ?? []) + (foot ? `<div class="mb-foot">${foot}</div>` : "");
  }
  private renderIntroBoard() {
    const el = $("icBoard"), c = this.course.id, key = String(this.holeI + 1);
    const pb = this.online.localPB(c, key);
    if (!this.online.enabled) {
      el.classList.toggle("hidden", !pb);
      el.innerHTML = pb ? `<div class="mb-foot">Your best here: <b>${pb}</b></div>` : "";
      return;
    }
    const b = this.online.board(c);
    if (!b) { this.online.loadBoard(c); }
    const me = this.online.player?.name;
    const foot = pb ? `Your best here: <b>${pb}</b>` : me ? "" : "Sign in on the title screen to post scores";
    el.innerHTML = this.boardHtml(b?.holes[key], me, 3, foot);
    el.classList.remove("hidden");
  }
  private renderResultBoard() {
    const el = $("rcBoard"), b = this.online.board(this.course.id), me = this.online.player;
    const pair = b?.holes[String(this.holeI + 1)];
    if (!me || !pair) { el.classList.add("hidden"); return; }
    const g = rankOf(pair.gross, this.strokes), n = rankOf(pair.net, this.netFor(this.holeI, this.strokes));
    const ord = (k: number) => k + (["th", "st", "nd", "rd"][(k % 100 >= 11 && k % 100 <= 13) ? 0 : Math.min(k % 10, 4) % 4] || "th");
    el.innerHTML = `<div class="mb-foot">This hole: <b>${ord(g)}</b> off the stick · <b>${ord(n)}</b> on handicap</div>`;
    el.classList.remove("hidden");
  }
  /** Running scorecard on the result card. */
  private renderStrip() {
    const hs = this.course.holes, upto = this.holeI;
    const from = hs.length > 9 && upto >= 9 ? 9 : 0, to = hs.length > 9 && upto < 9 ? 8 : hs.length - 1;
    let cells = "", tot = 0, par = 0;
    for (let i = from; i <= to; i++) {
      const sc = this.scores[i];
      cells += `<div class="cell${i === upto ? " cur" : ""}"><small>${i + 1}</small><b>${sc ? `<span class="sc ${scoreClass(sc, hs[i].par)}">${sc}</span>` : `<span class="dim">·</span>`}</b></div>`;
    }
    this.scores.forEach((sc, i) => { if (sc) { tot += sc; par += hs[i].par; } });
    cells += `<div class="cell tot"><small>TOTAL</small><b>${tot} <span class="dim">(${relPar(tot - par)})</span></b></div>`;
    $("rcStrip").innerHTML = cells;
  }

  // ================================================================ leaderboards screen
  private bdCourse = "";
  private bdKey = "1";
  private openBoards() {
    this.bdCourse = this.course.id;
    this.bdKey = this.phase === "title" ? (this.course.holes.length >= 18 ? "18" : String(this.course.holes.length)) : String(this.holeI + 1);
    $("boards").classList.remove("hidden");
    this.renderBoards();
    this.online.loadBoard(this.bdCourse, true);
    this.sfx.click();
  }
  private renderBoards() {
    const course = this.courses.find((c) => c.id === this.bdCourse) ?? this.course;
    const chip = (label: string, on: boolean, fn: () => void) => {
      const b = document.createElement("button"); b.className = "chip" + (on ? " on" : ""); b.textContent = label;
      b.onclick = (e) => { e.stopPropagation(); fn(); this.sfx.click(); }; return b;
    };
    const cw = $("bdCourse");
    cw.innerHTML = `<select id="bdSelect" class="bd-select" aria-label="Course">${this.courses.map((c) =>
      `<option value="${esc(c.id)}"${c.id === course.id ? " selected" : ""}>${esc(c.name)} · ${c.holes.length} holes</option>`).join("")}</select>`;
    ($("bdSelect") as HTMLSelectElement).onchange = (e) => {
      const c = this.courses.find((x) => x.id === (e.target as HTMLSelectElement).value);
      if (!c) return;
      this.bdCourse = c.id; this.bdKey = c.holes.length >= 18 ? "18" : String(c.holes.length);
      this.sfx.click(); this.renderBoards(); this.online.loadBoard(c.id);
    };
    const pw = $("bdPick"); pw.innerHTML = "";
    const N = course.holes.length;
    const segs = N >= 18 ? [["18", "18 holes"], ["9f", "Front 9"], ["9b", "Back 9"]] : [[String(N), `${N} holes`]];
    for (const [k, label] of segs) pw.appendChild(chip(label, this.bdKey === k && !/^h/.test(k), () => { this.bdKey = k; this.renderBoards(); }));
    for (let i = 1; i <= N; i++) pw.appendChild(chip(`H${i}`, this.bdKey === "h" + i, () => { this.bdKey = "h" + i; this.renderBoards(); }));
    const body = $("bdBody");
    if (!this.online.enabled) { body.innerHTML = `<div class="bd-msg">Leaderboards aren't switched on for this copy of the game yet.</div>`; return; }
    const b = this.online.board(course.id);
    if (!b) { body.innerHTML = `<div class="bd-msg">Loading…</div>`; return; }
    const isHole = /^h\d+$/.test(this.bdKey);
    const pair = isHole ? b.holes[this.bdKey.slice(1)] : b.rounds[this.bdKey];
    const pb = this.online.localPB(course.id, isHole ? this.bdKey.slice(1) : this.bdKey);
    body.innerHTML = `<div class="mini-board">${this.boardHtml(pair, this.online.player?.name, 10, pb ? `Your best: <b>${pb}</b>` : "")}</div>`;
  }

  // ================================================================ player sign-in
  private openPlayer() {
    const p = this.online.player, body = $("pmBody");
    $("pmTitle").textContent = p ? p.name : "Join the leaderboards";
    if (p) {
      body.innerHTML = `<p class="gfx-msg">Handicap <b>${fmtHcap(p.hcap)}</b>. Your scores post to the leaderboards after every hole${this.online.pending() ? ` (<b>${this.online.pending()}</b> waiting to upload)` : ""}.</p>
        <p class="pm-note">Your handicap is worked out automatically from your best 3 of your last 10 completed rounds.</p>
        <div class="modal-actions"><button id="pmOut" class="btn-secondary">Sign out</button><button id="pmDone" class="btn-primary">Done</button></div>`;
      $("pmOut").onclick = () => { this.online.signOut(); $("playerModal").classList.add("hidden"); };
      $("pmDone").onclick = () => $("playerModal").classList.add("hidden");
    } else {
      this.renderPlayerForm(false);
    }
    $("playerModal").classList.remove("hidden");
    this.sfx.click();
  }
  private renderPlayerForm(isNew: boolean) {
    const body = $("pmBody");
    body.innerHTML = `<div class="chips pm-tabs"><button id="pmTabIn" class="chip${isNew ? "" : " on"}">Sign in</button><button id="pmTabNew" class="chip${isNew ? " on" : ""}">New player</button></div>
      <label class="field"><span>Name</span><input id="pmName" maxlength="24" autocomplete="nickname"></label>
      <label class="field"><span>4-digit PIN</span><input id="pmPin" inputmode="numeric" pattern="[0-9]*" maxlength="4" type="password"></label>
      <div id="pmErr" class="pm-err"></div>
      <div class="modal-actions"><button id="pmCancel" class="btn-secondary">Play as guest</button><button id="pmGo" class="btn-primary">${isNew ? "Create player" : "Sign in"}</button></div>
      <p class="pm-note">Your PIN stops anyone else posting scores under your name.${isNew ? " Everyone starts on an 18 handicap; it updates automatically from your best rounds." : ""}</p>`;
    $("pmTabIn").onclick = () => this.renderPlayerForm(false);
    $("pmTabNew").onclick = () => this.renderPlayerForm(true);
    $("pmCancel").onclick = () => $("playerModal").classList.add("hidden");
    $("pmGo").onclick = async () => {
      const name = ($("pmName") as HTMLInputElement).value.trim(), pin = ($("pmPin") as HTMLInputElement).value.trim();
      const err = $("pmErr");
      if (name.length < 2) { err.textContent = "Enter your name."; return; }
      if (!/^\d{4}$/.test(pin)) { err.textContent = "PIN must be 4 digits."; return; }
      err.textContent = "…";
      const e = isNew ? await this.online.register(name, pin) : await this.online.login(name, pin);
      if (e) { err.textContent = e; return; }
      $("playerModal").classList.add("hidden");
      this.toast(`Welcome, <b>${esc(this.online.player!.name)}</b>`, 1.8);
    };
  }

  // ================================================================ scorecard / menus
  private showScorecard(final: boolean) {
    const holes = this.course.holes;
    let rows = "", pt = 0, st = 0, played = 0;
    holes.forEach((h, i) => {
      const s = this.scores[i];
      pt += h.par;
      if (s) { st += s; played += h.par; }
      rows += `<tr class="${i === this.holeI && !final ? "cur" : ""}"><td class="n">${i + 1}</td><td class="nm">${esc(h.name)}</td><td>${h.par}</td>
        <td>${s ? `<span class="sc ${scoreClass(s, h.par)}">${s}</span>` : `<span class="dim">–</span>`}</td></tr>`;
    });
    $("scTable").innerHTML = `<thead><tr><th>#</th><th class="nm">Hole</th><th>Par</th><th>Score</th></tr></thead><tbody>${rows}</tbody>
      <tfoot><tr><td></td><td class="nm">Total</td><td>${pt}</td><td>${st || "–"}</td></tr></tfoot>`;
    $("scTitle").textContent = final ? "Round complete" : "Scorecard";
    $("scSummary").innerHTML = st ? `${esc(this.course.name)} · <b>${st}</b> strokes · <b>${relPar(st - played)}</b>` : "No holes completed yet";
    $("scAgain").classList.toggle("hidden", !final);
    $("scClose").textContent = final ? "Courses" : "Close";
    $("scorecard").classList.remove("hidden");
    if (final) this.phase = "card";
  }
  /** High → Low → Safe → High. Safe changes renderer settings, so it reloads the page. */
  private toggleQuality() {
    const cur = this.world.safe ? "safe" : this.high ? "high" : "low";
    const next = cur === "high" ? "low" : cur === "low" ? "safe" : "high";
    store.set("pg3d.quality", next);
    if (cur === "safe" || next === "safe") { location.reload(); return; }
    this.high = next === "high";
    this.world.setQuality(this.high);
    this.world.loadHole(this.hole);
    this.syncQualityLabels();
  }
  private syncQualityLabels() {
    const q = `Graphics: ${this.world.safe ? "Safe" : this.high ? "High" : "Low"}`;
    $("mQuality").textContent = q; $("tQuality").textContent = q;
    $("mSound").textContent = `Sound: ${this.sfx.enabled ? "On" : "Off"}`;
  }
  private toggleMap() {
    if (this.phase !== "aim") return;
    this.overhead = !this.overhead;
    $("btnMap").classList.toggle("on", this.overhead);
    if (this.overhead) this.toast("Tap the map to aim", 1.8);
  }

  // ================================================================ UI wiring
  private buildClubs() {
    const wrap = $("clubs");
    wrap.innerHTML = "";
    for (const c of this.bag) {
      const b = document.createElement("button");
      b.className = "club"; b.dataset.id = c.id;
      b.innerHTML = `<b>${c.short}</b><small>${c.id === "putter" ? "putt" : c.max + "y"}</small><i class="lie-dot"></i>`;
      b.onclick = () => {
        if (this.phase !== "aim") return;
        this.club = c; this.aimReset(); this.sfx.click(); this.updateHUD();
      };
      wrap.appendChild(b);
    }
  }
  /** colour each club's dot by how well it plays from the current lie */
  private syncLieDots() {
    const lie = this.lie();
    document.querySelectorAll<HTMLElement>("#clubs .club").forEach((b) => {
      const c = clubById(b.dataset.id || "");
      const dot = b.querySelector(".lie-dot") as HTMLElement | null;
      if (dot) dot.className = "lie-dot r" + lieRating(c, lie);
    });
  }

  // ================================================================ bag
  private openBag() {
    const pref = store.get("pg3d.play");
    this.play = pref === "9f" || pref === "9b" ? pref : "18";
    this.bagDraft = this.bag.map((c) => c.id).filter((id) => id !== "putter");
    this.renderBag();
    $("bagPick").classList.remove("hidden");
    this.sfx.click();
  }
  private renderBag() {
    const need = BAG_SIZE - 1;
    const segWrap = $("bagSeg"), long = this.course.holes.length >= 18;
    segWrap.classList.toggle("hidden", !long);
    if (long) {
      segWrap.innerHTML = "";
      for (const [k, label] of [["18", "Full 18"], ["9f", "Front 9"], ["9b", "Back 9"]] as const) {
        const b = document.createElement("button");
        b.className = "chip" + (this.play === k ? " on" : ""); b.textContent = label;
        b.onclick = () => { this.play = k; store.set("pg3d.play", k); this.sfx.click(); this.renderBag(); };
        segWrap.appendChild(b);
      }
    }
    $("bagNeed").textContent = String(need);
    const wrap = $("bagList");
    wrap.innerHTML = "";
    const L = ["Tee", "Fwy", "Rgh", "Sand"], K = ["tee", "fairway", "rough", "bunker"] as const;
    for (const c of CLUBS) {
      const on = c.id === "putter" || this.bagDraft.includes(c.id);
      const b = document.createElement("button");
      b.className = "bag-club" + (on ? " on" : "") + (c.id === "putter" ? " locked" : "");
      b.innerHTML = `<div class="bc-badge">${c.short}</div>
        <div><div class="bc-name">${c.name}<small>${c.id === "putter" ? "always in" : c.max + " yds"}</small></div><div class="bc-blurb">${c.blurb}</div></div>
        <div class="bc-lies">${K.map((k, i) => `<div>${L[i]}<i class="r${c.lies[k]}"></i></div>`).join("")}</div>`;
      b.onclick = () => {
        if (c.id === "putter") return;
        const i = this.bagDraft.indexOf(c.id);
        if (i >= 0) this.bagDraft.splice(i, 1);
        else { this.bagDraft.push(c.id); if (this.bagDraft.length > need) this.bagDraft.shift(); }
        this.sfx.click();
        this.renderBag();
      };
      wrap.appendChild(b);
    }
    ($("bagGo") as HTMLButtonElement).disabled = this.bagDraft.length !== need;
    $("bagGo").textContent = this.bagDraft.length === need ? "Tee off" : `Pick ${need - this.bagDraft.length} more`;
  }
  private confirmBag() {
    if (this.bagDraft.length !== BAG_SIZE - 1) return;
    const ids = CLUBS.map((c) => c.id).filter((id) => this.bagDraft.includes(id)).concat("putter");
    this.bag = ids.map(clubById);
    store.set("pg3d.bag", ids.join(","));
    this.buildClubs();
    $("bagPick").classList.add("hidden");
    this.startRound();
  }
  private bagCode() { return this.bag.filter((c) => c.id !== "putter").map((c) => c.short).join("-"); }

  private bindUI() {
    const on = (id: string, fn: () => void) => { $(id).onclick = (e) => { e.stopPropagation(); fn(); }; };
    on("btnSwing", () => this.primary());
    on("btnMap", () => this.toggleMap());
    on("miniWrap", () => this.toggleMap());
    on("btnMenu", () => { this.syncQualityLabels(); $("menu").classList.remove("hidden"); });
    on("introCard", () => this.endIntro());
    on("rcNext", () => this.nextHole());
    on("scClose", () => { $("scorecard").classList.add("hidden"); if (this.phase === "card") this.showTitle(); });
    on("scAgain", () => this.startRound());
    on("mResume", () => $("menu").classList.add("hidden"));
    on("mCard", () => { $("menu").classList.add("hidden"); this.showScorecard(false); });
    on("mRestart", () => { $("menu").classList.add("hidden"); this.loadHole(this.holeI); });
    on("mQuality", () => this.toggleQuality());
    on("mSound", () => { this.sfx.enabled = !this.sfx.enabled; store.set("pg3d.sound", this.sfx.enabled ? "on" : "off"); this.syncQualityLabels(); });
    on("mLook", () => { $("menu").classList.add("hidden"); this.openLooker(); });
    on("tLook", () => this.openLooker());
    on("lookDone", () => { $("looker").classList.add("hidden"); saveLook(this.look); });
    on("lookRandom", () => { this.look = randomLook(); this.applyLook(); this.renderLooker(); });
    on("mHelp", () => { $("menu").classList.add("hidden"); $("help").classList.remove("hidden"); });
    on("mQuit", () => this.showTitle());
    on("helpClose", () => $("help").classList.add("hidden"));
    on("btnPlay", () => this.openBag());
    on("bagGo", () => this.confirmBag());
    on("bagCancel", () => $("bagPick").classList.add("hidden"));
    on("tPlayer", () => this.openPlayer());
    on("tBoards", () => this.openBoards());
    on("mBoards", () => { $("menu").classList.add("hidden"); this.openBoards(); });
    on("bdClose", () => $("boards").classList.add("hidden"));
    on("tHelp", () => $("help").classList.remove("hidden"));
    on("tQuality", () => this.toggleQuality());
    const ci = $("courseInput") as HTMLInputElement;
    on("tLoad", () => ci.click());
    ci.onchange = async () => {
      const f = ci.files?.[0];
      ci.value = "";
      if (!f) return;
      try {
        const c = parseCourse(await f.text());
        this.courses = this.courses.filter((x) => x.id !== c.id);
        this.courses.push(c);
        this.course = c;
        this.applyCourseVisual();
        this.renderCourseList();
        $("titleMsg").textContent = `Loaded “${c.name}” — ${c.holes.length} holes`;
      } catch (err) {
        $("titleMsg").textContent = `Couldn't load course: ${(err as Error).message}`;
      }
    };
    for (const id of ["menu", "help", "scorecard", "looker", "bagPick", "playerModal", "boards"]) {
      $(id).addEventListener("click", (e) => { if (e.target === $(id) && id !== "scorecard") $(id).classList.add("hidden"); });
    }
  }

  attachInput(dom: HTMLElement) {
    dom.addEventListener("pointerdown", (e) => this.onDown(e));
    window.addEventListener("pointermove", (e) => this.onMove(e));
    const up = () => { this.aimDrag = null; this.spinDrag = null; };
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    dom.addEventListener("contextmenu", (e) => e.preventDefault());
    window.addEventListener("keydown", (e) => {
      if (e.code === "Space") { e.preventDefault(); this.primary(); }
      else if (this.phase === "aim" && e.code === "ArrowLeft") this.heading += 0.03;
      else if (this.phase === "aim" && e.code === "ArrowRight") this.heading -= 0.03;
      else if (e.code === "KeyM") this.toggleMap();
    });
    window.addEventListener("resize", () => this.world.resize());
  }
  private onDown(e: PointerEvent) {
    this.sfx.unlock();
    switch (this.phase) {
      case "intro": this.endIntro(); break;
      case "aim":
        if (this.overhead) this.raycastAim(e);
        else this.aimDrag = { x: e.clientX, th0: this.heading };
        break;
      case "power": this.lockPower(); break;
      case "impact": this.lockImpact(); break;
      case "flight":
        if (this.flight && this.flight.seg === "carry") this.spinDrag = { x: e.clientX, y: e.clientY, h0: this.flight.spin.h, v0: this.flight.spin.v };
        break;
      default: break;
    }
  }
  private onMove(e: PointerEvent) {
    if (this.aimDrag && this.phase === "aim") {
      const dx = e.clientX - this.aimDrag.x;
      this.heading = this.aimDrag.th0 - dx * 0.0048;
      if (!this.hintShown && Math.abs(dx) > 24) { this.hintShown = true; store.set("pg3d.hint", "1"); $("hint").classList.add("hidden"); }
    } else if (this.spinDrag && this.phase === "flight" && this.flight && this.flight.seg === "carry") {
      this.flight.spin.h = clamp(this.spinDrag.h0 - (e.clientX - this.spinDrag.x) * 0.009, -1, 1);
      this.flight.spin.v = clamp(this.spinDrag.v0 + (e.clientY - this.spinDrag.y) * 0.009, -1, 1); // down = backspin
    }
  }
  private raycastAim(e: PointerEvent) {
    const ndc = new THREE.Vector2((e.clientX / innerWidth) * 2 - 1, -(e.clientY / innerHeight) * 2 + 1);
    this.ray.setFromCamera(ndc, this.world.camera);
    const pt = new THREE.Vector3();
    if (this.ray.ray.intersectPlane(this.plane, pt)) this.heading = Math.atan2(pt.x - this.ball.x, pt.z - this.ball.z);
  }

  // ================================================================ per frame
  update(dt: number) {
    this.time += dt;
    const m = this.meter;
    switch (this.phase) {
      case "title": this.titleCam(); break;
      case "intro":
        this.introT += dt / 3.4;
        this.introCam();
        if (this.introT >= 1) this.endIntro();
        break;
      case "power":
        m.power += m.pdir * dt * 1.15 * this.curDiff.ms * this.curDiff.pspeed;
        if (m.power >= 1) { m.power = 1; m.pdir = -1; }
        if (m.power <= 0) { m.power = 0; m.pdir = 1; }
        this.golferAng = lerp(12, -150 * this.club.swing, m.power);
        break;
      case "impact":
        m.impact += m.idir * dt * 1.35 * this.curDiff.ms;
        if (m.impact >= 1) { m.impact = 1; m.idir = -1; }
        if (m.impact <= 0) { m.impact = 0; m.idir = 1; }
        break;
      case "swinging": {
        this.golferT += dt / 0.5;
        const c = this.pending!.club, top = -150 * c.swing, fo = 150 * c.swing;
        this.golferAng = this.golferT < 0.33 ? lerp(top, 12, this.golferT / 0.33) : lerp(12, fo, clamp((this.golferT - 0.33) / 0.67, 0, 1));
        if (!this.launched && this.golferT >= 0.33) { this.launched = true; this.launch(); }
        break;
      }
      case "flight": {
        const f = this.flight!;
        // slow-motion feel while the ball is in the air, easing back to real time on the ground
        const ts = f.seg === "carry" ? (this.heroShot ? 0.55 : 0.72) : f.seg === "roll" ? 0.85 : 1;
        f.update(dt * ts);
        for (const ev of f.events.splice(0)) {
          if (ev.surface === "water" || ev.surface === "hazard") continue;
          this.sfx.bounce(ev.surface, ev.strength, ev.type === "land");
          if (ev.type === "land") navigator.vibrate?.(Math.round(6 + ev.strength * 10));
        }
        if (f.seg === "splash" && !this.splashed) {
          this.splashed = true;
          if (f.hazard === "grass") this.sfx.rustle(); else { this.world.splash(f.pos.x, f.pos.z); this.sfx.splash(); }
          setTimeout(() => this.sfx.groan(0.6), 350);
        }
        if (f.finished) this.finalize();
        break;
      }
      default: break;
    }
    if (this.phase !== "title" && this.phase !== "intro") this.updateCamera(dt);
    this.updateVisuals();
    this.updateMeters();
    this.updateLive();
    if (this.toastT > 0) { this.toastT -= dt; if (this.toastT <= 0) $("toast").classList.remove("show"); }
    this.world.update(dt, this.time);
  }

  private aimCam() {
    const o = this.ball, th = (this.phase === "swinging" && this.pending) ? this.pending.th : this.heading;
    const hx = Math.sin(th), hz = Math.cos(th), base = this.world.groundAt(o.x, o.z);
    // screen-right of the aim line is (-hz, hx); nudge the camera that way so the golfer doesn't block the ball
    const rx = -hz, rz = hx;
    if (this.club.id === "putter") {
      const ahead = clamp(this.distPin() * 0.5, 3, 12), lx = o.x + hx * ahead, lz = o.z + hz * ahead;
      return {
        p: new THREE.Vector3(o.x - hx * 7 + rx * 0.8, base + 6.2, o.z - hz * 7 + rz * 0.8),
        l: new THREE.Vector3(lx, this.world.groundAt(lx, lz), lz),
      };
    }
    const lx = o.x + hx * 30, lz = o.z + hz * 30;
    return {
      p: new THREE.Vector3(o.x - hx * 13 + rx * 1.2, base + 5, o.z - hz * 13 + rz * 1.2),
      l: new THREE.Vector3(lx, this.world.groundAt(lx, lz) + 0.5, lz),
    };
  }
  private titleCam() {
    const g = this.hole.green, a = this.time * 0.07, R = g.r * 2.6 + 30, y = groundH(this.hole, g.x, g.z);
    this.cam.p.set(g.x + Math.cos(a) * R, y + 17, g.z + Math.sin(a) * R);
    this.cam.l.set(g.x, y, g.z);
    this.world.setCamera(this.cam.p.x, this.cam.p.y, this.cam.p.z, this.cam.l.x, this.cam.l.y, this.cam.l.z);
  }
  private introCam() {
    const pd = pathData(this.hole), e = smoothstep(0, 1, this.introT);
    const s = pd.total * (1 - e), p = pathAt(this.hole, s);
    const back = 10 + 22 * (1 - e), hgt = 6.4 + 34 * (1 - e);
    const g = this.hole.green;
    const aim = this.aimCam();
    const cp = new THREE.Vector3(p.x - p.tx * back, this.world.groundAt(p.x, p.z) + hgt, p.z - p.tz * back);
    const gl = new THREE.Vector3(g.x, groundH(this.hole, g.x, g.z), g.z);
    const blend = smoothstep(0.8, 1, this.introT);
    this.cam.p.copy(cp.lerp(aim.p, blend));
    this.cam.l.copy(gl.lerp(aim.l, e));
    this.world.setCamera(this.cam.p.x, this.cam.p.y, this.cam.p.z, this.cam.l.x, this.cam.l.y, this.cam.l.z);
  }
  private updateCamera(dt: number) {
    if (this.overhead && this.phase === "aim") {
      const reach = Math.min(this.distPin(), this.club.max);
      const span = clamp(reach * 1.4 + 50, 90, 520);
      const hx = Math.sin(this.heading), hz = Math.cos(this.heading);
      this.world.setTopCamera(this.ball.x + hx * reach * 0.45, this.ball.z + hz * reach * 0.45, span);
      return;
    }
    let D: { p: THREE.Vector3; l: THREE.Vector3 };
    if (this.phase === "flight" && this.flight && this.pending) {
      const b = this.flight.pos, h = this.flight.h, th = this.pending.th, hx = Math.sin(th), hz = Math.cos(th);
      const base = this.world.groundAt(b.x, b.z);
      const putt = this.pending.club.id === "putter";
      D = putt
        ? { p: new THREE.Vector3(b.x - hx * 7, base + 4.2, b.z - hz * 7), l: new THREE.Vector3(b.x + hx * 6, base, b.z + hz * 6) }
        : { p: new THREE.Vector3(b.x - hx * 12, base + 5 + h * 0.45, b.z - hz * 12), l: new THREE.Vector3(b.x + hx * 12, base + 1 + h * 0.6, b.z + hz * 12) };
    } else if (this.phase === "done") {
      const g = this.hole.green, y = groundH(this.hole, g.x, g.z), a = this.time * 0.15;
      D = { p: new THREE.Vector3(g.x + Math.cos(a) * 24, y + 12, g.z + Math.sin(a) * 24), l: new THREE.Vector3(g.x, y, g.z) };
    } else {
      D = this.aimCam();
    }
    const k = this.camSnap ? 1 : Math.min(1, dt * (this.phase === "flight" ? 3.2 : this.phase === "done" ? 1.5 : 8));
    this.camSnap = false;
    this.cam.p.lerp(D.p, k);
    this.cam.l.lerp(D.l, k);
    this.world.setCamera(this.cam.p.x, this.cam.p.y, this.cam.p.z, this.cam.l.x, this.cam.l.y, this.cam.l.z);
  }

  private updateVisuals() {
    const bp = this.flight ? this.flight.pos : this.ball;
    const air = this.flight ? this.flight.h : this.phase === "done" ? -0.6 : 0;
    this.world.setBall(bp.x, bp.z, air);
    const th = (this.phase === "swinging" || this.phase === "flight") && this.pending ? this.pending.th : this.heading;
    this.world.setGolfer(this.ball.x, this.ball.z, th, this.golferAng, this.phase !== "flight" && this.phase !== "done");
    const aiming = this.phase === "aim" || this.phase === "power" || this.phase === "impact";
    const putter = this.club.id === "putter";
    this.world.setAim(this.ball, this.heading, Math.min(this.distPin(), this.club.max), aiming && !putter);
    this.world.setPuttMode(putter && (aiming || this.phase === "swinging"));
    if (aiming && putter) {
      const key = `${this.ball.x.toFixed(2)}|${this.ball.z.toFixed(2)}|${this.heading.toFixed(3)}`;
      if (key !== this.puttKey) {
        this.puttKey = key;
        let path = previewPutt(this.hole, this.ball, this.heading, this.distPin());
        // fast greens: only show the first part of the roll, so you have to read the break yourself
        const gs = this.hole.greenSpeed ?? 1;
        if (gs >= 1.3) path = path.slice(0, Math.max(2, Math.round(path.length * 0.55)));
        this.world.setPuttPreview(path);
      }
    } else if (this.puttKey !== "") {
      this.puttKey = "";
      this.world.setPuttPreview(null);
    }
  }

  private updateMeters() {
    const showP = this.phase === "power" || this.phase === "impact" || this.phase === "swinging";
    $("powerWrap").classList.toggle("hidden", !showP);
    $("impactWrap").classList.toggle("hidden", this.phase !== "impact");
    if (showP) {
      const pw = this.phase === "power" ? this.meter.power : this.meter.lp;
      $("powerFill").style.height = (pw * 100).toFixed(1) + "%";
      const need = clamp(this.distPin() / (this.club.max * this.curDiff.pm), 0, 1);
      $("powerTick").style.bottom = (need * 100).toFixed(1) + "%";
    }
    if (this.phase === "impact") $("impactMarker").style.left = (this.meter.impact * 100).toFixed(1) + "%";
    const spinOn = this.phase === "flight" && !!this.flight && this.flight.seg === "carry";
    $("spin").classList.toggle("hidden", !spinOn);
    if (spinOn && this.flight) {
      const d = $("spinDot");
      d.style.transform = `translate(calc(-50% + ${(-this.flight.spin.h * 36).toFixed(1)}px), calc(-50% + ${(this.flight.spin.v * 36).toFixed(1)}px))`;
    }
  }

  private updateLive() {
    if (this.phase === "title") return;
    const th = this.heading, hx = Math.sin(th), hz = Math.cos(th);
    const up = this.wind.x * hx + this.wind.z * hz, right = this.wind.x * -hz + this.wind.z * hx;
    $("windArrow").style.transform = `rotate(${Math.atan2(right, up).toFixed(3)}rad)`;
    const pos = this.flight ? this.flight.pos : this.ball;
    const d = Math.hypot(pos.x - this.pin().x, pos.z - this.pin().z);
    const onG = this.lie() === "green" || this.lie() === "fringe";
    $("toPinVal").textContent = this.phase === "done" ? "0" : onG && !this.flight ? `${Math.round(d * 3)}` : `${Math.round(d)}`;
    $("toPinUnit").textContent = onG && !this.flight ? "ft to pin" : "yds to pin";
    const aiming = this.phase === "aim" || this.phase === "power" || this.phase === "impact";
    this.mini.draw(pos, this.heading, Math.min(this.distPin(), this.club.max), aiming);
  }

  private updateHUD() {
    const h = this.hole;
    $("tbHole").textContent = `${this.holeI + 1}`;
    $("tbPar").textContent = `Par ${h.par}`;
    $("tbYds").textContent = `${this.yards(h)} yds`;
    $("tbShot").textContent = this.phase === "done" ? "Holed" : `Shot ${this.strokes + 1}`;
    $("tbLie").textContent = this.phase === "done" ? "In the cup" : LIE[this.lie()];
    $("tbScore").textContent = relPar(this.roundRel());
    $("windMph").textContent = `${Math.round(this.wind.mph)} mph`;
    const aim = this.phase === "aim";
    document.querySelectorAll<HTMLElement>(".club").forEach((b) => {
      b.classList.toggle("active", b.dataset.id === this.club.id);
      b.classList.toggle("locked", !aim);
    });
    $("btnMap").classList.toggle("on", this.overhead);
    this.syncLieDots();
    const last = this.holeI === this.lastHole;
    const map: Partial<Record<Phase, [string, string, string]>> = {
      intro: ["SKIP", "flyover", "aim"],
      aim: ["SWING", "tap to start", "aim"],
      power: ["POWER", "tap to set", "power"],
      impact: ["STRIKE", "green zone", "impact"],
      swinging: ["···", "", "busy"],
      flight: ["···", this.club.id === "putter" ? "" : "drag: spin", "busy"],
      done: ["NEXT", last ? "scorecard" : `hole ${this.holeI + 2}`, "next"],
    };
    const [lbl, sub, st] = map[this.phase] ?? ["", "", "busy"];
    const btn = $("btnSwing") as HTMLButtonElement;
    $("swingLbl").textContent = lbl;
    $("swingSub").textContent = sub;
    btn.dataset.state = st;
    btn.disabled = st === "busy";
  }
}
