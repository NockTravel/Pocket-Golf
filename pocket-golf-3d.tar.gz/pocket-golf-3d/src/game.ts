import * as THREE from "three";
import { World } from "./world";
import { Hole, Surface, surfaceAt, pathData, pathAt, nearestOnPath, groundH, smoothstep } from "./holes";
import { Course, COURSES, parseCourse } from "./course";
import { Look, loadLook, saveLook, randomLook, lookSVG, HATS, HAIRS, HAT_COLORS, HAIR_COLORS, SHIRT_COLORS, PANTS_COLORS, SKIN_TONES } from "./look";
import { CLUBS, Club, chooseClub, difficulty, Difficulty, Flight, previewPutt } from "./physics";
import { Sfx } from "./sfx";
import { Minimap } from "./minimap";

type Phase = "title" | "intro" | "aim" | "power" | "impact" | "swinging" | "flight" | "done" | "card";

const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const $ = (id: string) => document.getElementById(id) as HTMLElement;
const store = {
  get(k: string) { try { return localStorage.getItem(k); } catch { return null; } },
  set(k: string, v: string) { try { localStorage.setItem(k, v); } catch { /* storage unavailable */ } },
};
const esc = (s: string) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]!);
const LIE: Record<Surface, string> = { tee: "Tee", green: "Green", fringe: "Fringe", fairway: "Fairway", rough: "Rough", bunker: "Bunker", water: "Water" };
const relPar = (n: number) => (n === 0 ? "E" : n > 0 ? `+${n}` : `${n}`);
function scoreName(s: number, par: number) {
  if (s === 1) return "Hole in one!";
  const d = s - par;
  return d <= -3 ? "Albatross!" : d === -2 ? "Eagle!" : d === -1 ? "Birdie!" : d === 0 ? "Par" : d === 1 ? "Bogey" : d === 2 ? "Double bogey" : `+${d}`;
}
function scoreClass(s: number, par: number) {
  const d = s - par;
  return s === 1 || d <= -2 ? "eagle" : d === -1 ? "birdie" : d === 0 ? "par" : d === 1 ? "bogey" : "dbl";
}

export class Game {
  private sfx = new Sfx();
  private mini: Minimap;
  private courses: Course[] = [...COURSES];
  private course: Course;
  private hole!: Hole;
  private holeI = 0;
  private scores: number[] = [];

  private ball = { x: 0, z: 0 };
  private strokes = 0;
  private club: Club = CLUBS[0];
  private heading = 0;
  private wind = { x: 0, z: 0, mph: 0 };
  private phase: Phase = "title";

  private flight: Flight | null = null;
  private heroShot = false;
  private look: Look = loadLook();
  private splashed = false;
  private pending: { power: number; off: number; club: Club; th: number; diff: Difficulty } | null = null;
  private curDiff: Difficulty = { pm: 1, disp: 0, ms: 1 };
  private meter = { power: 0, pdir: 1, impact: 0, idir: 1, lp: 0, li: 0.5 };
  private golferAng = 12;
  private golferT = 0;
  private launched = false;

  private overhead = false;
  private aimDrag: { x: number; th0: number } | null = null;
  private spinDrag: { x: number; y: number; h0: number; v0: number } | null = null;
  private cam = { p: new THREE.Vector3(0, 8, -10), l: new THREE.Vector3(0, 0, 40) };
  private camSnap = true;
  private introT = 0;
  private time = 0;
  private ray = new THREE.Raycaster();
  private plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
  private puttKey = "";
  private toastT = 0;
  private hintShown = store.get("pg3d.hint") === "1";

  constructor(private world: World, private high: boolean) {
    this.mini = new Minimap($("minimap") as HTMLCanvasElement);
    this.sfx.enabled = store.get("pg3d.sound") !== "off";
    const last = store.get("pg3d.course");
    this.course = this.courses.find((c) => c.id === last) ?? this.courses[0];
    this.buildClubs();
    this.bindUI();
    this.applyCourseVisual();
    this.applyLook();
    this.showTitle();
  }

  // ================================================================ helpers
  private pin() { return this.hole.pin; }
  private distPin() { return Math.hypot(this.ball.x - this.pin().x, this.ball.z - this.pin().z); }
  private lie(): Surface { return surfaceAt(this.hole, this.ball.x, this.ball.z); }
  private yards(h: Hole) { return Math.round(pathData(h).total); }
  private roundRel() {
    let r = 0;
    this.scores.forEach((s, i) => { if (s) r += s - this.course.holes[i].par; });
    return r;
  }
  private aimReset() {
    const d = this.distPin();
    if (this.club.id === "putter" || d <= this.club.max * 1.02) {
      this.heading = Math.atan2(this.pin().x - this.ball.x, this.pin().z - this.ball.z);
      return;
    }
    const np = nearestOnPath(this.hole, this.ball.x, this.ball.z);
    const tgt = pathAt(this.hole, Math.min(pathData(this.hole).total, np.s + this.club.max * 0.86));
    this.heading = Math.atan2(tgt.x - this.ball.x, tgt.z - this.ball.z);
  }
  private newWind() {
    const a = Math.random() * Math.PI * 2, m = 2 + Math.random() * 13;
    this.wind = { x: Math.sin(a) * m, z: Math.cos(a) * m, mph: m };
    this.world.setWind(this.wind.x, this.wind.z, m);
  }
  private toast(html: string, secs = 2.6) {
    const t = $("toast");
    t.innerHTML = html;
    t.classList.add("show");
    this.toastT = secs;
  }

  // ================================================================ title / course select
  private applyCourseVisual() {
    this.world.setTheme(this.course.theme);
    this.hole = this.course.holes[0];
    this.holeI = 0;
    this.world.loadHole(this.hole);
    this.mini.setHole(this.hole, this.course.theme);
    this.ball = { ...this.hole.tee };
    this.newWind();
  }
  private applyLook() { this.world.setLook(this.look); }
  private openLooker() { this.renderLooker(); $("looker").classList.remove("hidden"); this.sfx.click(); }
  private renderLooker() {
    $("lookPreview").innerHTML = lookSVG(this.look);
    const wrap = $("lookOpts");
    wrap.innerHTML = "";
    const L = this.look as unknown as Record<string, string>;
    const set = (k: string, v: string) => { L[k] = v; this.applyLook(); this.renderLooker(); saveLook(this.look); this.sfx.click(); };
    const row = (label: string, build: (box: HTMLElement) => void) => {
      const r = document.createElement("div"); r.className = "look-row";
      r.innerHTML = `<div class="look-label">${label}</div>`;
      const box = document.createElement("div"); box.className = "chips"; build(box); r.appendChild(box); wrap.appendChild(r);
    };
    const chips = (k: string, opts: [string, string][]) => (box: HTMLElement) => {
      for (const [v, name] of opts) {
        const b = document.createElement("button"); b.className = "chip" + (L[k] === v ? " on" : ""); b.textContent = name;
        b.onclick = () => set(k, v); box.appendChild(b);
      }
    };
    const swatches = (k: string, cols: string[]) => (box: HTMLElement) => {
      for (const c of cols) {
        const b = document.createElement("button"); b.className = "sw" + (L[k].toLowerCase() === c.toLowerCase() ? " on" : "");
        b.style.setProperty("--c", c); b.setAttribute("aria-label", c);
        b.onclick = () => set(k, c); box.appendChild(b);
      }
    };
    row("Hat", chips("hat", HATS));
    if (this.look.hat !== "none") row("Hat colour", swatches("hatColor", HAT_COLORS));
    row("Hair", chips("hair", HAIRS));
    if (this.look.hair !== "bald") row("Hair colour", swatches("hairColor", HAIR_COLORS));
    row("Shirt", swatches("shirt", SHIRT_COLORS));
    row("Trousers", swatches("pants", PANTS_COLORS));
    row("Skin", swatches("skin", SKIN_TONES));
  }
  private showTitle() {
    this.phase = "title";
    this.overhead = false;
    for (const id of ["hud", "introCard", "resultCard", "scorecard", "menu", "help"]) $(id).classList.add("hidden");
    $("title").classList.remove("hidden");
    this.renderCourseList();
    this.syncQualityLabels();
  }
  private renderCourseList() {
    const wrap = $("courseList");
    wrap.innerHTML = "";
    for (const c of this.courses) {
      const par = c.holes.reduce((a, h) => a + h.par, 0);
      const best = store.get("pg3d.best." + c.id);
      const el = document.createElement("button");
      el.className = "course-card" + (c === this.course ? " sel" : "");
      el.style.setProperty("--cc", c.theme.fairway);
      el.style.setProperty("--cw", c.theme.water);
      el.innerHTML = `<div class="cc-swatch"></div><div class="cc-body"><div class="cc-name">${esc(c.name)}</div>
        <div class="cc-tag">${esc(c.tagline || "Custom course")}</div>
        <div class="cc-meta"><span>${c.holes.length} holes</span><span>Par ${par}</span><span>${best ? `Best ${best} (${relPar(+best - par)})` : "No rounds yet"}</span></div></div>`;
      el.onclick = () => {
        if (c === this.course) return;
        this.course = c;
        store.set("pg3d.course", c.id);
        this.applyCourseVisual();
        this.renderCourseList();
        this.sfx.click();
      };
      wrap.appendChild(el);
    }
  }
  private startRound() {
    this.sfx.unlock();
    this.scores = [];
    for (const id of ["title", "scorecard", "menu", "help", "resultCard"]) $(id).classList.add("hidden");
    $("hud").classList.remove("hidden");
    this.loadHole(0);
  }

  // ================================================================ hole flow
  private loadHole(i: number) {
    this.holeI = i;
    this.hole = this.course.holes[i];
    this.world.loadHole(this.hole);
    this.mini.setHole(this.hole, this.course.theme);
    this.ball = { ...this.hole.tee };
    this.strokes = 0;
    this.flight = null;
    this.overhead = false;
    this.newWind();
    this.club = chooseClub(this.distPin(), "tee");
    this.aimReset();
    this.golferAng = 12;
    this.phase = "intro";
    this.introT = 0;
    this.toastT = 0;
    $("toast").classList.remove("show");
    $("resultCard").classList.add("hidden");
    $("icNum").textContent = `${i + 1}`;
    $("icName").textContent = this.hole.name;
    $("icMeta").textContent = `Par ${this.hole.par} · ${this.yards(this.hole)} yds`;
    const ic = $("introCard");
    ic.classList.remove("hidden");
    ic.classList.remove("fade");
    this.updateHUD();
  }
  private endIntro() {
    if (this.phase !== "intro") return;
    this.phase = "aim";
    this.camSnap = false;
    $("introCard").classList.add("fade");
    setTimeout(() => $("introCard").classList.add("hidden"), 350);
    if (!this.hintShown) $("hint").classList.remove("hidden");
    this.updateHUD();
  }
  private nextHole() {
    $("resultCard").classList.add("hidden");
    if (this.holeI < this.course.holes.length - 1) this.loadHole(this.holeI + 1);
    else this.showScorecard(true);
  }

  // ================================================================ swing
  primary() {
    this.sfx.unlock();
    switch (this.phase) {
      case "intro": this.endIntro(); break;
      case "aim": this.startSwing(); break;
      case "power": this.lockPower(); break;
      case "impact": this.lockImpact(); break;
      case "done": this.nextHole(); break;
      default: break;
    }
  }
  private startSwing() {
    this.overhead = false;
    this.curDiff = difficulty(this.club, this.lie());
    this.phase = "power";
    this.meter.power = 0; this.meter.pdir = 1;
    $("hint").classList.add("hidden");
    if (this.curDiff.disp > 0.08) this.toast(`<b class="gold">Tricky lie</b> — less power & control`);
    this.updateHUD();
  }
  private lockPower() {
    this.meter.lp = this.meter.power;
    this.phase = "impact";
    this.meter.impact = 0; this.meter.idir = 1;
    this.updateHUD();
  }
  private lockImpact() {
    this.meter.li = this.meter.impact;
    this.phase = "swinging";
    this.golferT = 0;
    this.launched = false;
    this.pending = { power: this.meter.lp, off: (0.5 - this.meter.li) * 2, club: this.club, th: this.heading, diff: this.curDiff };
    this.updateHUD();
  }
  private launch() {
    const p = this.pending!;
    this.flight = new Flight(this.hole, { ...p, origin: { ...this.ball }, wind: this.wind });
    this.splashed = false;
    this.phase = "flight";
    this.world.trailStart();
    const a = Math.abs(p.off);
    this.heroShot = p.club.id !== "putter" && a <= 0.1 && p.power >= 0.95;
    if (p.club.id === "putter") this.sfx.putt();
    else if (this.heroShot) this.sfx.perfect(p.club.id === "driver");
    else this.sfx.strike(p.power);
    navigator.vibrate?.(p.club.id === "putter" ? 8 : this.heroShot ? [30, 40, 60] : 18);
    if (p.club.id !== "putter") {
      if (this.heroShot) this.toast(`<b class="gold">PERFECT!</b> Flushed it`, 1.8);
      else if (a <= 0.1) this.toast(`<b class="green">Pure strike!</b>`, 1.4);
      else if (a <= 0.28) this.toast(p.off > 0 ? "Draw" : "Fade", 1.2);
      else this.toast(`<b class="warn">${p.off > 0 ? "Hook!" : "Slice!"}</b>`, 1.4);
    }
    this.updateHUD();
  }
  private finalize() {
    const r = this.flight!.result!;
    this.flight = null;
    this.world.trailStop();
    this.ball = { x: r.rest.x, z: r.rest.z };
    this.strokes += r.water ? 2 : 1;
    const d = this.distPin();
    if (r.holed || d < 1.5) { this.holeOut(); return; }
    const lie = this.lie();
    this.club = chooseClub(d, lie);
    this.aimReset();
    this.phase = "aim";
    const where = r.water ? `<b class="warn">Splash!</b> +1 penalty, dropped` :
      lie === "green" ? `On the green · <b>${Math.round(d * 3)} ft</b>` :
      lie === "fringe" ? `On the fringe · <b>${Math.round(d * 3)} ft</b>` :
      `${LIE[lie]} · <b>${Math.round(d)}</b> yds to pin`;
    this.toast(where);
    this.updateHUD();
  }
  private holeOut() {
    this.ball = { ...this.pin() };
    this.scores[this.holeI] = this.strokes;
    this.phase = "done";
    this.toastT = 0;
    $("toast").classList.remove("show");
    this.sfx.cup();
    const diff = this.strokes - this.hole.par;
    if (diff <= 0) setTimeout(() => this.sfx.cheer(), 250);
    navigator.vibrate?.([20, 40, 20]);
    const last = this.holeI === this.course.holes.length - 1;
    $("rcLabel").textContent = scoreName(this.strokes, this.hole.par);
    $("rcLabel").className = "rc-label " + scoreClass(this.strokes, this.hole.par);
    $("rcSub").textContent = `${this.strokes} stroke${this.strokes === 1 ? "" : "s"} · Par ${this.hole.par} · Round ${relPar(this.roundRel())}`;
    $("rcNext").textContent = last ? "See scorecard" : `Hole ${this.holeI + 2} →`;
    $("resultCard").classList.remove("hidden");
    if (last) {
      const tot = this.scores.reduce((a, b) => a + (b || 0), 0);
      const key = "pg3d.best." + this.course.id, prev = Number(store.get(key) || 0);
      if (!prev || tot < prev) store.set(key, String(tot));
    }
    this.updateHUD();
  }

  // ================================================================ scorecard / menus
  private showScorecard(final: boolean) {
    const holes = this.course.holes;
    let rows = "", pt = 0, st = 0, played = 0;
    holes.forEach((h, i) => {
      const s = this.scores[i];
      pt += h.par;
      if (s) { st += s; played += h.par; }
      rows += `<tr class="${i === this.holeI && !final ? "cur" : ""}"><td class="n">${i + 1}</td><td class="nm">${esc(h.name)}</td><td>${h.par}</td>
        <td>${s ? `<span class="sc ${scoreClass(s, h.par)}">${s}</span>` : `<span class="dim">–</span>`}</td></tr>`;
    });
    $("scTable").innerHTML = `<thead><tr><th>#</th><th class="nm">Hole</th><th>Par</th><th>Score</th></tr></thead><tbody>${rows}</tbody>
      <tfoot><tr><td></td><td class="nm">Total</td><td>${pt}</td><td>${st || "–"}</td></tr></tfoot>`;
    $("scTitle").textContent = final ? "Round complete" : "Scorecard";
    $("scSummary").innerHTML = st ? `${esc(this.course.name)} · <b>${st}</b> strokes · <b>${relPar(st - played)}</b>` : "No holes completed yet";
    $("scAgain").classList.toggle("hidden", !final);
    $("scClose").textContent = final ? "Courses" : "Close";
    $("scorecard").classList.remove("hidden");
    if (final) this.phase = "card";
  }
  private toggleQuality() {
    this.high = !this.high;
    store.set("pg3d.quality", this.high ? "high" : "low");
    this.world.setQuality(this.high);
    this.world.loadHole(this.hole);
    this.syncQualityLabels();
  }
  private syncQualityLabels() {
    const q = `Graphics: ${this.high ? "High" : "Low"}`;
    $("mQuality").textContent = q; $("tQuality").textContent = q;
    $("mSound").textContent = `Sound: ${this.sfx.enabled ? "On" : "Off"}`;
  }
  private toggleMap() {
    if (this.phase !== "aim") return;
    this.overhead = !this.overhead;
    $("btnMap").classList.toggle("on", this.overhead);
    if (this.overhead) this.toast("Tap the map to aim", 1.8);
  }

  // ================================================================ UI wiring
  private buildClubs() {
    const wrap = $("clubs");
    wrap.innerHTML = "";
    for (const c of CLUBS) {
      const b = document.createElement("button");
      b.className = "club"; b.dataset.id = c.id;
      b.innerHTML = `<b>${c.short}</b><small>${c.id === "putter" ? "putt" : c.max + "y"}</small>`;
      b.onclick = () => {
        if (this.phase !== "aim") return;
        this.club = c; this.aimReset(); this.sfx.click(); this.updateHUD();
      };
      wrap.appendChild(b);
    }
  }
  private bindUI() {
    const on = (id: string, fn: () => void) => { $(id).onclick = (e) => { e.stopPropagation(); fn(); }; };
    on("btnSwing", () => this.primary());
    on("btnMap", () => this.toggleMap());
    on("miniWrap", () => this.toggleMap());
    on("btnMenu", () => { this.syncQualityLabels(); $("menu").classList.remove("hidden"); });
    on("introCard", () => this.endIntro());
    on("rcNext", () => this.nextHole());
    on("scClose", () => { $("scorecard").classList.add("hidden"); if (this.phase === "card") this.showTitle(); });
    on("scAgain", () => this.startRound());
    on("mResume", () => $("menu").classList.add("hidden"));
    on("mCard", () => { $("menu").classList.add("hidden"); this.showScorecard(false); });
    on("mRestart", () => { $("menu").classList.add("hidden"); this.loadHole(this.holeI); });
    on("mQuality", () => this.toggleQuality());
    on("mSound", () => { this.sfx.enabled = !this.sfx.enabled; store.set("pg3d.sound", this.sfx.enabled ? "on" : "off"); this.syncQualityLabels(); });
    on("mLook", () => { $("menu").classList.add("hidden"); this.openLooker(); });
    on("tLook", () => this.openLooker());
    on("lookDone", () => { $("looker").classList.add("hidden"); saveLook(this.look); });
    on("lookRandom", () => { this.look = randomLook(); this.applyLook(); this.renderLooker(); });
    on("mHelp", () => { $("menu").classList.add("hidden"); $("help").classList.remove("hidden"); });
    on("mQuit", () => this.showTitle());
    on("helpClose", () => $("help").classList.add("hidden"));
    on("btnPlay", () => this.startRound());
    on("tHelp", () => $("help").classList.remove("hidden"));
    on("tQuality", () => this.toggleQuality());
    const ci = $("courseInput") as HTMLInputElement;
    on("tLoad", () => ci.click());
    ci.onchange = async () => {
      const f = ci.files?.[0];
      ci.value = "";
      if (!f) return;
      try {
        const c = parseCourse(await f.text());
        this.courses = this.courses.filter((x) => x.id !== c.id);
        this.courses.push(c);
        this.course = c;
        this.applyCourseVisual();
        this.renderCourseList();
        $("titleMsg").textContent = `Loaded “${c.name}” — ${c.holes.length} holes`;
      } catch (err) {
        $("titleMsg").textContent = `Couldn't load course: ${(err as Error).message}`;
      }
    };
    for (const id of ["menu", "help", "scorecard", "looker"]) {
      $(id).addEventListener("click", (e) => { if (e.target === $(id) && id !== "scorecard") $(id).classList.add("hidden"); });
    }
  }

  attachInput(dom: HTMLElement) {
    dom.addEventListener("pointerdown", (e) => this.onDown(e));
    window.addEventListener("pointermove", (e) => this.onMove(e));
    const up = () => { this.aimDrag = null; this.spinDrag = null; };
    window.addEventListener("pointerup", up);
    window.addEventListener("pointercancel", up);
    dom.addEventListener("contextmenu", (e) => e.preventDefault());
    window.addEventListener("keydown", (e) => {
      if (e.code === "Space") { e.preventDefault(); this.primary(); }
      else if (this.phase === "aim" && e.code === "ArrowLeft") this.heading += 0.03;
      else if (this.phase === "aim" && e.code === "ArrowRight") this.heading -= 0.03;
      else if (e.code === "KeyM") this.toggleMap();
    });
    window.addEventListener("resize", () => this.world.resize());
  }
  private onDown(e: PointerEvent) {
    this.sfx.unlock();
    switch (this.phase) {
      case "intro": this.endIntro(); break;
      case "aim":
        if (this.overhead) this.raycastAim(e);
        else this.aimDrag = { x: e.clientX, th0: this.heading };
        break;
      case "power": this.lockPower(); break;
      case "impact": this.lockImpact(); break;
      case "flight":
        if (this.flight && this.flight.seg === "carry") this.spinDrag = { x: e.clientX, y: e.clientY, h0: this.flight.spin.h, v0: this.flight.spin.v };
        break;
      default: break;
    }
  }
  private onMove(e: PointerEvent) {
    if (this.aimDrag && this.phase === "aim") {
      const dx = e.clientX - this.aimDrag.x;
      this.heading = this.aimDrag.th0 - dx * 0.0048;
      if (!this.hintShown && Math.abs(dx) > 24) { this.hintShown = true; store.set("pg3d.hint", "1"); $("hint").classList.add("hidden"); }
    } else if (this.spinDrag && this.phase === "flight" && this.flight && this.flight.seg === "carry") {
      this.flight.spin.h = clamp(this.spinDrag.h0 - (e.clientX - this.spinDrag.x) * 0.009, -1, 1);
      this.flight.spin.v = clamp(this.spinDrag.v0 - (e.clientY - this.spinDrag.y) * 0.009, -1, 1);
    }
  }
  private raycastAim(e: PointerEvent) {
    const ndc = new THREE.Vector2((e.clientX / innerWidth) * 2 - 1, -(e.clientY / innerHeight) * 2 + 1);
    this.ray.setFromCamera(ndc, this.world.camera);
    const pt = new THREE.Vector3();
    if (this.ray.ray.intersectPlane(this.plane, pt)) this.heading = Math.atan2(pt.x - this.ball.x, pt.z - this.ball.z);
  }

  // ================================================================ per frame
  update(dt: number) {
    this.time += dt;
    const m = this.meter;
    switch (this.phase) {
      case "title": this.titleCam(); break;
      case "intro":
        this.introT += dt / 3.4;
        this.introCam();
        if (this.introT >= 1) this.endIntro();
        break;
      case "power":
        m.power += m.pdir * dt * 1.15 * this.curDiff.ms;
        if (m.power >= 1) { m.power = 1; m.pdir = -1; }
        if (m.power <= 0) { m.power = 0; m.pdir = 1; }
        this.golferAng = lerp(12, -150 * this.club.swing, m.power);
        break;
      case "impact":
        m.impact += m.idir * dt * 1.35 * this.curDiff.ms;
        if (m.impact >= 1) { m.impact = 1; m.idir = -1; }
        if (m.impact <= 0) { m.impact = 0; m.idir = 1; }
        break;
      case "swinging": {
        this.golferT += dt / 0.5;
        const c = this.pending!.club, top = -150 * c.swing, fo = 150 * c.swing;
        this.golferAng = this.golferT < 0.33 ? lerp(top, 12, this.golferT / 0.33) : lerp(12, fo, clamp((this.golferT - 0.33) / 0.67, 0, 1));
        if (!this.launched && this.golferT >= 0.33) { this.launched = true; this.launch(); }
        break;
      }
      case "flight": {
        const f = this.flight!;
        // slow-motion feel while the ball is in the air, easing back to real time on the ground
        const ts = f.seg === "carry" ? (this.heroShot ? 0.55 : 0.72) : f.seg === "roll" ? 0.85 : 1;
        f.update(dt * ts);
        for (const ev of f.events.splice(0)) {
          if (ev.surface === "water") continue;
          this.sfx.bounce(ev.surface, ev.strength, ev.type === "land");
          if (ev.type === "land") navigator.vibrate?.(Math.round(6 + ev.strength * 10));
        }
        if (f.seg === "splash" && !this.splashed) { this.splashed = true; this.world.splash(f.pos.x, f.pos.z); this.sfx.splash(); }
        if (f.finished) this.finalize();
        break;
      }
      default: break;
    }
    if (this.phase !== "title" && this.phase !== "intro") this.updateCamera(dt);
    this.updateVisuals();
    this.updateMeters();
    this.updateLive();
    if (this.toastT > 0) { this.toastT -= dt; if (this.toastT <= 0) $("toast").classList.remove("show"); }
    this.world.update(dt, this.time);
  }

  private aimCam() {
    const o = this.ball, th = (this.phase === "swinging" && this.pending) ? this.pending.th : this.heading;
    const hx = Math.sin(th), hz = Math.cos(th), base = this.world.groundAt(o.x, o.z);
    // screen-right of the aim line is (-hz, hx); nudge the camera that way so the golfer doesn't block the ball
    const rx = -hz, rz = hx;
    if (this.club.id === "putter") {
      const ahead = clamp(this.distPin() * 0.5, 3, 12), lx = o.x + hx * ahead, lz = o.z + hz * ahead;
      return {
        p: new THREE.Vector3(o.x - hx * 7 + rx * 0.8, base + 6.2, o.z - hz * 7 + rz * 0.8),
        l: new THREE.Vector3(lx, this.world.groundAt(lx, lz), lz),
      };
    }
    const lx = o.x + hx * 30, lz = o.z + hz * 30;
    return {
      p: new THREE.Vector3(o.x - hx * 13 + rx * 1.2, base + 5, o.z - hz * 13 + rz * 1.2),
      l: new THREE.Vector3(lx, this.world.groundAt(lx, lz) + 0.5, lz),
    };
  }
  private titleCam() {
    const g = this.hole.green, a = this.time * 0.07, R = g.r * 2.6 + 30, y = groundH(this.hole, g.x, g.z);
    this.cam.p.set(g.x + Math.cos(a) * R, y + 17, g.z + Math.sin(a) * R);
    this.cam.l.set(g.x, y, g.z);
    this.world.setCamera(this.cam.p.x, this.cam.p.y, this.cam.p.z, this.cam.l.x, this.cam.l.y, this.cam.l.z);
  }
  private introCam() {
    const pd = pathData(this.hole), e = smoothstep(0, 1, this.introT);
    const s = pd.total * (1 - e), p = pathAt(this.hole, s);
    const back = 10 + 22 * (1 - e), hgt = 6.4 + 34 * (1 - e);
    const g = this.hole.green;
    const aim = this.aimCam();
    const cp = new THREE.Vector3(p.x - p.tx * back, this.world.groundAt(p.x, p.z) + hgt, p.z - p.tz * back);
    const gl = new THREE.Vector3(g.x, groundH(this.hole, g.x, g.z), g.z);
    const blend = smoothstep(0.8, 1, this.introT);
    this.cam.p.copy(cp.lerp(aim.p, blend));
    this.cam.l.copy(gl.lerp(aim.l, e));
    this.world.setCamera(this.cam.p.x, this.cam.p.y, this.cam.p.z, this.cam.l.x, this.cam.l.y, this.cam.l.z);
  }
  private updateCamera(dt: number) {
    if (this.overhead && this.phase === "aim") {
      const reach = Math.min(this.distPin(), this.club.max);
      const span = clamp(reach * 1.4 + 50, 90, 520);
      const hx = Math.sin(this.heading), hz = Math.cos(this.heading);
      this.world.setTopCamera(this.ball.x + hx * reach * 0.45, this.ball.z + hz * reach * 0.45, span);
      return;
    }
    let D: { p: THREE.Vector3; l: THREE.Vector3 };
    if (this.phase === "flight" && this.flight && this.pending) {
      const b = this.flight.pos, h = this.flight.h, th = this.pending.th, hx = Math.sin(th), hz = Math.cos(th);
      const base = this.world.groundAt(b.x, b.z);
      const putt = this.pending.club.id === "putter";
      D = putt
        ? { p: new THREE.Vector3(b.x - hx * 7, base + 4.2, b.z - hz * 7), l: new THREE.Vector3(b.x + hx * 6, base, b.z + hz * 6) }
        : { p: new THREE.Vector3(b.x - hx * 12, base + 5 + h * 0.45, b.z - hz * 12), l: new THREE.Vector3(b.x + hx * 12, base + 1 + h * 0.6, b.z + hz * 12) };
    } else if (this.phase === "done") {
      const g = this.hole.green, y = groundH(this.hole, g.x, g.z), a = this.time * 0.15;
      D = { p: new THREE.Vector3(g.x + Math.cos(a) * 24, y + 12, g.z + Math.sin(a) * 24), l: new THREE.Vector3(g.x, y, g.z) };
    } else {
      D = this.aimCam();
    }
    const k = this.camSnap ? 1 : Math.min(1, dt * (this.phase === "flight" ? 3.2 : this.phase === "done" ? 1.5 : 8));
    this.camSnap = false;
    this.cam.p.lerp(D.p, k);
    this.cam.l.lerp(D.l, k);
    this.world.setCamera(this.cam.p.x, this.cam.p.y, this.cam.p.z, this.cam.l.x, this.cam.l.y, this.cam.l.z);
  }

  private updateVisuals() {
    const bp = this.flight ? this.flight.pos : this.ball;
    const air = this.flight ? this.flight.h : this.phase === "done" ? -0.6 : 0;
    this.world.setBall(bp.x, bp.z, air);
    const th = (this.phase === "swinging" || this.phase === "flight") && this.pending ? this.pending.th : this.heading;
    this.world.setGolfer(this.ball.x, this.ball.z, th, this.golferAng, this.phase !== "flight" && this.phase !== "done");
    const aiming = this.phase === "aim" || this.phase === "power" || this.phase === "impact";
    const putter = this.club.id === "putter";
    this.world.setAim(this.ball, this.heading, Math.min(this.distPin(), this.club.max), aiming && !putter);
    this.world.setPuttMode(putter && (aiming || this.phase === "swinging"));
    if (aiming && putter) {
      const key = `${this.ball.x.toFixed(2)}|${this.ball.z.toFixed(2)}|${this.heading.toFixed(3)}`;
      if (key !== this.puttKey) { this.puttKey = key; this.world.setPuttPreview(previewPutt(this.hole, this.ball, this.heading, this.distPin())); }
    } else if (this.puttKey !== "") {
      this.puttKey = "";
      this.world.setPuttPreview(null);
    }
  }

  private updateMeters() {
    const showP = this.phase === "power" || this.phase === "impact" || this.phase === "swinging";
    $("powerWrap").classList.toggle("hidden", !showP);
    $("impactWrap").classList.toggle("hidden", this.phase !== "impact");
    if (showP) {
      const pw = this.phase === "power" ? this.meter.power : this.meter.lp;
      $("powerFill").style.height = (pw * 100).toFixed(1) + "%";
      const need = clamp(this.distPin() / (this.club.max * this.curDiff.pm), 0, 1);
      $("powerTick").style.bottom = (need * 100).toFixed(1) + "%";
    }
    if (this.phase === "impact") $("impactMarker").style.left = (this.meter.impact * 100).toFixed(1) + "%";
    const spinOn = this.phase === "flight" && !!this.flight && this.flight.seg === "carry";
    $("spin").classList.toggle("hidden", !spinOn);
    if (spinOn && this.flight) {
      const d = $("spinDot");
      d.style.transform = `translate(calc(-50% + ${(-this.flight.spin.h * 36).toFixed(1)}px), calc(-50% + ${(-this.flight.spin.v * 36).toFixed(1)}px))`;
    }
  }

  private updateLive() {
    if (this.phase === "title") return;
    const th = this.heading, hx = Math.sin(th), hz = Math.cos(th);
    const up = this.wind.x * hx + this.wind.z * hz, right = this.wind.x * -hz + this.wind.z * hx;
    $("windArrow").style.transform = `rotate(${Math.atan2(right, up).toFixed(3)}rad)`;
    const pos = this.flight ? this.flight.pos : this.ball;
    const d = Math.hypot(pos.x - this.pin().x, pos.z - this.pin().z);
    const onG = this.lie() === "green" || this.lie() === "fringe";
    $("toPinVal").textContent = this.phase === "done" ? "0" : onG && !this.flight ? `${Math.round(d * 3)}` : `${Math.round(d)}`;
    $("toPinUnit").textContent = onG && !this.flight ? "ft to pin" : "yds to pin";
    const aiming = this.phase === "aim" || this.phase === "power" || this.phase === "impact";
    this.mini.draw(pos, this.heading, Math.min(this.distPin(), this.club.max), aiming);
  }

  private updateHUD() {
    const h = this.hole;
    $("tbHole").textContent = `${this.holeI + 1}`;
    $("tbPar").textContent = `Par ${h.par}`;
    $("tbYds").textContent = `${this.yards(h)} yds`;
    $("tbShot").textContent = this.phase === "done" ? "Holed" : `Shot ${this.strokes + 1}`;
    $("tbLie").textContent = this.phase === "done" ? "In the cup" : LIE[this.lie()];
    $("tbScore").textContent = relPar(this.roundRel());
    $("windMph").textContent = `${Math.round(this.wind.mph)} mph`;
    const aim = this.phase === "aim";
    document.querySelectorAll<HTMLElement>(".club").forEach((b) => {
      b.classList.toggle("active", b.dataset.id === this.club.id);
      b.classList.toggle("locked", !aim);
    });
    $("btnMap").classList.toggle("on", this.overhead);
    const last = this.holeI === this.course.holes.length - 1;
    const map: Partial<Record<Phase, [string, string, string]>> = {
      intro: ["SKIP", "flyover", "aim"],
      aim: ["SWING", "tap to start", "aim"],
      power: ["POWER", "tap to set", "power"],
      impact: ["STRIKE", "green zone", "impact"],
      swinging: ["···", "", "busy"],
      flight: ["···", this.club.id === "putter" ? "" : "drag: spin", "busy"],
      done: ["NEXT", last ? "scorecard" : `hole ${this.holeI + 2}`, "next"],
    };
    const [lbl, sub, st] = map[this.phase] ?? ["", "", "busy"];
    const btn = $("btnSwing") as HTMLButtonElement;
    $("swingLbl").textContent = lbl;
    $("swingSub").textContent = sub;
    btn.dataset.state = st;
    btn.disabled = st === "busy";
  }
}
