import { World } from "./world";
import { Game } from "./game";

function pickQuality(): boolean {
  try {
    const saved = localStorage.getItem("pg3d.quality");
    if (saved) return saved === "high";
  } catch { /* storage unavailable */ }
  const mobile = /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent) || Math.min(innerWidth, innerHeight) < 520;
  return !mobile;
}

const canvas = document.getElementById("scene") as HTMLCanvasElement;
const high = pickQuality();
const world = new World(canvas, high);
const game = new Game(world, high);
game.attachInput(canvas);
if (location.search.includes("debug")) (window as unknown as { __game: Game }).__game = game;

let last = performance.now();
function frame(now: number) {
  const dt = Math.min(0.05, (now - last) / 1000);
  last = now;
  game.update(dt);
  world.render();
  requestAnimationFrame(frame);
}
requestAnimationFrame(frame);

// Installable / offline when served over HTTPS (e.g. GitHub Pages)
if ("serviceWorker" in navigator && location.protocol === "https:") {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./sw.js").catch(() => { /* not available in this context */ });
  });
}
