// Tiny WebAudio synth — no audio files.
export class Sfx {
  enabled = true;
  private ctx: AudioContext | null = null;

  unlock() {
    if (this.ctx) { if (this.ctx.state === "suspended") void this.ctx.resume(); return; }
    try {
      const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AC();
    } catch { this.ctx = null; }
  }

  private noise(dur: number, freq: number, q: number, gain: number, type: BiquadFilterType) {
    const c = this.ctx;
    if (!c || !this.enabled) return;
    const len = Math.max(1, Math.floor(c.sampleRate * dur));
    const buf = c.createBuffer(1, len, c.sampleRate), d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = c.createBufferSource(); src.buffer = buf;
    const f = c.createBiquadFilter(); f.type = type; f.frequency.value = freq; f.Q.value = q;
    const g = c.createGain(); g.gain.value = gain;
    src.connect(f).connect(g).connect(c.destination);
    src.start();
  }
  private tone(freq: number, dur: number, gain: number, type: OscillatorType = "sine", slideTo?: number, delay = 0) {
    const c = this.ctx;
    if (!c || !this.enabled) return;
    const t0 = c.currentTime + delay;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t0);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(gain, t0 + 0.008);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g).connect(c.destination);
    o.start(t0); o.stop(t0 + dur + 0.02);
  }

  strike(power: number) { this.noise(0.06, 3200, 0.7, 0.35 + power * 0.3, "highpass"); this.tone(160, 0.14, 0.35, "sine", 70); }
  putt() { this.tone(950, 0.06, 0.18, "triangle"); this.noise(0.03, 3500, 1, 0.12, "highpass"); }
  cup() { this.tone(700, 0.14, 0.25, "sine"); this.tone(1050, 0.22, 0.22, "sine", undefined, 0.11); }
  splash() { this.noise(0.6, 900, 0.5, 0.35, "lowpass"); }
  cheer() { this.noise(1.4, 1300, 0.35, 0.16, "bandpass"); }
  click() { this.tone(1400, 0.03, 0.08, "square"); }
}
